<?php
// ============================================================
// middlewares/auth.php
// Validasi session + role + viewer scope
// ============================================================

function requireAuth(): array {
    if (!isset($_SESSION['user_id'])) {
        responseError('Sesi tidak valid. Silakan login kembali.', 401);
    }
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_LIFETIME) {
        session_unset();
        session_destroy();
        responseError('Sesi telah berakhir. Silakan login kembali.', 401);
    }
    $_SESSION['last_activity'] = time();
    return [
        'user_id'  => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'nama'     => $_SESSION['nama'],
        'role'     => $_SESSION['role'],
        'nip'      => $_SESSION['nip']    ?? null,
        'asn_id'   => $_SESSION['asn_id'] ?? null,
    ];
}

function requireRole(array $roles): array {
    $user = requireAuth();
    if (!in_array($user['role'], $roles, true)) {
        responseError('Anda tidak memiliki hak akses untuk operasi ini.', 403);
    }
    return $user;
}

function isAdmin(): bool {
    return ($_SESSION['role'] ?? '') === 'administrator';
}

function isOperator(): bool {
    return in_array($_SESSION['role'] ?? '', ['administrator', 'operator'], true);
}

function isViewer(): bool {
    return ($_SESSION['role'] ?? '') === 'viewer';
}

/**
 * Untuk viewer: kembalikan asn_id dari session.
 * Untuk admin/operator: kembalikan null (tidak dibatasi).
 * Endpoint bisa pakai ini untuk auto-filter.
 */
function getViewerAsnId(): ?int {
    if (isViewer()) {
        $aid = $_SESSION['asn_id'] ?? null;
        return $aid ? (int)$aid : null;
    }
    return null;
}
