<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$db   = getDB();
$tahun = (int)($_GET['tahun'] ?? date('Y'));

// Total ASN
$r = $db->query("SELECT COUNT(*) as total FROM asn WHERE status_asn = 'Aktif'");
$total_asn = (int)$r->fetch_assoc()['total'];

// Per jenis
$r = $db->query("SELECT jenis_asn, COUNT(*) as total FROM asn WHERE status_asn='Aktif' GROUP BY jenis_asn");
$per_jenis = ['PNS' => 0, 'PPPK' => 0];
while ($row = $r->fetch_assoc()) $per_jenis[$row['jenis_asn']] = (int)$row['total'];

// Belum ambil cuti tahunan tahun ini
$stmt = $db->prepare(
    "SELECT COUNT(*) as total FROM asn a
     LEFT JOIN saldo_cuti_tahunan s ON s.asn_id = a.id AND s.tahun = ?
     WHERE a.status_asn = 'Aktif' AND (s.terpakai IS NULL OR s.terpakai = 0)"
);
$stmt->bind_param('i', $tahun);
$stmt->execute();
$belum_cuti = (int)$stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Sisa cuti < 3 hari
$stmt = $db->prepare(
    "SELECT COUNT(*) as total FROM v_saldo_cuti
     WHERE tahun = ? AND sisa_total < 3 AND sisa_total >= 0"
);
$stmt->bind_param('i', $tahun);
$stmt->execute();
$sisa_minim = (int)$stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Akumulasi maksimum (total_hak >= 24)
$stmt = $db->prepare(
    "SELECT COUNT(*) as total FROM v_saldo_cuti WHERE tahun = ? AND total_hak >= 24"
);
$stmt->bind_param('i', $tahun);
$stmt->execute();
$akumulasi_maks = (int)$stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Rekap cuti per bulan tahun ini
$stmt = $db->prepare(
    "SELECT MONTH(tanggal_mulai) as bulan, COUNT(*) as total, SUM(jumlah_hari) as total_hari
     FROM cuti WHERE tahun = ? AND status = 'Disetujui'
     GROUP BY MONTH(tanggal_mulai) ORDER BY bulan"
);
$stmt->bind_param('i', $tahun);
$stmt->execute();
$r = $stmt->get_result();
$rekap_bulanan = array_fill(1, 12, ['total' => 0, 'total_hari' => 0]);
while ($row = $r->fetch_assoc()) {
    $rekap_bulanan[(int)$row['bulan']] = [
        'total'       => (int)$row['total'],
        'total_hari'  => (int)$row['total_hari'],
    ];
}
$stmt->close();

// Rekap per jenis cuti tahun ini
$stmt = $db->prepare(
    "SELECT j.nama, COUNT(*) as total, SUM(c.jumlah_hari) as total_hari
     FROM cuti c JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.tahun = ? AND c.status = 'Disetujui'
     GROUP BY j.id ORDER BY total_hari DESC"
);
$stmt->bind_param('i', $tahun);
$stmt->execute();
$rekap_jenis = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ASN sedang cuti hari ini
$today = date('Y-m-d');
$stmt = $db->prepare(
    "SELECT a.nama, a.unit_kerja, j.nama as jenis_cuti, c.tanggal_mulai, c.tanggal_selesai
     FROM cuti c JOIN asn a ON a.id = c.asn_id JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE ? BETWEEN c.tanggal_mulai AND c.tanggal_selesai AND c.status = 'Disetujui'
     ORDER BY a.nama LIMIT 10"
);
$stmt->bind_param('s', $today);
$stmt->execute();
$sedang_cuti = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

responseSuccess('OK', [
    'total_asn'      => $total_asn,
    'total_pns'      => $per_jenis['PNS'],
    'total_pppk'     => $per_jenis['PPPK'],
    'belum_cuti'     => $belum_cuti,
    'sisa_minim'     => $sisa_minim,
    'akumulasi_maks' => $akumulasi_maks,
    'rekap_bulanan'  => array_values($rekap_bulanan),
    'rekap_jenis'    => $rekap_jenis,
    'sedang_cuti'    => $sedang_cuti,
    'tahun'          => $tahun,
]);
