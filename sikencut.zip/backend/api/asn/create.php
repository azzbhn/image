<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);
$user = requireRole(['administrator', 'operator']);

$body   = getBody();
$errors = validateRequired($body, ['nip','nama','jenis_asn','jabatan','unit_kerja','tmt_asn']);
if ($errors) responseError(implode(' ', $errors));

$nip       = sanitizeString($body['nip']       ?? '');
$nama      = sanitizeString($body['nama']      ?? '');
$jenis_asn = sanitizeString($body['jenis_asn'] ?? '');
$jabatan   = sanitizeString($body['jabatan']   ?? '');
$unit      = sanitizeString($body['unit_kerja']?? '');
$tmt       = sanitizeString($body['tmt_asn']   ?? '');
$status    = sanitizeString($body['status_asn']?? 'Aktif');
$hp        = sanitizeString($body['nomor_hp']  ?? '');
$email     = sanitizeString($body['email']     ?? '');
$ket       = sanitizeString($body['keterangan']?? '');

if (!in_array($jenis_asn, ['PNS','PPPK','PPPK PW'])) responseError('Jenis ASN tidak valid.');
if (!validateDate($tmt)) responseError('Format tanggal TMT tidak valid (YYYY-MM-DD).');
$valid_status = ['Aktif','Non-Aktif','Pensiun','CLTN'];
if (!in_array($status, $valid_status)) responseError('Status ASN tidak valid.');
if ($email && !validateEmail($email)) responseError('Format email tidak valid.');

$db = getDB();

// Cek NIP duplikat
$s = $db->prepare("SELECT id FROM asn WHERE nip = ? LIMIT 1");
$s->bind_param('s', $nip);
$s->execute();
if ($s->get_result()->num_rows > 0) responseError('NIP sudah terdaftar.');
$s->close();

$uid = $user['user_id'];
$stmt = $db->prepare(
    "INSERT INTO asn (nip,nama,jenis_asn,jabatan,unit_kerja,tmt_asn,status_asn,nomor_hp,email,keterangan,created_by)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)"
);
$stmt->bind_param('ssssssssssi', $nip,$nama,$jenis_asn,$jabatan,$unit,$tmt,$status,$hp,$email,$ket,$uid);
$stmt->execute();
$new_id = (int)$db->insert_id;
$stmt->close();

// Buat saldo cuti tahunan tahun berjalan
$tahun = (int)date('Y');
$stmt2 = $db->prepare(
    "INSERT IGNORE INTO saldo_cuti_tahunan (asn_id, tahun, hak_tahun_ini, sisa_n1, sisa_n2, terpakai)
     VALUES (?, ?, 12, 0, 0, 0)"
);
$stmt2->bind_param('ii', $new_id, $tahun);
$stmt2->execute();
$stmt2->close();

writeAudit('tambah_asn', 'asn', $new_id, "Tambah ASN: $nama ($nip)");
responseSuccess('Data ASN berhasil ditambahkan.', ['id' => $new_id], 201);
