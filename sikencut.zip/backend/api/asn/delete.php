<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['DELETE','POST']);
$user = requireRole(['administrator']);

$body = getBody();
$id   = (int)($body['id'] ?? $_GET['id'] ?? 0);
if (!$id) responseError('ID ASN tidak valid.');

$db = getDB();

// Cek ada cuti
$s = $db->prepare("SELECT COUNT(*) as total FROM cuti WHERE asn_id = ?");
$s->bind_param('i', $id);
$s->execute();
$has_cuti = (int)$s->get_result()->fetch_assoc()['total'];
$s->close();

if ($has_cuti > 0) {
    responseError('ASN ini memiliki riwayat cuti dan tidak dapat dihapus. Nonaktifkan saja.');
}

$s = $db->prepare("SELECT nama, nip FROM asn WHERE id = ? LIMIT 1");
$s->bind_param('i', $id);
$s->execute();
$asn = $s->get_result()->fetch_assoc();
$s->close();

if (!$asn) responseError('Data ASN tidak ditemukan.', 404);

$db->begin_transaction();
try {
    $s = $db->prepare("DELETE FROM saldo_cuti_tahunan WHERE asn_id = ?");
    $s->bind_param('i', $id); $s->execute(); $s->close();

    $s = $db->prepare("DELETE FROM asn WHERE id = ?");
    $s->bind_param('i', $id); $s->execute(); $s->close();

    $db->commit();
} catch (Throwable $e) {
    $db->rollback();
    error_log('[SICUTI] Delete ASN error: ' . $e->getMessage());
    responseError('Gagal menghapus data. Silakan coba lagi.', 500);
}

writeAudit('hapus_asn', 'asn', $id, "Hapus ASN: {$asn['nama']} ({$asn['nip']})");
responseSuccess('Data ASN berhasil dihapus.');
