<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$id = (int)($_GET['id'] ?? 0);
if (!$id) responseError('ID ASN tidak valid.');

$db = getDB();
$stmt = $db->prepare(
    "SELECT a.*, u.nama as created_by_nama
     FROM asn a LEFT JOIN users u ON u.id = a.created_by
     WHERE a.id = ? LIMIT 1"
);
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) responseError('Data ASN tidak ditemukan.', 404);

responseSuccess('OK', $row);
