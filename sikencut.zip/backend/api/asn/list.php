<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$db = getDB();

$page     = max(1, (int)($_GET['page']     ?? 1));
$per_page = min(100, max(5, (int)($_GET['per_page'] ?? 15)));
$offset   = ($page - 1) * $per_page;
$search   = sanitizeString($_GET['q'] ?? '');
$jenis    = sanitizeString($_GET['jenis_asn'] ?? '');
$status   = sanitizeString($_GET['status_asn'] ?? '');
$unit     = sanitizeString($_GET['unit_kerja'] ?? '');

$where  = [];
$params = [];
$types  = '';

if ($search) {
    $like = "%$search%";
    $where[]  = "(a.nip LIKE ? OR a.nama LIKE ? OR a.jabatan LIKE ?)";
    $params   = array_merge($params, [$like, $like, $like]);
    $types   .= 'sss';
}
if ($jenis && in_array($jenis, ['PNS','PPPK'])) {
    $where[]  = "a.jenis_asn = ?";
    $params[] = $jenis;
    $types   .= 's';
}
if ($status) {
    $where[]  = "a.status_asn = ?";
    $params[] = $status;
    $types   .= 's';
}
if ($unit) {
    $like2    = "%$unit%";
    $where[]  = "a.unit_kerja LIKE ?";
    $params[] = $like2;
    $types   .= 's';
}

$sql_where = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Total
$stmt_count = $db->prepare("SELECT COUNT(*) as total FROM asn a $sql_where");
if ($types) $stmt_count->bind_param($types, ...$params);
$stmt_count->execute();
$total = (int)$stmt_count->get_result()->fetch_assoc()['total'];
$stmt_count->close();

// Data
$types_full   = $types . 'ii';
$params_full  = array_merge($params, [$per_page, $offset]);
$stmt = $db->prepare(
    "SELECT a.id, a.nip, a.nama, a.jenis_asn, a.jabatan, a.unit_kerja,
            a.tmt_asn, a.status_asn, a.nomor_hp, a.email, a.keterangan,
            a.created_at, a.updated_at
     FROM asn a $sql_where
     ORDER BY a.nama ASC
     LIMIT ? OFFSET ?"
);
$stmt->bind_param($types_full, ...$params_full);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

responsePaginated('OK', $rows, $total, $page, $per_page);
