<?php
// ============================================================
// api/asn/dashboard.php
// Profil lengkap satu ASN dengan filter tahun.
// Mengembalikan saldo referensi, saldo kalkulasi, dan riwayat
// berdasarkan tahun terpilih.
// ============================================================
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
$user = requireAuth();

$req_id     = (int)($_GET['id']    ?? 0);
$tahun_req  = (int)($_GET['tahun'] ?? date('Y'));
$viewer_asn = getViewerAsnId();

if ($viewer_asn !== null) {
    $id = $viewer_asn;
} else {
    if (!$req_id) responseError('Parameter id wajib diisi.');
    $id = $req_id;
}

if ($tahun_req < 2020 || $tahun_req > 2100) $tahun_req = (int)date('Y');

$db        = getDB();
$tahun_ini = (int)date('Y');

// ── 1. Data Pokok ASN ─────────────────────────────────────
$s = $db->prepare(
    "SELECT a.*, u.nama AS created_by_nama
     FROM asn a LEFT JOIN users u ON u.id = a.created_by
     WHERE a.id = ? LIMIT 1"
);
$s->bind_param('i', $id); $s->execute();
$asn = $s->get_result()->fetch_assoc(); $s->close();
if (!$asn) responseError('ASN tidak ditemukan.', 404);

// ── 2. Daftar tahun yang tersedia (untuk dropdown) ────────
$s = $db->prepare(
    "SELECT DISTINCT tahun FROM saldo_cuti_tahunan
     WHERE asn_id = ? ORDER BY tahun DESC"
);
$s->bind_param('i', $id); $s->execute();
$tahun_tersedia = array_column($s->get_result()->fetch_all(MYSQLI_ASSOC), 'tahun');
$s->close();
// Pastikan tahun berjalan selalu ada
if (!in_array($tahun_ini, $tahun_tersedia)) {
    $tahun_tersedia[] = $tahun_ini;
    rsort($tahun_tersedia);
}

// ── 3. Saldo tahun yang dipilih (referensi + kalkulasi) ───
$saldo = getSaldoOrCreate($db, $id, $tahun_req);
$k     = $saldo['kalkulasi'];

$saldo_display = [
    // Referensi — tidak berubah akibat transaksi
    'hak_tahun_ini' => (int)$saldo['hak_tahun_ini'],
    'sisa_n1'       => (int)$saldo['sisa_n1'],
    'sisa_n2'       => (int)$saldo['sisa_n2'],
    'total_hak'     => (int)$k['total_hak'],
    // Transaksi
    'terpakai'      => (int)$k['terpakai'],
    // Kalkulasi — dinamis, urutan N-2 → N-1 → N
    'sisa_total'    => (int)$k['sisa_total'],
    'n2_tersisa'    => (int)$k['n2_tersisa'],
    'n1_tersisa'    => (int)$k['n1_tersisa'],
    'n_tersisa'     => (int)$k['n_tersisa'],
];

// ── 4. Histori saldo semua tahun (untuk tab Saldo) ───────
$s = $db->prepare(
    "SELECT tahun, hak_tahun_ini, sisa_n1, sisa_n2, terpakai
     FROM saldo_cuti_tahunan WHERE asn_id = ? ORDER BY tahun DESC"
);
$s->bind_param('i', $id); $s->execute();
$saldo_history_raw = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();

$saldo_history = array_map(function($sh) {
    $k = hitungSaldo(
        (int)$sh['hak_tahun_ini'],
        (int)$sh['sisa_n1'],
        (int)$sh['sisa_n2'],
        (int)$sh['terpakai']
    );
    return array_merge($sh, [
        'total_hak'  => $k['total_hak'],
        'sisa_total' => $k['sisa_total'],
        'n2_tersisa' => $k['n2_tersisa'],
        'n1_tersisa' => $k['n1_tersisa'],
        'n_tersisa'  => $k['n_tersisa'],
    ]);
}, $saldo_history_raw);

// ── 5. Riwayat cuti tahun terpilih (semua jenis) ─────────
$s = $db->prepare(
    "SELECT c.id, c.tanggal_mulai, c.tanggal_selesai, c.jumlah_hari,
            c.tahun, c.alasan, c.alamat_selama_cuti, c.status, c.created_at,
            j.kode AS jenis_kode, j.nama AS jenis_nama,
            u.nama AS created_by_nama
     FROM cuti c
     JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     LEFT JOIN users u ON u.id = c.created_by
     WHERE c.asn_id = ? AND c.tahun = ?
     ORDER BY c.tanggal_mulai DESC"
);
$s->bind_param('ii', $id, $tahun_req); $s->execute();
$riwayat_tahun = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();

// Group riwayat per jenis
$riwayat_per_jenis = [];
foreach ($riwayat_tahun as $r) {
    $k2 = $r['jenis_kode'];
    if (!isset($riwayat_per_jenis[$k2])) {
        $riwayat_per_jenis[$k2] = [
            'kode'       => $k2,
            'nama'       => $r['jenis_nama'],
            'total_hari' => 0,
            'total_kali' => 0,
            'items'      => [],
        ];
    }
    $riwayat_per_jenis[$k2]['total_hari'] += (int)$r['jumlah_hari'];
    $riwayat_per_jenis[$k2]['total_kali']++;
    $riwayat_per_jenis[$k2]['items'][] = $r;
}

// ── 6. Semua riwayat cuti (all time, untuk timeline) ─────
$s = $db->prepare(
    "SELECT c.id, c.tanggal_mulai, c.tanggal_selesai, c.jumlah_hari,
            c.tahun, c.alasan, c.status, c.created_at,
            j.kode AS jenis_kode, j.nama AS jenis_nama
     FROM cuti c JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.asn_id = ? AND c.status = 'Disetujui'
     ORDER BY c.tanggal_mulai DESC"
);
$s->bind_param('i', $id); $s->execute();
$riwayat_semua = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();

// ── 7. Statistik per jenis (all time) ────────────────────
$s = $db->prepare(
    "SELECT j.kode, j.nama AS jenis_nama,
            COUNT(*) AS total_kali,
            SUM(c.jumlah_hari) AS total_hari,
            MIN(c.tanggal_mulai) AS pertama,
            MAX(c.tanggal_mulai) AS terakhir
     FROM cuti c JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.asn_id = ? AND c.status = 'Disetujui'
     GROUP BY j.id ORDER BY total_hari DESC"
);
$s->bind_param('i', $id); $s->execute();
$statistik_jenis = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();

$total_hari_cuti = array_sum(array_column($statistik_jenis, 'total_hari'));
$total_kali_cuti = array_sum(array_column($statistik_jenis, 'total_kali'));

// ── 8. Rekap per tahun ───────────────────────────────────
$s = $db->prepare(
    "SELECT c.tahun, COUNT(*) AS total_kali, SUM(c.jumlah_hari) AS total_hari
     FROM cuti c JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.asn_id = ? AND c.status = 'Disetujui'
     GROUP BY c.tahun ORDER BY c.tahun DESC"
);
$s->bind_param('i', $id); $s->execute();
$rekap_per_tahun = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();

// ── 9. Masa Kerja ────────────────────────────────────────
$tmt  = new DateTime($asn['tmt_asn']);
$diff = $tmt->diff(new DateTime());
$masa_kerja = [
    'tahun'       => $diff->y,
    'bulan'       => $diff->m,
    'hari'        => $diff->d,
    'total_bulan' => $diff->y * 12 + $diff->m,
];

// ── 10. Sedang cuti hari ini ─────────────────────────────
$today = date('Y-m-d');
$s = $db->prepare(
    "SELECT c.tanggal_mulai, c.tanggal_selesai, j.nama AS jenis_nama
     FROM cuti c JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.asn_id = ? AND ? BETWEEN c.tanggal_mulai AND c.tanggal_selesai
       AND c.status = 'Disetujui' LIMIT 1"
);
$s->bind_param('is', $id, $today); $s->execute();
$sedang_cuti = $s->get_result()->fetch_assoc(); $s->close();

responseSuccess('OK', [
    'asn'              => $asn,
    'masa_kerja'       => $masa_kerja,
    'tahun_dipilih'    => $tahun_req,
    'tahun_ini'        => $tahun_ini,
    'tahun_tersedia'   => $tahun_tersedia,

    // Saldo dengan breakdown referensi + kalkulasi
    'saldo'            => $saldo_display,
    'saldo_history'    => $saldo_history,

    // Riwayat tahun terpilih (dikelompok per jenis)
    'riwayat_tahun'    => array_values($riwayat_per_jenis),
    'riwayat_list'     => $riwayat_tahun,  // flat list untuk tabel

    // Data all-time untuk chart/statistik
    'riwayat_semua'    => $riwayat_semua,
    'statistik_jenis'  => $statistik_jenis,
    'rekap_per_tahun'  => $rekap_per_tahun,
    'total_hari_cuti'  => (int)$total_hari_cuti,
    'total_kali_cuti'  => (int)$total_kali_cuti,
    'sedang_cuti'      => $sedang_cuti,
]);
