<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['PUT','POST']);
$user = requireRole(['administrator', 'operator']);

$body   = getBody();
$id     = (int)($body['id'] ?? $_GET['id'] ?? 0);
if (!$id) responseError('ID ASN tidak valid.');

$errors = validateRequired($body, ['nip','nama','jenis_asn','jabatan','unit_kerja','tmt_asn']);
if ($errors) responseError(implode(' ', $errors));

$nip    = sanitizeString($body['nip']       ?? '');
$nama   = sanitizeString($body['nama']      ?? '');
$jenis  = sanitizeString($body['jenis_asn'] ?? '');
$jbtn   = sanitizeString($body['jabatan']   ?? '');
$unit   = sanitizeString($body['unit_kerja']?? '');
$tmt    = sanitizeString($body['tmt_asn']   ?? '');
$status = sanitizeString($body['status_asn']?? 'Aktif');
$hp     = sanitizeString($body['nomor_hp']  ?? '');
$email  = sanitizeString($body['email']     ?? '');
$ket    = sanitizeString($body['keterangan']?? '');

if (!in_array($jenis, ['PNS','PPPK','PPPK PW'])) responseError('Jenis ASN tidak valid.');
if (!validateDate($tmt)) responseError('Format tanggal TMT tidak valid.');
if ($email && !validateEmail($email)) responseError('Format email tidak valid.');

$db = getDB();

// Cek data exist
$s = $db->prepare("SELECT id FROM asn WHERE id = ? LIMIT 1");
$s->bind_param('i', $id);
$s->execute();
if ($s->get_result()->num_rows === 0) responseError('Data ASN tidak ditemukan.', 404);
$s->close();

// Cek NIP duplikat
$s = $db->prepare("SELECT id FROM asn WHERE nip = ? AND id != ? LIMIT 1");
$s->bind_param('si', $nip, $id);
$s->execute();
if ($s->get_result()->num_rows > 0) responseError('NIP sudah digunakan oleh ASN lain.');
$s->close();

$stmt = $db->prepare(
    "UPDATE asn SET nip=?,nama=?,jenis_asn=?,jabatan=?,unit_kerja=?,tmt_asn=?,
                    status_asn=?,nomor_hp=?,email=?,keterangan=?
     WHERE id = ?"
);
$stmt->bind_param('ssssssssssi', $nip,$nama,$jenis,$jbtn,$unit,$tmt,$status,$hp,$email,$ket,$id);
$stmt->execute();
$stmt->close();

writeAudit('edit_asn', 'asn', $id, "Edit ASN: $nama ($nip)");
responseSuccess('Data ASN berhasil diperbarui.');
