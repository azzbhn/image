<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$db      = getDB();
$tahun   = (int)($_GET['tahun']  ?? date('Y'));
$jenis   = sanitizeString($_GET['jenis'] ?? '');
$page    = max(1, (int)($_GET['page']    ?? 1));
$perpage = min(100, max(10, (int)($_GET['per_page'] ?? 50)));
$offset  = ($page - 1) * $perpage;

$where  = ['YEAR(h.tanggal) = ?'];
$params = [$tahun];
$types  = 'i';

if ($jenis && in_array($jenis, ['Hari Libur Nasional', 'Cuti Bersama'])) {
    $where[]  = 'h.jenis = ?';
    $params[] = $jenis;
    $types   .= 's';
}

$sql_where = 'WHERE ' . implode(' AND ', $where);

$sc = $db->prepare("SELECT COUNT(*) as total FROM hari_libur h $sql_where");
$sc->bind_param($types, ...$params);
$sc->execute();
$total = (int)$sc->get_result()->fetch_assoc()['total'];
$sc->close();

$types_f  = $types . 'ii';
$params_f = array_merge($params, [$perpage, $offset]);
$st = $db->prepare(
    "SELECT h.id, h.tanggal, h.nama, h.jenis, h.is_recurring, h.keterangan,
            h.created_at, u.nama as created_by_nama
     FROM hari_libur h LEFT JOIN users u ON u.id = h.created_by
     $sql_where ORDER BY h.tanggal ASC LIMIT ? OFFSET ?"
);
$st->bind_param($types_f, ...$params_f);
$st->execute();
$rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$st->close();

responsePaginated('OK', $rows, $total, $page, $perpage);
