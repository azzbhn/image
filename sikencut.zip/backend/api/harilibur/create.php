<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);
$user = requireRole(['administrator', 'operator']);

$body   = getBody();
$errors = validateRequired($body, ['tanggal', 'nama', 'jenis']);
if ($errors) responseError(implode(' ', $errors));

$tanggal    = sanitizeString($body['tanggal']     ?? '');
$nama       = sanitizeString($body['nama']        ?? '');
$jenis      = sanitizeString($body['jenis']       ?? '');
$is_recurring = (int)($body['is_recurring'] ?? 0);
$keterangan = sanitizeString($body['keterangan']  ?? '');

if (!validateDate($tanggal)) responseError('Format tanggal tidak valid (YYYY-MM-DD).');
if (!in_array($jenis, ['Hari Libur Nasional', 'Cuti Bersama'])) {
    responseError('Jenis hari libur tidak valid.');
}
if (strlen($nama) < 3) responseError('Nama minimal 3 karakter.');

$db  = getDB();
$uid = $user['user_id'];

// Cek duplikat tanggal
$s = $db->prepare("SELECT id, nama FROM hari_libur WHERE tanggal = ? LIMIT 1");
$s->bind_param('s', $tanggal);
$s->execute();
$existing = $s->get_result()->fetch_assoc();
$s->close();
if ($existing) {
    responseError("Tanggal {$tanggal} sudah terdaftar sebagai: {$existing['nama']}");
}

$stmt = $db->prepare(
    "INSERT INTO hari_libur (tanggal, nama, jenis, is_recurring, keterangan, created_by)
     VALUES (?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param('sssisi', $tanggal, $nama, $jenis, $is_recurring, $keterangan, $uid);
$stmt->execute();
$new_id = (int)$db->insert_id;
$stmt->close();

writeAudit('tambah_hari_libur', 'harilibur', $new_id, "Tambah: {$nama} ({$tanggal}) — {$jenis}");
responseSuccess('Hari libur berhasil ditambahkan.', ['id' => $new_id], 201);
