<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['PUT', 'POST']);
$user = requireRole(['administrator', 'operator']);

$body   = getBody();
$id     = (int)($body['id'] ?? $_GET['id'] ?? 0);
if (!$id) responseError('ID tidak valid.');

$errors = validateRequired($body, ['tanggal', 'nama', 'jenis']);
if ($errors) responseError(implode(' ', $errors));

$tanggal      = sanitizeString($body['tanggal']     ?? '');
$nama         = sanitizeString($body['nama']        ?? '');
$jenis        = sanitizeString($body['jenis']       ?? '');
$is_recurring = (int)($body['is_recurring'] ?? 0);
$keterangan   = sanitizeString($body['keterangan']  ?? '');

if (!validateDate($tanggal)) responseError('Format tanggal tidak valid.');
if (!in_array($jenis, ['Hari Libur Nasional', 'Cuti Bersama'])) {
    responseError('Jenis tidak valid.');
}

$db = getDB();

// Cek exist
$s = $db->prepare("SELECT id FROM hari_libur WHERE id = ? LIMIT 1");
$s->bind_param('i', $id); $s->execute();
if ($s->get_result()->num_rows === 0) responseError('Data tidak ditemukan.', 404);
$s->close();

// Cek duplikat tanggal (selain diri sendiri)
$s = $db->prepare("SELECT id FROM hari_libur WHERE tanggal = ? AND id != ? LIMIT 1");
$s->bind_param('si', $tanggal, $id); $s->execute();
if ($s->get_result()->num_rows > 0) responseError('Tanggal tersebut sudah terdaftar untuk hari libur lain.');
$s->close();

$stmt = $db->prepare(
    "UPDATE hari_libur SET tanggal=?, nama=?, jenis=?, is_recurring=?, keterangan=? WHERE id=?"
);
$stmt->bind_param('sssisi', $tanggal, $nama, $jenis, $is_recurring, $keterangan, $id);
$stmt->execute();
$stmt->close();

writeAudit('edit_hari_libur', 'harilibur', $id, "Edit: {$nama} ({$tanggal})");
responseSuccess('Hari libur berhasil diperbarui.');
