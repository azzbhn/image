<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);
$user = requireRole(['administrator', 'operator']);

$body  = getBody();
$items = $body['items'] ?? [];

if (!is_array($items) || count($items) === 0) {
    responseError('Tidak ada data yang dikirim.');
}
if (count($items) > 100) {
    responseError('Maksimal 100 hari libur per import.');
}

$db      = getDB();
$uid     = $user['user_id'];
$ok      = 0;
$skipped = [];

$stmt = $db->prepare(
    "INSERT IGNORE INTO hari_libur (tanggal, nama, jenis, is_recurring, keterangan, created_by)
     VALUES (?, ?, ?, ?, ?, ?)"
);

foreach ($items as $item) {
    $tanggal      = sanitizeString($item['tanggal']     ?? '');
    $nama         = sanitizeString($item['nama']        ?? '');
    $jenis        = sanitizeString($item['jenis']       ?? 'Hari Libur Nasional');
    $is_recurring = (int)($item['is_recurring'] ?? 0);
    $keterangan   = sanitizeString($item['keterangan']  ?? '');

    if (!validateDate($tanggal) || strlen($nama) < 2) {
        $skipped[] = $tanggal ?: 'unknown';
        continue;
    }
    if (!in_array($jenis, ['Hari Libur Nasional', 'Cuti Bersama'])) {
        $jenis = 'Hari Libur Nasional';
    }

    $stmt->bind_param('sssisi', $tanggal, $nama, $jenis, $is_recurring, $keterangan, $uid);
    $stmt->execute();
    if ($db->affected_rows > 0) $ok++;
    else $skipped[] = $tanggal;
}
$stmt->close();

writeAudit('import_hari_libur', 'harilibur', null, "Import {$ok} hari libur, skip: " . count($skipped));
responseSuccess("Import selesai: {$ok} berhasil, " . count($skipped) . " dilewati (duplikat/error).", [
    'berhasil' => $ok,
    'dilewati' => $skipped,
]);
