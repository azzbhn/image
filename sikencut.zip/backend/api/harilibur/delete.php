<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['DELETE', 'POST']);
$user = requireRole(['administrator']);

$body = getBody();
$id   = (int)($body['id'] ?? $_GET['id'] ?? 0);
if (!$id) responseError('ID tidak valid.');

$db = getDB();
$s  = $db->prepare("SELECT nama, tanggal FROM hari_libur WHERE id = ? LIMIT 1");
$s->bind_param('i', $id); $s->execute();
$row = $s->get_result()->fetch_assoc(); $s->close();
if (!$row) responseError('Data tidak ditemukan.', 404);

$s = $db->prepare("DELETE FROM hari_libur WHERE id = ?");
$s->bind_param('i', $id); $s->execute(); $s->close();

writeAudit('hapus_hari_libur', 'harilibur', $id, "Hapus: {$row['nama']} ({$row['tanggal']})");
responseSuccess('Hari libur berhasil dihapus.');
