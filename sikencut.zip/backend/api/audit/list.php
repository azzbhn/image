<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireRole(['administrator']);

$db      = getDB();
$page    = max(1, (int)($_GET['page']    ?? 1));
$perpage = min(100, max(10, (int)($_GET['per_page'] ?? 20)));
$offset  = ($page - 1) * $perpage;
$aksi    = sanitizeString($_GET['aksi']   ?? '');
$modul   = sanitizeString($_GET['modul']  ?? '');
$search  = sanitizeString($_GET['q']      ?? '');
$tgl     = sanitizeString($_GET['tanggal']?? '');

$where = []; $params = []; $types = '';

if ($aksi)   { $where[] = "aksi=?";   $params[] = $aksi;    $types .= 's'; }
if ($modul)  { $where[] = "modul=?";  $params[] = $modul;   $types .= 's'; }
if ($search) { $like = "%$search%"; $where[] = "username LIKE ?"; $params[] = $like; $types .= 's'; }
if ($tgl && validateDate($tgl)) {
    $where[] = "DATE(created_at) = ?"; $params[] = $tgl; $types .= 's';
}

$sql_where = $where ? 'WHERE '.implode(' AND ', $where) : '';

$sc = $db->prepare("SELECT COUNT(*) as total FROM audit_log $sql_where");
if ($types) $sc->bind_param($types, ...$params);
$sc->execute();
$total = (int)$sc->get_result()->fetch_assoc()['total'];
$sc->close();

$st = $db->prepare(
    "SELECT id, user_id, username, aksi, modul, target_id, keterangan, ip_address, created_at
     FROM audit_log $sql_where ORDER BY created_at DESC LIMIT ? OFFSET ?"
);
$types_f = $types.'ii';
$params_f = array_merge($params, [$perpage, $offset]);
$st->bind_param($types_f, ...$params_f);
$st->execute();
$rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$st->close();

responsePaginated('OK', $rows, $total, $page, $perpage);
