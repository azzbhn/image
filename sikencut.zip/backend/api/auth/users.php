<?php
require_once __DIR__ . '/../../bootstrap.php';

$method = getMethod();
allowMethods(['GET','POST','PUT','DELETE']);
$user = requireRole(['administrator']);
$db   = getDB();

// GET list
if ($method === 'GET' && !isset($_GET['id'])) {
    $rows = $db->query(
        "SELECT id, username, nama, nip, role, is_active, created_at FROM users ORDER BY role, nama"
    )->fetch_all(MYSQLI_ASSOC);
    responseSuccess('OK', $rows);
}

// GET detail
if ($method === 'GET' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $s  = $db->prepare("SELECT id,username,nama,nip,role,is_active FROM users WHERE id=? LIMIT 1");
    $s->bind_param('i', $id); $s->execute();
    $row = $s->get_result()->fetch_assoc(); $s->close();
    if (!$row) responseError('User tidak ditemukan.', 404);
    responseSuccess('OK', $row);
}

$body = getBody();

// POST create
if ($method === 'POST') {
    $errors = validateRequired($body, ['username','password','nama','role']);
    if ($errors) responseError(implode(' ', $errors));

    $uname = sanitizeString($body['username'] ?? '');
    $pass  = (string)($body['password'] ?? '');
    $nama  = sanitizeString($body['nama']     ?? '');
    $role  = sanitizeString($body['role']     ?? '');
    $nip   = sanitizeString($body['nip']      ?? '');

    if (!in_array($role, ['administrator','operator','viewer'])) responseError('Role tidak valid.');
    if (strlen($pass) < 8) responseError('Password minimal 8 karakter.');

    $s = $db->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
    $s->bind_param('s', $uname); $s->execute();
    if ($s->get_result()->num_rows > 0) responseError('Username sudah digunakan.');
    $s->close();

    $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]);
    $nipVal = $nip ?: null;
    $s = $db->prepare("INSERT INTO users (username,password,nama,nip,role) VALUES(?,?,?,?,?)");
    $s->bind_param('sssss', $uname,$hash,$nama,$nipVal,$role); $s->execute();
    $new_id = (int)$db->insert_id; $s->close();

    writeAudit('tambah_user', 'users', $new_id, "Tambah user: $uname ($role)");
    responseSuccess('User berhasil ditambahkan.', ['id'=>$new_id], 201);
}

// PUT update
if ($method === 'PUT') {
    $id     = (int)($body['id'] ?? 0);
    $nama   = sanitizeString($body['nama']   ?? '');
    $role   = sanitizeString($body['role']   ?? '');
    $nip    = sanitizeString($body['nip']    ?? '');
    $active = (int)($body['is_active'] ?? 1);

    if (!$id || !$nama || !$role) responseError('Data tidak lengkap.');
    if (!in_array($role, ['administrator','operator','viewer'])) responseError('Role tidak valid.');

    $nipVal = $nip ?: null;
    $s = $db->prepare("UPDATE users SET nama=?,role=?,nip=?,is_active=? WHERE id=?");
    $s->bind_param('sssii', $nama,$role,$nipVal,$active,$id); $s->execute(); $s->close();

    if (!empty($body['password'])) {
        $pass = (string)$body['password'];
        if (strlen($pass) < 8) responseError('Password minimal 8 karakter.');
        $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]);
        $s = $db->prepare("UPDATE users SET password=? WHERE id=?");
        $s->bind_param('si', $hash, $id); $s->execute(); $s->close();
    }

    writeAudit('edit_user', 'users', $id, "Edit user ID $id");
    responseSuccess('User berhasil diperbarui.');
}

// DELETE
if ($method === 'DELETE') {
    $id = (int)($body['id'] ?? $_GET['id'] ?? 0);
    if (!$id) responseError('ID tidak valid.');
    if ($id === $user['user_id']) responseError('Tidak dapat menghapus akun sendiri.');

    $s = $db->prepare("DELETE FROM users WHERE id=?");
    $s->bind_param('i', $id); $s->execute(); $s->close();

    writeAudit('hapus_user', 'users', $id, "Hapus user ID $id");
    responseSuccess('User berhasil dihapus.');
}
