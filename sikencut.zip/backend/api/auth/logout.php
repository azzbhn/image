<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);

if (isset($_SESSION['user_id'])) {
    writeAudit('logout', 'auth', (int)$_SESSION['user_id'], 'Logout');
}

session_unset();
session_destroy();

responseSuccess('Logout berhasil.');
