<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);
$user = requireAuth();
$body = getBody();

$errors = validateRequired($body, ['password_lama', 'password_baru']);
if ($errors) responseError(implode(' ', $errors));

$old = (string)($body['password_lama'] ?? '');
$new = (string)($body['password_baru'] ?? '');

if (strlen($new) < 8) responseError('Password baru minimal 8 karakter.');

$db   = getDB();
$stmt = $db->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $user['user_id']);
$stmt->execute();
$row  = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row || !password_verify($old, $row['password'])) {
    responseError('Password lama tidak sesuai.');
}

$hash = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
$stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
$stmt->bind_param('si', $hash, $user['user_id']);
$stmt->execute();
$stmt->close();

writeAudit('ganti_password', 'auth', $user['user_id'], 'Ganti password');
responseSuccess('Password berhasil diubah.');
