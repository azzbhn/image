<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
$user = requireAuth();

// Sertakan asn_id & nip untuk viewer
responseSuccess('OK', [
    'user_id'  => $user['user_id'],
    'username' => $user['username'],
    'nama'     => $user['nama'],
    'role'     => $user['role'],
    'nip'      => $_SESSION['nip']    ?? null,
    'asn_id'   => $_SESSION['asn_id'] ?? null,
]);
