<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);

$body = getBody();
$errors = validateRequired($body, ['username', 'password']);
if ($errors) responseError(implode(' ', $errors));

$username = sanitizeString($body['username'] ?? '');
$password = (string)($body['password'] ?? '');

if (strlen($username) > 50 || strlen($password) > 255) {
    responseError('Username atau password tidak valid.');
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, username, password, nama, nip, role, is_active FROM users WHERE username = ? LIMIT 1"
);
$stmt->bind_param('s', $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user || !password_verify($password, $user['password'])) {
    writeAudit('login_gagal', 'auth', null, "Percobaan login gagal: $username");
    responseError('Username atau password salah.', 401);
}

if (!$user['is_active']) {
    responseError('Akun Anda telah dinonaktifkan. Hubungi administrator.', 403);
}

// Jika viewer, resolve asn_id berdasarkan NIP
$asn_id  = null;
$asn_nip = null;
if ($user['role'] === 'viewer' && $user['nip']) {
    $s = $db->prepare("SELECT id, nip FROM asn WHERE nip = ? LIMIT 1");
    $s->bind_param('s', $user['nip']);
    $s->execute();
    $asn_row = $s->get_result()->fetch_assoc();
    $s->close();
    if ($asn_row) {
        $asn_id  = (int)$asn_row['id'];
        $asn_nip = $asn_row['nip'];
    }
}

session_regenerate_id(true);

$_SESSION['user_id']       = (int)$user['id'];
$_SESSION['username']      = $user['username'];
$_SESSION['nama']          = $user['nama'];
$_SESSION['role']          = $user['role'];
$_SESSION['nip']           = $user['nip'] ?? null;
$_SESSION['asn_id']        = $asn_id;    // null jika bukan viewer atau NIP tidak cocok
$_SESSION['last_activity'] = time();

writeAudit('login', 'auth', (int)$user['id'], 'Login berhasil');

responseSuccess('Login berhasil.', [
    'user_id'  => (int)$user['id'],
    'username' => $user['username'],
    'nama'     => $user['nama'],
    'role'     => $user['role'],
    'nip'      => $user['nip'] ?? null,
    'asn_id'   => $asn_id,
]);
