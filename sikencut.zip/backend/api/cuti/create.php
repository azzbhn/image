<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);
$user = requireRole(['administrator', 'operator']);

$body   = getBody();
$errors = validateRequired($body, ['asn_id','jenis_cuti_id','tanggal_mulai','tanggal_selesai','jumlah_hari']);
if ($errors) responseError(implode(' ', $errors));

$asn_id    = (int)($body['asn_id']                  ?? 0);
$jenis_id  = (int)($body['jenis_cuti_id']            ?? 0);
$tgl_mulai = sanitizeString($body['tanggal_mulai']   ?? '');
$tgl_sel   = sanitizeString($body['tanggal_selesai'] ?? '');
$jml_hari  = (int)($body['jumlah_hari']              ?? 0);
$alasan    = sanitizeString($body['alasan']           ?? '');
$alamat    = sanitizeString($body['alamat_selama_cuti'] ?? '');
$catatan   = sanitizeString($body['catatan']          ?? '');
$status    = sanitizeString($body['status']           ?? 'Disetujui');

if (!validateDate($tgl_mulai) || !validateDate($tgl_sel))
    responseError('Format tanggal tidak valid.');
if (strtotime($tgl_sel) < strtotime($tgl_mulai))
    responseError('Tanggal selesai tidak boleh lebih awal dari tanggal mulai.');
if ($jml_hari < 1) responseError('Jumlah hari harus minimal 1.');

$tahun = (int)date('Y', strtotime($tgl_mulai));
$uid   = $user['user_id'];
$db    = getDB();

// ── Validasi ASN ──────────────────────────────────────────
$s = $db->prepare("SELECT id, nama, jenis_asn, status_asn FROM asn WHERE id = ? LIMIT 1");
$s->bind_param('i', $asn_id); $s->execute();
$asn = $s->get_result()->fetch_assoc(); $s->close();
if (!$asn) responseError('Data ASN tidak ditemukan.', 404);
if ($asn['status_asn'] !== 'Aktif')
    responseError('ASN dengan status non-Aktif tidak dapat mengajukan cuti.');

// ── Validasi jenis cuti ───────────────────────────────────
$s = $db->prepare(
    "SELECT id, kode, nama, untuk_pns, untuk_pppk, untuk_pppk_pw, is_tahunan
     FROM jenis_cuti WHERE id = ? LIMIT 1"
);
$s->bind_param('i', $jenis_id); $s->execute();
$jenis = $s->get_result()->fetch_assoc(); $s->close();
if (!$jenis) responseError('Jenis cuti tidak ditemukan.');

if ($asn['jenis_asn'] === 'PNS'     && !$jenis['untuk_pns'])
    responseError('Jenis cuti ini tidak tersedia untuk PNS.');
if ($asn['jenis_asn'] === 'PPPK'    && !$jenis['untuk_pppk'])
    responseError("Jenis cuti '{$jenis['nama']}' tidak tersedia untuk PPPK.");
if ($asn['jenis_asn'] === 'PPPK PW' && !$jenis['untuk_pppk_pw'])
    responseError("Jenis cuti '{$jenis['nama']}' tidak tersedia untuk PPPK Paruh Waktu.");

$db->begin_transaction();
try {
    // ── Cuti tahunan: validasi + update HANYA terpakai ───
    if ($jenis['is_tahunan'] && $status === 'Disetujui') {
        $saldo = getSaldoOrCreate($db, $asn_id, $tahun);

        // Lock row
        $sl = $db->prepare(
            "SELECT id FROM saldo_cuti_tahunan WHERE asn_id=? AND tahun=? FOR UPDATE"
        );
        $sl->bind_param('ii', $asn_id, $tahun); $sl->execute(); $sl->close();

        // Validasi saldo mencukupi
        $err = validasiSaldo(
            (int)$saldo['hak_tahun_ini'],
            (int)$saldo['sisa_n1'],
            (int)$saldo['sisa_n2'],
            (int)$saldo['terpakai'],
            $jml_hari
        );
        if ($err) { $db->rollback(); responseError($err); }

        // Hanya tambah terpakai — TIDAK sentuh hak/n1/n2
        tambahTerpakai($db, (int)$saldo['id'], $jml_hari);
    }

    // ── Insert record cuti ────────────────────────────────
    $stmt = $db->prepare(
        "INSERT INTO cuti
             (asn_id,jenis_cuti_id,tanggal_mulai,tanggal_selesai,
              jumlah_hari,tahun,alasan,alamat_selama_cuti,catatan,status,created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)"
    );
    $stmt->bind_param(
        'iisssissssi',
        $asn_id,$jenis_id,$tgl_mulai,$tgl_sel,
        $jml_hari,$tahun,$alasan,$alamat,$catatan,$status,$uid
    );
    $stmt->execute();
    $new_id = (int)$db->insert_id;
    $stmt->close();

    $db->commit();
} catch (Throwable $e) {
    $db->rollback();
    error_log('[SIKENCUT] Cuti create error: ' . $e->getMessage());
    responseError('Gagal menyimpan data cuti. Silakan coba lagi.', 500);
}

writeAudit('input_cuti', 'cuti', $new_id,
    "Input cuti {$jenis['nama']} untuk {$asn['nama']} ({$jml_hari} hari)");
responseSuccess('Data cuti berhasil disimpan.', ['id' => $new_id], 201);
