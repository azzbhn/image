<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
$user = requireAuth();

$db = getDB();

$page      = max(1, (int)($_GET['page']     ?? 1));
$per_page  = min(100, max(5, (int)($_GET['per_page'] ?? 15)));
$offset    = ($page - 1) * $per_page;
$jenis_id  = (int)($_GET['jenis_cuti_id'] ?? 0);
$tahun     = (int)($_GET['tahun']          ?? 0);
$status    = sanitizeString($_GET['status'] ?? '');
$search    = sanitizeString($_GET['q']     ?? '');

// Viewer hanya boleh lihat cuti miliknya sendiri
$viewer_asn = getViewerAsnId();
$asn_id     = $viewer_asn ?? (int)($_GET['asn_id'] ?? 0);

$where = []; $params = []; $types = '';

if ($asn_id) {
    $where[] = 'c.asn_id = ?'; $params[] = $asn_id; $types .= 'i';
}
if ($jenis_id) {
    $where[] = 'c.jenis_cuti_id = ?'; $params[] = $jenis_id; $types .= 'i';
}
if ($tahun) {
    $where[] = 'c.tahun = ?'; $params[] = $tahun; $types .= 'i';
}
if ($status) {
    $where[] = 'c.status = ?'; $params[] = $status; $types .= 's';
}
if ($search && !$viewer_asn) {
    $like = "%$search%";
    $where[] = '(a.nama LIKE ? OR a.nip LIKE ?)';
    $params  = array_merge($params, [$like, $like]); $types .= 'ss';
}

$sql_where = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$stmt_c = $db->prepare("SELECT COUNT(*) AS total FROM cuti c JOIN asn a ON a.id=c.asn_id $sql_where");
if ($types) $stmt_c->bind_param($types, ...$params);
$stmt_c->execute();
$total = (int)$stmt_c->get_result()->fetch_assoc()['total'];
$stmt_c->close();

$stmt = $db->prepare(
    "SELECT c.id, c.asn_id, a.nip, a.nama, a.unit_kerja, a.jenis_asn,
            j.kode AS jenis_cuti_kode, j.nama AS jenis_cuti_nama,
            c.tanggal_mulai, c.tanggal_selesai, c.jumlah_hari, c.tahun,
            c.alasan, c.status, c.catatan, c.created_at,
            u.nama AS created_by_nama
     FROM cuti c
     JOIN asn a ON a.id = c.asn_id
     JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     LEFT JOIN users u ON u.id = c.created_by
     $sql_where
     ORDER BY c.tanggal_mulai DESC
     LIMIT ? OFFSET ?"
);
$types_f  = $types . 'ii';
$params_f = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types_f, ...$params_f);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

responsePaginated('OK', $rows, $total, $page, $per_page);
