<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$jenis_asn = sanitizeString($_GET['jenis_asn'] ?? '');
$db = getDB();

if ($jenis_asn === 'PNS') {
    $stmt = $db->prepare("SELECT * FROM jenis_cuti WHERE untuk_pns=1 ORDER BY id");
} elseif ($jenis_asn === 'PPPK') {
    $stmt = $db->prepare("SELECT * FROM jenis_cuti WHERE untuk_pppk=1 ORDER BY id");
} elseif ($jenis_asn === 'PPPK PW') {
    $stmt = $db->prepare("SELECT * FROM jenis_cuti WHERE untuk_pppk_pw=1 ORDER BY id");
} else {
    $stmt = $db->prepare("SELECT * FROM jenis_cuti ORDER BY id");
}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

responseSuccess('OK', $rows);
