<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
$user = requireAuth();

$db    = getDB();
$tahun = (int)($_GET['tahun'] ?? date('Y'));

$viewer_asn = getViewerAsnId();
$asn_id     = $viewer_asn ?? (int)($_GET['asn_id'] ?? 0);
if (!$asn_id) responseError('Parameter asn_id wajib diisi.');

// Ambil atau buat saldo + kalkulasi otomatis
$saldo = getSaldoOrCreate($db, $asn_id, $tahun);

// Riwayat cuti tahunan tahun tersebut
$stmt2 = $db->prepare(
    "SELECT c.id, c.tanggal_mulai, c.tanggal_selesai, c.jumlah_hari,
            c.status, c.alasan, c.created_at
     FROM cuti c
     JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.asn_id = ? AND c.tahun = ? AND j.is_tahunan = 1
     ORDER BY c.tanggal_mulai DESC"
);
$stmt2->bind_param('ii', $asn_id, $tahun);
$stmt2->execute();
$riwayat = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt2->close();

// Response dengan data referensi + kalkulasi dipisah
$k = $saldo['kalkulasi'];
responseSuccess('OK', [
    'referensi' => [
        'hak_tahun_ini' => (int)$saldo['hak_tahun_ini'],
        'sisa_n1'       => (int)$saldo['sisa_n1'],
        'sisa_n2'       => (int)$saldo['sisa_n2'],
        'total_hak'     => $k['total_hak'],
    ],
    'transaksi' => [
        'terpakai' => $k['terpakai'],
    ],
    'kalkulasi' => [
        'sisa_total'  => $k['sisa_total'],
        'n2_tersisa'  => $k['n2_tersisa'],
        'n1_tersisa'  => $k['n1_tersisa'],
        'n_tersisa'   => $k['n_tersisa'],
    ],
    'saldo_id' => (int)$saldo['id'],
    'tahun'    => $tahun,
    'riwayat'  => $riwayat,
]);
