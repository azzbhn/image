<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$db    = getDB();
$bulan = (int)($_GET['bulan'] ?? date('n'));
$tahun = (int)($_GET['tahun'] ?? date('Y'));

if ($bulan < 1 || $bulan > 12) responseError('Bulan tidak valid.');

$tgl_awal = sprintf('%04d-%02d-01', $tahun, $bulan);
$tgl_akhir = date('Y-m-t', strtotime($tgl_awal));

$stmt = $db->prepare(
    "SELECT c.id, c.tanggal_mulai, c.tanggal_selesai, c.jumlah_hari, c.status,
            a.id as asn_id, a.nama, a.nip, a.unit_kerja, a.jenis_asn,
            j.kode as jenis_kode, j.nama as jenis_nama
     FROM cuti c
     JOIN asn a ON a.id = c.asn_id
     JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.status = 'Disetujui'
       AND c.tanggal_mulai <= ? AND c.tanggal_selesai >= ?
     ORDER BY c.tanggal_mulai ASC"
);
$stmt->bind_param('ss', $tgl_akhir, $tgl_awal);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Bangun event kalender per hari
$days_in_month = (int)date('t', strtotime($tgl_awal));
$calendar = [];
for ($d = 1; $d <= $days_in_month; $d++) {
    $tanggal = sprintf('%04d-%02d-%02d', $tahun, $bulan, $d);
    $calendar[$tanggal] = [];
}

foreach ($rows as $cuti) {
    $cur = $cuti['tanggal_mulai'];
    $end = $cuti['tanggal_selesai'];
    while ($cur <= $end) {
        if (isset($calendar[$cur])) {
            $calendar[$cur][] = [
                'id'         => $cuti['id'],
                'asn_id'     => $cuti['asn_id'],
                'nama'       => $cuti['nama'],
                'nip'        => $cuti['nip'],
                'unit_kerja' => $cuti['unit_kerja'],
                'jenis_kode' => $cuti['jenis_kode'],
                'jenis_nama' => $cuti['jenis_nama'],
            ];
        }
        $cur = date('Y-m-d', strtotime($cur . ' +1 day'));
    }
}

responseSuccess('OK', [
    'bulan'    => $bulan,
    'tahun'    => $tahun,
    'calendar' => $calendar,
    'cuti'     => $rows,
]);
