<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['DELETE','POST']);
$user = requireRole(['administrator']);

$body = getBody();
$id   = (int)($body['id'] ?? $_GET['id'] ?? 0);
if (!$id) responseError('ID cuti tidak valid.');

$db = getDB();
$s  = $db->prepare(
    "SELECT c.*, j.is_tahunan FROM cuti c
     JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.id = ? LIMIT 1"
);
$s->bind_param('i', $id); $s->execute();
$cuti = $s->get_result()->fetch_assoc(); $s->close();
if (!$cuti) responseError('Data cuti tidak ditemukan.', 404);

$db->begin_transaction();
try {
    // ── Kembalikan terpakai jika cuti tahunan + Disetujui ─
    // Hanya mengurangi terpakai. TIDAK mengubah hak/n1/n2.
    if ($cuti['is_tahunan'] && $cuti['status'] === 'Disetujui') {
        $asn_id = (int)$cuti['asn_id'];
        $tahun  = (int)$cuti['tahun'];
        $hari   = (int)$cuti['jumlah_hari'];

        $saldo = getSaldoOrCreate($db, $asn_id, $tahun);
        kurangiTerpakai($db, (int)$saldo['id'], $hari);
    }

    $s = $db->prepare("DELETE FROM cuti WHERE id = ?");
    $s->bind_param('i', $id); $s->execute(); $s->close();

    $db->commit();
} catch (Throwable $e) {
    $db->rollback();
    error_log('[SIKENCUT] Cuti delete error: ' . $e->getMessage());
    responseError('Gagal menghapus data cuti.', 500);
}

writeAudit('hapus_cuti', 'cuti', $id, "Hapus cuti ID $id");
responseSuccess('Data cuti berhasil dihapus.');
