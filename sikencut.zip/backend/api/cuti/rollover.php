<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['POST']);
requireRole(['administrator']);

$body      = getBody();
$tahun_baru = (int)($body['tahun'] ?? date('Y'));

if ($tahun_baru < 2020 || $tahun_baru > 2100) {
    responseError('Tahun tidak valid.');
}

$db = getDB();

// Panggil stored procedure
$stmt = $db->prepare("CALL sp_rollover_tahunan(?)");
$stmt->bind_param('i', $tahun_baru);
$stmt->execute();
$stmt->close();

writeAudit('rollover_cuti', 'cuti', null, "Rollover saldo cuti tahunan ke tahun $tahun_baru");
responseSuccess("Rollover saldo cuti tahunan ke tahun $tahun_baru berhasil dilakukan.");
