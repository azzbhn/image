<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['PUT','POST']);
$user = requireRole(['administrator', 'operator']);

$body = getBody();
$id   = (int)($body['id'] ?? $_GET['id'] ?? 0);
if (!$id) responseError('ID cuti tidak valid.');

$errors = validateRequired($body, ['tanggal_mulai','tanggal_selesai','jumlah_hari']);
if ($errors) responseError(implode(' ', $errors));

$tgl_mulai = sanitizeString($body['tanggal_mulai']       ?? '');
$tgl_sel   = sanitizeString($body['tanggal_selesai']     ?? '');
$jml_hari  = (int)($body['jumlah_hari']                  ?? 0);
$alasan    = sanitizeString($body['alasan']               ?? '');
$alamat    = sanitizeString($body['alamat_selama_cuti']   ?? '');
$catatan   = sanitizeString($body['catatan']              ?? '');
$status    = sanitizeString($body['status']               ?? 'Disetujui');

if (!validateDate($tgl_mulai) || !validateDate($tgl_sel))
    responseError('Format tanggal tidak valid.');
if ($jml_hari < 1) responseError('Jumlah hari harus minimal 1.');

$db  = getDB();
$uid = $user['user_id'];

// ── Ambil data cuti lama ──────────────────────────────────
$s = $db->prepare(
    "SELECT c.*, j.is_tahunan FROM cuti c
     JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
     WHERE c.id = ? LIMIT 1"
);
$s->bind_param('i', $id); $s->execute();
$old = $s->get_result()->fetch_assoc(); $s->close();
if (!$old) responseError('Data cuti tidak ditemukan.', 404);

$db->begin_transaction();
try {
    // ── Rekonsiliasi terpakai untuk cuti tahunan ──────────
    if ($old['is_tahunan']) {
        $asn_id     = (int)$old['asn_id'];
        $tahun_lama = (int)$old['tahun'];
        $hari_lama  = (int)$old['jumlah_hari'];
        $hari_baru  = $jml_hari;
        $tahun_baru = (int)date('Y', strtotime($tgl_mulai));

        // Status lama
        $status_lama     = $old['status'];
        $lama_disetujui  = ($status_lama === 'Disetujui');
        $baru_disetujui  = ($status === 'Disetujui');

        if ($tahun_lama === $tahun_baru) {
            // Tahun sama — hanya sesuaikan selisih terpakai
            $saldo = getSaldoOrCreate($db, $asn_id, $tahun_lama);
            $sl = $db->prepare(
                "SELECT id FROM saldo_cuti_tahunan WHERE asn_id=? AND tahun=? FOR UPDATE"
            );
            $sl->bind_param('ii', $asn_id, $tahun_lama); $sl->execute(); $sl->close();

            if ($lama_disetujui && $baru_disetujui) {
                // Kedua disetujui: sesuaikan selisih
                $selisih = $hari_baru - $hari_lama;
                if ($selisih > 0) {
                    // Tambah — validasi dulu
                    $err = validasiSaldo(
                        (int)$saldo['hak_tahun_ini'],
                        (int)$saldo['sisa_n1'],
                        (int)$saldo['sisa_n2'],
                        (int)$saldo['terpakai'],
                        $selisih
                    );
                    if ($err) { $db->rollback(); responseError($err); }
                    tambahTerpakai($db, (int)$saldo['id'], $selisih);
                } elseif ($selisih < 0) {
                    kurangiTerpakai($db, (int)$saldo['id'], abs($selisih));
                }
            } elseif ($lama_disetujui && !$baru_disetujui) {
                // Dari disetujui ke tidak — kembalikan saldo
                kurangiTerpakai($db, (int)$saldo['id'], $hari_lama);
            } elseif (!$lama_disetujui && $baru_disetujui) {
                // Dari tidak ke disetujui — kurangi saldo
                $err = validasiSaldo(
                    (int)$saldo['hak_tahun_ini'],
                    (int)$saldo['sisa_n1'],
                    (int)$saldo['sisa_n2'],
                    (int)$saldo['terpakai'],
                    $hari_baru
                );
                if ($err) { $db->rollback(); responseError($err); }
                tambahTerpakai($db, (int)$saldo['id'], $hari_baru);
            }
            // else: keduanya tidak disetujui → tidak ada perubahan saldo
        } else {
            // Tahun berbeda — kembalikan saldo tahun lama, kurangi tahun baru
            if ($lama_disetujui) {
                $saldo_lama = getSaldoOrCreate($db, $asn_id, $tahun_lama);
                kurangiTerpakai($db, (int)$saldo_lama['id'], $hari_lama);
            }
            if ($baru_disetujui) {
                $saldo_baru = getSaldoOrCreate($db, $asn_id, $tahun_baru);
                $err = validasiSaldo(
                    (int)$saldo_baru['hak_tahun_ini'],
                    (int)$saldo_baru['sisa_n1'],
                    (int)$saldo_baru['sisa_n2'],
                    (int)$saldo_baru['terpakai'],
                    $hari_baru
                );
                if ($err) { $db->rollback(); responseError($err); }
                tambahTerpakai($db, (int)$saldo_baru['id'], $hari_baru);
            }
        }
    }

    // ── Update record cuti ────────────────────────────────
    $stmt = $db->prepare(
        "UPDATE cuti
         SET tanggal_mulai=?, tanggal_selesai=?, jumlah_hari=?,
             tahun=YEAR(?), alasan=?, alamat_selama_cuti=?,
             catatan=?, status=?, updated_by=?
         WHERE id=?"
    );
    $stmt->bind_param(
        'sssissssii',
        $tgl_mulai,$tgl_sel,$jml_hari,$tgl_mulai,
        $alasan,$alamat,$catatan,$status,$uid,$id
    );
    $stmt->execute(); $stmt->close();

    $db->commit();
} catch (Throwable $e) {
    $db->rollback();
    error_log('[SIKENCUT] Cuti update error: ' . $e->getMessage());
    responseError('Gagal memperbarui data cuti.', 500);
}

writeAudit('edit_cuti', 'cuti', $id, "Edit cuti ID $id");
responseSuccess('Data cuti berhasil diperbarui.');
