<?php
require_once __DIR__ . '/../../bootstrap.php';
allowMethods(['GET']);
requireAuth();

$db    = getDB();
$jenis = sanitizeString($_GET['jenis']  ?? 'rekap_tahunan'); // rekap_tahunan | semua | per_asn | per_jenis | belum_cuti | sisa_minim
$tahun = (int)($_GET['tahun']  ?? date('Y'));
$asn_id= (int)($_GET['asn_id'] ?? 0);

writeAudit('cetak_laporan', 'laporan', null, "Cetak laporan: $jenis tahun $tahun");

switch ($jenis) {

    case 'rekap_tahunan':
        $stmt = $db->prepare(
            "SELECT a.nip, a.nama, a.jenis_asn, a.unit_kerja,
                    s.hak_tahun_ini, s.sisa_n1, s.sisa_n2,
                    (s.hak_tahun_ini+s.sisa_n1+s.sisa_n2) as total_hak,
                    s.terpakai,
                    (s.hak_tahun_ini+s.sisa_n1+s.sisa_n2-s.terpakai) as sisa_total
             FROM saldo_cuti_tahunan s JOIN asn a ON a.id=s.asn_id
             WHERE s.tahun=? AND a.status_asn='Aktif'
             ORDER BY a.nama ASC"
        );
        $stmt->bind_param('i', $tahun);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        responseSuccess('OK', $rows);
        break;

    case 'semua':
        $stmt = $db->prepare(
            "SELECT c.id, a.nip, a.nama, a.jenis_asn, a.unit_kerja,
                    j.nama as jenis_cuti, c.tanggal_mulai, c.tanggal_selesai,
                    c.jumlah_hari, c.tahun, c.status, c.alasan
             FROM cuti c JOIN asn a ON a.id=c.asn_id JOIN jenis_cuti j ON j.id=c.jenis_cuti_id
             WHERE c.tahun=? ORDER BY a.nama, c.tanggal_mulai"
        );
        $stmt->bind_param('i', $tahun);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        responseSuccess('OK', $rows);
        break;

    case 'per_asn':
        if (!$asn_id) responseError('Parameter asn_id wajib untuk laporan per ASN.');
        $stmt = $db->prepare(
            "SELECT c.id, j.nama as jenis_cuti, c.tanggal_mulai, c.tanggal_selesai,
                    c.jumlah_hari, c.tahun, c.status, c.alasan, c.created_at
             FROM cuti c JOIN jenis_cuti j ON j.id=c.jenis_cuti_id
             WHERE c.asn_id=?
             ORDER BY c.tahun DESC, c.tanggal_mulai DESC"
        );
        $stmt->bind_param('i', $asn_id);
        $stmt->execute();
        $cuti = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // ASN info
        $s = $db->prepare("SELECT * FROM asn WHERE id=? LIMIT 1");
        $s->bind_param('i', $asn_id);
        $s->execute();
        $asn = $s->get_result()->fetch_assoc();
        $s->close();

        responseSuccess('OK', ['asn' => $asn, 'cuti' => $cuti]);
        break;

    case 'per_jenis':
        $stmt = $db->prepare(
            "SELECT j.kode, j.nama as jenis_cuti,
                    COUNT(*) as total_penggunaan, SUM(c.jumlah_hari) as total_hari,
                    COUNT(DISTINCT c.asn_id) as total_asn
             FROM cuti c JOIN jenis_cuti j ON j.id=c.jenis_cuti_id
             WHERE c.tahun=? AND c.status='Disetujui'
             GROUP BY j.id ORDER BY total_hari DESC"
        );
        $stmt->bind_param('i', $tahun);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        responseSuccess('OK', $rows);
        break;

    case 'per_tahun':
        $stmt = $db->query(
            "SELECT c.tahun,
                    COUNT(*) as total_penggunaan,
                    SUM(c.jumlah_hari) as total_hari,
                    COUNT(DISTINCT c.asn_id) as total_asn
             FROM cuti c WHERE c.status='Disetujui'
             GROUP BY c.tahun ORDER BY c.tahun DESC LIMIT 10"
        );
        responseSuccess('OK', $stmt->fetch_all(MYSQLI_ASSOC));
        break;

    case 'belum_cuti':
        $stmt = $db->prepare(
            "SELECT a.nip, a.nama, a.jenis_asn, a.unit_kerja,
                    COALESCE(s.hak_tahun_ini,12) as hak_tahun_ini
             FROM asn a
             LEFT JOIN saldo_cuti_tahunan s ON s.asn_id=a.id AND s.tahun=?
             WHERE a.status_asn='Aktif'
               AND (s.terpakai IS NULL OR s.terpakai=0)
             ORDER BY a.nama ASC"
        );
        $stmt->bind_param('i', $tahun);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        responseSuccess('OK', $rows);
        break;

    case 'sisa_minim':
        $batas = (int)($_GET['batas'] ?? 3);
        $stmt  = $db->prepare(
            "SELECT v.nip, v.nama, v.jenis_asn, v.unit_kerja,
                    v.total_hak, v.terpakai, v.sisa_total
             FROM v_saldo_cuti v
             WHERE v.tahun=? AND v.sisa_total>=0 AND v.sisa_total<=?
             ORDER BY v.sisa_total ASC, v.nama ASC"
        );
        $stmt->bind_param('ii', $tahun, $batas);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        responseSuccess('OK', $rows);
        break;

    default:
        responseError('Jenis laporan tidak dikenal.');
}
