<?php
// ============================================================
// helpers/response.php
// Helper untuk output JSON konsisten
// ============================================================

function responseSuccess(string $message, $data = null, int $code = 200): void {
    http_response_code($code);
    echo json_encode([
        'status'  => true,
        'message' => $message,
        'data'    => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function responseError(string $message, int $code = 400, $data = null): void {
    http_response_code($code);
    echo json_encode([
        'status'  => false,
        'message' => $message,
        'data'    => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function responsePaginated(string $message, array $rows, int $total, int $page, int $per_page): void {
    http_response_code(200);
    echo json_encode([
        'status'      => true,
        'message'     => $message,
        'data'        => $rows,
        'pagination'  => [
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'last_page'=> (int) ceil($total / $per_page),
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
