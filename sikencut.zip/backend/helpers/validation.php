<?php
// ============================================================
// helpers/validation.php
// Helper validasi input
// ============================================================

function sanitizeString(?string $val): string {
    return htmlspecialchars(trim((string)$val), ENT_QUOTES, 'UTF-8');
}

function validateRequired(array $data, array $fields): array {
    $errors = [];
    foreach ($fields as $field) {
        if (!isset($data[$field]) || trim((string)$data[$field]) === '') {
            $errors[] = "Field '$field' wajib diisi.";
        }
    }
    return $errors;
}

function validateEmail(?string $email): bool {
    return filter_var(trim((string)$email), FILTER_VALIDATE_EMAIL) !== false;
}

function validateDate(?string $date): bool {
    if (!$date) return false;
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

function getBody(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        // Fallback ke POST
        return $_POST ?: [];
    }
    return $data ?: [];
}

function getMethod(): string {
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

function allowMethods(array $methods): void {
    if (!in_array(getMethod(), $methods, true)) {
        responseError('Method tidak diizinkan.', 405);
    }
}
