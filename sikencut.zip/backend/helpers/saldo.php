<?php
// ============================================================
// helpers/saldo.php
//
// ARSITEKTUR SALDO CUTI TAHUNAN:
//
//   DATA REFERENSI  (tidak pernah berubah akibat transaksi cuti):
//     hak_tahun_ini  = hak cuti tahun berjalan (default 12)
//     sisa_n1        = carry forward dari tahun lalu (maks 6)
//     sisa_n2        = carry forward dari 2 tahun lalu (maks 6)
//
//   DATA TRANSAKSI  (berubah setiap ada cuti tahunan):
//     terpakai       = total hari cuti tahunan yang disetujui
//
//   DATA KALKULASI  (dihitung, tidak disimpan):
//     saldo_tersisa  = (hak + n1 + n2) - terpakai
//     breakdown_n2_tersisa, n1_tersisa, n_tersisa
//
// URUTAN PENGURANGAN: N-2 → N-1 → N (tahun berjalan)
// ============================================================

/**
 * Hitung breakdown saldo tersisa berdasarkan referensi + terpakai.
 *
 * @param int $hak       hak_tahun_ini (referensi N)
 * @param int $n1        sisa_n1 (referensi N-1)
 * @param int $n2        sisa_n2 (referensi N-2)
 * @param int $terpakai  total hari yang sudah dipakai (dari tabel cuti)
 *
 * @return array {
 *   total_hak: int,     // hak + n1 + n2
 *   terpakai:  int,     // sama dengan input
 *   sisa_total: int,    // total_hak - terpakai
 *   n2_tersisa: int,    // sisa dari pool N-2
 *   n1_tersisa: int,    // sisa dari pool N-1
 *   n_tersisa:  int,    // sisa dari pool N
 * }
 */
function hitungSaldo(int $hak, int $n1, int $n2, int $terpakai): array {
    $total_hak  = $hak + $n1 + $n2;
    $sisa_total = max(0, $total_hak - $terpakai);
    $sisa_hari  = $terpakai; // hari yang akan "dikurangi" dari pool

    // Kurangi dari N-2 dahulu
    $kurang_n2  = min($n2, $sisa_hari);
    $sisa_hari -= $kurang_n2;
    $n2_tersisa = $n2 - $kurang_n2;

    // Lalu N-1
    $kurang_n1  = min($n1, $sisa_hari);
    $sisa_hari -= $kurang_n1;
    $n1_tersisa = $n1 - $kurang_n1;

    // Sisanya dari N (hak tahun berjalan)
    $kurang_n   = min($hak, $sisa_hari);
    $n_tersisa  = $hak - $kurang_n;

    return [
        'total_hak'   => $total_hak,
        'terpakai'    => $terpakai,
        'sisa_total'  => $sisa_total,
        'n2_tersisa'  => $n2_tersisa,
        'n1_tersisa'  => $n1_tersisa,
        'n_tersisa'   => $n_tersisa,
    ];
}

/**
 * Validasi apakah hari yang diminta masih mencukupi saldo.
 * Return null jika ok, string error jika tidak.
 */
function validasiSaldo(int $hak, int $n1, int $n2, int $terpakai, int $hari_diminta): ?string {
    $saldo = hitungSaldo($hak, $n1, $n2, $terpakai);
    if ($hari_diminta > $saldo['sisa_total']) {
        return "Saldo cuti tahunan tidak mencukupi. "
             . "Sisa: {$saldo['sisa_total']} hari, "
             . "dibutuhkan: {$hari_diminta} hari.";
    }
    return null;
}

/**
 * Ambil saldo dari DB atau buat baru jika belum ada.
 * HANYA membaca dan membuat record, TIDAK pernah mengubah hak/n1/n2.
 */
function getSaldoOrCreate(mysqli $db, int $asn_id, int $tahun): array {
    $s = $db->prepare(
        "SELECT id, hak_tahun_ini, sisa_n1, sisa_n2, terpakai
         FROM saldo_cuti_tahunan
         WHERE asn_id = ? AND tahun = ?
         LIMIT 1"
    );
    $s->bind_param('ii', $asn_id, $tahun);
    $s->execute();
    $row = $s->get_result()->fetch_assoc();
    $s->close();

    if (!$row) {
        $ins = $db->prepare(
            "INSERT IGNORE INTO saldo_cuti_tahunan
             (asn_id, tahun, hak_tahun_ini, sisa_n1, sisa_n2, terpakai)
             VALUES (?, ?, 12, 0, 0, 0)"
        );
        $ins->bind_param('ii', $asn_id, $tahun);
        $ins->execute();
        $new_id = (int)$db->insert_id;
        $ins->close();
        $row = ['id' => $new_id, 'hak_tahun_ini' => 12, 'sisa_n1' => 0, 'sisa_n2' => 0, 'terpakai' => 0];
    }

    // Gabungkan dengan kalkulasi
    $row['kalkulasi'] = hitungSaldo(
        (int)$row['hak_tahun_ini'],
        (int)$row['sisa_n1'],
        (int)$row['sisa_n2'],
        (int)$row['terpakai']
    );

    return $row;
}

/**
 * Tambah terpakai (untuk create cuti).
 * TIDAK mengubah hak_tahun_ini / sisa_n1 / sisa_n2.
 */
function tambahTerpakai(mysqli $db, int $saldo_id, int $tambah): void {
    $s = $db->prepare(
        "UPDATE saldo_cuti_tahunan
         SET terpakai = GREATEST(0, terpakai + ?)
         WHERE id = ?"
    );
    $s->bind_param('ii', $tambah, $saldo_id);
    $s->execute();
    $s->close();
}

/**
 * Kurangi terpakai (untuk hapus/batal cuti).
 * TIDAK mengubah hak_tahun_ini / sisa_n1 / sisa_n2.
 */
function kurangiTerpakai(mysqli $db, int $saldo_id, int $kurang): void {
    $s = $db->prepare(
        "UPDATE saldo_cuti_tahunan
         SET terpakai = GREATEST(0, terpakai - ?)
         WHERE id = ?"
    );
    $s->bind_param('ii', $kurang, $saldo_id);
    $s->execute();
    $s->close();
}

/**
 * Recalculate terpakai dari tabel cuti (untuk repair / audit).
 * AMAN dijalankan kapanpun, tidak mengubah referensi.
 */
function recalcTerpakai(mysqli $db, int $asn_id, int $tahun): int {
    $s = $db->prepare(
        "SELECT COALESCE(SUM(c.jumlah_hari), 0) AS total
         FROM cuti c
         JOIN jenis_cuti j ON j.id = c.jenis_cuti_id
         WHERE c.asn_id = ? AND c.tahun = ?
           AND j.is_tahunan = 1
           AND c.status = 'Disetujui'"
    );
    $s->bind_param('ii', $asn_id, $tahun);
    $s->execute();
    $total = (int)$s->get_result()->fetch_assoc()['total'];
    $s->close();

    $upd = $db->prepare(
        "UPDATE saldo_cuti_tahunan SET terpakai = ?
         WHERE asn_id = ? AND tahun = ?"
    );
    $upd->bind_param('iii', $total, $asn_id, $tahun);
    $upd->execute();
    $upd->close();

    return $total;
}
