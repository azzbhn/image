<?php
// ============================================================
// helpers/audit.php
// Helper untuk menulis audit log
// ============================================================

function writeAudit(string $aksi, string $modul, ?int $target_id = null, ?string $keterangan = null): void {
    try {
        $db        = getDB();
        $user_id   = $_SESSION['user_id']   ?? null;
        $username  = $_SESSION['username']  ?? 'system';
        $ip        = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
        $ua        = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300);

        $stmt = $db->prepare(
            "INSERT INTO audit_log (user_id, username, aksi, modul, target_id, keterangan, ip_address, user_agent)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param('isssisss', $user_id, $username, $aksi, $modul, $target_id, $keterangan, $ip, $ua);
        $stmt->execute();
        $stmt->close();
    } catch (Throwable $e) {
        error_log('[SICUTI-AUDIT] ' . $e->getMessage());
    }
}
