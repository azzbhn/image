<?php
// ============================================================
// bootstrap.php
// Di-include oleh setiap endpoint API
// ============================================================

// Error reporting — matikan di production
if (getenv('APP_ENV') === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', __DIR__ . '/logs/php_error.log');
}

// Session config
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.use_strict_mode', '1');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', '1');
}

session_start();

// Load config
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';

// Load helpers
require_once __DIR__ . '/helpers/response.php';
require_once __DIR__ . '/helpers/validation.php';
require_once __DIR__ . '/helpers/audit.php';

// Load middlewares
require_once __DIR__ . '/middlewares/cors.php';
require_once __DIR__ . '/middlewares/auth.php';
require_once __DIR__ . '/helpers/saldo.php';
