<?php
// ============================================================
// config/database.php
// Konfigurasi koneksi database MySQLi
// ============================================================

define('DB_HOST',     getenv('DB_HOST')     ?: 'localhost');
define('DB_USER',     getenv('DB_USER')     ?: 'fgqqlzxt_sikencut_root');
define('DB_PASS',     getenv('DB_PASS')     ?: '');
define('DB_NAME',     getenv('DB_NAME')     ?: 'fgqqlzxt_sikencut_db');
define('DB_CHARSET',  'utf8mb4');

function getDB(): mysqli {
    static $conn = null;
    if ($conn !== null && $conn->ping()) {
        return $conn;
    }
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        error_log('[SICUTI-DB] Connection failed: ' . $conn->connect_error);
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['status' => false, 'message' => 'Koneksi database gagal.', 'data' => null]);
        exit;
    }
    $conn->set_charset(DB_CHARSET);
    return $conn;
}
