<?php
// ============================================================
// config/app.php
// Konfigurasi global aplikasi
// ============================================================

define('APP_NAME',    'SICUTI');
define('APP_VERSION', '1.0.0');
define('APP_ENV',     getenv('APP_ENV') ?: 'production');

// Allowed CORS origin — sesuaikan dengan domain frontend
define('CORS_ORIGIN', getenv('CORS_ORIGIN') ?: 'https://sikencut.ajb.my.id');

// Session lifetime (detik) — 8 jam
define('SESSION_LIFETIME', 28800);

// Timezone
date_default_timezone_set('Asia/Jakarta');
