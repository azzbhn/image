import{r as e,t}from"./rolldown-runtime-QTnfLwEv.js";import{g as n,m as r}from"./charts-VsLNPVad.js";var i=e(n(),1),a=e=>typeof e==`number`&&!isNaN(e),o=e=>typeof e==`string`,s=e=>typeof e==`function`,c=e=>o(e)||a(e),l=e=>o(e)||s(e)?e:null,u=(e,t)=>e===!1||a(e)&&e>0?e:t,d=e=>(0,i.isValidElement)(e)||o(e)||s(e)||a(e);function f(e,t,n=300){let{scrollHeight:r,style:i}=e;requestAnimationFrame(()=>{i.minHeight=`initial`,i.height=r+`px`,i.transition=`all ${n}ms`,requestAnimationFrame(()=>{i.height=`0`,i.padding=`0`,i.margin=`0`,setTimeout(t,n)})})}function p({enter:e,exit:t,appendPosition:n=!1,collapse:r=!0,collapseDuration:a=300}){return function({children:o,position:s,preventExitTransition:c,done:l,nodeRef:u,isIn:d,playToast:p}){let m=n?`${e}--${s}`:e,h=n?`${t}--${s}`:t,g=(0,i.useRef)(0);return(0,i.useLayoutEffect)(()=>{let e=u.current,t=m.split(` `),n=r=>{r.target===u.current&&(p(),e.removeEventListener(`animationend`,n),e.removeEventListener(`animationcancel`,n),g.current===0&&r.type!==`animationcancel`&&e.classList.remove(...t))};e.classList.add(...t),e.addEventListener(`animationend`,n),e.addEventListener(`animationcancel`,n)},[]),(0,i.useEffect)(()=>{let e=u.current,t=()=>{e.removeEventListener(`animationend`,t),r?f(e,l,a):l()};d||(c?t():(g.current=1,e.className+=` ${h}`,e.addEventListener(`animationend`,t)))},[d]),i.createElement(i.Fragment,null,o)}}function m(e,t){return{content:h(e.content,e.props),containerId:e.props.containerId,id:e.props.toastId,theme:e.props.theme,type:e.props.type,data:e.props.data||{},isLoading:e.props.isLoading,icon:e.props.icon,reason:e.removalReason,status:t}}function h(e,t,n=!1){return(0,i.isValidElement)(e)&&!o(e.type)?(0,i.cloneElement)(e,{closeToast:t.closeToast,toastProps:t,data:t.data,isPaused:n}):s(e)?e({closeToast:t.closeToast,toastProps:t,data:t.data,isPaused:n}):e}function g({closeToast:e,theme:t,ariaLabel:n=`close`}){return i.createElement(`button`,{className:`Toastify__close-button Toastify__close-button--${t}`,type:`button`,onClick:t=>{t.stopPropagation(),e(!0)},"aria-label":n},i.createElement(`svg`,{"aria-hidden":`true`,viewBox:`0 0 14 16`},i.createElement(`path`,{fillRule:`evenodd`,d:`M7.71 8.23l3.75 3.75-1.48 1.48-3.75-3.75-3.75 3.75L1 11.98l3.75-3.75L1 4.48 2.48 3l3.75 3.75L9.98 3l1.48 1.48-3.75 3.75z`})))}function _({delay:e,isRunning:t,closeToast:n,type:a=`default`,hide:o,className:c,controlledProgress:l,progress:u,rtl:d,isIn:f,theme:p}){let m=o||l&&u===0,h={animationDuration:`${e}ms`,animationPlayState:t?`running`:`paused`};l&&(h.transform=`scaleX(${u})`);let g=r(`Toastify__progress-bar`,l?`Toastify__progress-bar--controlled`:`Toastify__progress-bar--animated`,`Toastify__progress-bar-theme--${p}`,`Toastify__progress-bar--${a}`,{"Toastify__progress-bar--rtl":d}),_=s(c)?c({rtl:d,type:a,defaultClassName:g}):r(g,c),v={[l&&u>=1?`onTransitionEnd`:`onAnimationEnd`]:l&&u<1?null:()=>{f&&n()}};return i.createElement(`div`,{className:`Toastify__progress-bar--wrp`,"data-hidden":m},i.createElement(`div`,{className:`Toastify__progress-bar--bg Toastify__progress-bar-theme--${p} Toastify__progress-bar--${a}`}),i.createElement(`div`,{role:`progressbar`,"aria-hidden":m?`true`:`false`,"aria-label":`notification timer`,"aria-valuenow":l?Math.round(u*100):void 0,"aria-valuemin":0,"aria-valuemax":100,className:_,style:h,...v}))}var v=1,y=()=>`${v++}`;function b(e,t,n){let r=1,i=0,o=[],s=[],c=t,f=new Map,p=new Set,h=e=>(p.add(e),()=>p.delete(e)),g=()=>{s=Array.from(f.values()),p.forEach(e=>e())},_=({containerId:t,toastId:n,updateId:r})=>{let i=t?t!==e:e!==1,a=f.has(n)&&r==null;return i||a},v=(e,t)=>{f.forEach(n=>{var r;(t==null||t===n.props.toastId)&&((r=n.toggle)==null||r.call(n,e))})},y=e=>{var t,r;e.isActive&&((r=(t=e.props)?.onClose)==null||r.call(t,e.removalReason),e.isActive=!1,n(m(e,`removed`)))},b=e=>{if(e==null)f.forEach(y);else{let t=f.get(e);t&&y(t)}g()},x=()=>{i-=o.length,o=[]},S=e=>{var t,r;let{toastId:i,updateId:a}=e.props,o=a==null;e.staleId&&f.delete(e.staleId),e.isActive=!0,f.set(i,e),g(),n(m(e,o?`added`:`updated`)),o&&((r=(t=e.props).onOpen)==null||r.call(t))};return{id:e,props:c,observe:h,toggle:v,removeToast:b,toasts:f,clearQueue:x,buildToast:(e,t)=>{if(_(t))return;let{toastId:n,updateId:s,data:p,staleId:m,delay:h}=t,v=s==null;v&&i++;let y={...c,style:c.toastStyle,key:r++,...Object.fromEntries(Object.entries(t).filter(([e,t])=>t!=null)),toastId:n,updateId:s,data:p,isIn:!1,className:l(t.className||c.toastClassName),progressClassName:l(t.progressClassName||c.progressClassName),autoClose:t.isLoading?!1:u(t.autoClose,c.autoClose),closeToast(e){let t=f.get(n);t&&(t.removalReason=e,b(n))},deleteToast(){if(f.get(n)!=null){if(f.delete(n),i--,i<0&&(i=0),o.length>0){S(o.shift());return}g()}}};y.closeButton=c.closeButton,t.closeButton===!1||d(t.closeButton)?y.closeButton=t.closeButton:t.closeButton===!0&&(y.closeButton=d(c.closeButton)?c.closeButton:!0);let x={content:e,props:y,staleId:m};c.limit&&c.limit>0&&i>c.limit&&v?o.push(x):a(h)?setTimeout(()=>{S(x)},h):S(x)},setProps(e){c=e},setToggle:(e,t)=>{let n=f.get(e);n&&(n.toggle=t)},isToastActive:e=>f.get(e)?.isActive,getSnapshot:()=>s}}var x=new Map,S=[],C=new Set,w=e=>C.forEach(t=>t(e)),T=()=>x.size>0;function E(){S.forEach(e=>ne(e.content,e.options)),S=[]}var D=(e,{containerId:t})=>x.get(t||1)?.toasts.get(e);function ee(e,t){var n;if(t)return!!((n=x.get(t))!=null&&n.isToastActive(e));let r=!1;return x.forEach(t=>{t.isToastActive(e)&&(r=!0)}),r}function te(e){if(!T()){S=S.filter(t=>e!=null&&t.options.toastId!==e);return}if(e==null||c(e))x.forEach(t=>{t.removeToast(e)});else if(e&&(`containerId`in e||`id`in e)){let t=x.get(e.containerId);t?t.removeToast(e.id):x.forEach(t=>{t.removeToast(e.id)})}}var O=(e={})=>{x.forEach(t=>{t.props.limit&&(!e.containerId||t.id===e.containerId)&&t.clearQueue()})};function ne(e,t){d(e)&&(T()||S.push({content:e,options:t}),x.forEach(n=>{n.buildToast(e,t)}))}function re(e){var t;(t=x.get(e.containerId||1))==null||t.setToggle(e.id,e.fn)}function k(e,t){x.forEach(n=>{(t==null||!(t!=null&&t.containerId)||t?.containerId===n.id)&&n.toggle(e,t?.id)})}function A(e){let t=e.containerId||1;return{subscribe(n){let r=b(t,e,w);x.set(t,r);let i=r.observe(n);return E(),()=>{i(),x.delete(t)}},setProps(e){var n;(n=x.get(t))==null||n.setProps(e)},getSnapshot(){return x.get(t)?.getSnapshot()}}}function j(e){return C.add(e),()=>{C.delete(e)}}function M(e){return e&&(o(e.toastId)||a(e.toastId))?e.toastId:y()}function N(e,t){return ne(e,t),t.toastId}function P(e,t){return{...t,type:t&&t.type||e,toastId:M(t)}}function F(e){return(t,n)=>N(t,P(e,n))}function I(e,t){return N(e,P(`default`,t))}I.loading=(e,t)=>N(e,P(`default`,{isLoading:!0,autoClose:!1,closeOnClick:!1,closeButton:!1,draggable:!1,...t}));function ie(e,{pending:t,error:n,success:r},i){let a;t&&(a=o(t)?I.loading(t,i):I.loading(t.render,{...i,...t}));let c={isLoading:null,autoClose:null,closeOnClick:null,closeButton:null,draggable:null},l=(e,t,n)=>{if(t==null){I.dismiss(a);return}let r={type:e,...c,...i,data:n},s=o(t)?{render:t}:t;return a?I.update(a,{...r,...s}):I(s.render,{...r,...s}),n},u=s(e)?e():e;return u.then(e=>l(`success`,r,e)).catch(e=>l(`error`,n,e)),u}I.promise=ie,I.success=F(`success`),I.info=F(`info`),I.error=F(`error`),I.warning=F(`warning`),I.warn=I.warning,I.dark=(e,t)=>N(e,P(`default`,{theme:`dark`,...t}));function ae(e){te(e)}I.dismiss=ae,I.clearWaitingQueue=O,I.isActive=ee,I.update=(e,t={})=>{let n=D(e,t);if(n){let{props:r,content:i}=n,a={delay:100,...r,...t,toastId:t.toastId||e,updateId:y()};a.toastId!==e&&(a.staleId=e);let o=a.render||i;delete a.render,N(o,a)}},I.done=e=>{I.update(e,{progress:1})},I.onChange=j,I.play=e=>k(!0,e),I.pause=e=>k(!1,e);function oe(e){let{subscribe:t,getSnapshot:n,setProps:r}=(0,i.useRef)(A(e)).current;r(e);let a=(0,i.useSyncExternalStore)(t,n,n)?.slice();function o(t){if(!a)return[];let n=new Map;return e.newestOnTop&&a.reverse(),a.forEach(e=>{let{position:t}=e.props;n.has(t)||n.set(t,[]),n.get(t).push(e)}),Array.from(n,e=>t(e[0],e[1]))}return{getToastToRender:o,isToastActive:ee,count:a?.length}}function se(e){let[t,n]=(0,i.useState)(!1),[r,a]=(0,i.useState)(!1),o=(0,i.useRef)(null),s=(0,i.useRef)({start:0,delta:0,removalDistance:0,canCloseOnClick:!0,canDrag:!1,didMove:!1}).current,{autoClose:c,pauseOnHover:l,closeToast:u,onClick:d,closeOnClick:f}=e;re({id:e.toastId,containerId:e.containerId,fn:n}),(0,i.useEffect)(()=>{if(e.pauseOnFocusLoss)return p(),()=>{m()}},[e.pauseOnFocusLoss]);function p(){document.hasFocus()||v(),window.addEventListener(`focus`,_),window.addEventListener(`blur`,v)}function m(){window.removeEventListener(`focus`,_),window.removeEventListener(`blur`,v)}function h(t){if(e.draggable===!0||e.draggable===t.pointerType){y();let n=o.current;s.canCloseOnClick=!0,s.canDrag=!0,n.style.transition=`none`,e.draggableDirection===`x`?(s.start=t.clientX,s.removalDistance=n.offsetWidth*(e.draggablePercent/100)):(s.start=t.clientY,s.removalDistance=n.offsetHeight*(e.draggablePercent===80?e.draggablePercent*1.5:e.draggablePercent)/100)}}function g(t){let{top:n,bottom:r,left:i,right:a}=o.current.getBoundingClientRect();t.pointerType===`mouse`&&e.pauseOnHover&&t.clientX>=i&&t.clientX<=a&&t.clientY>=n&&t.clientY<=r?v():_()}function _(){n(!0)}function v(){n(!1)}function y(){s.didMove=!1,document.addEventListener(`pointermove`,x),document.addEventListener(`pointerup`,S)}function b(){document.removeEventListener(`pointermove`,x),document.removeEventListener(`pointerup`,S)}function x(n){let r=o.current;if(s.canDrag&&r){s.didMove=!0,t&&v(),e.draggableDirection===`x`?s.delta=n.clientX-s.start:s.delta=n.clientY-s.start,s.start!==n.clientX&&(s.canCloseOnClick=!1);let i=e.draggableDirection===`x`?`${s.delta}px, var(--y)`:`0, calc(${s.delta}px + var(--y))`;r.style.transform=`translate3d(${i},0)`,r.style.opacity=`${1-Math.abs(s.delta/s.removalDistance)}`}}function S(){b();let t=o.current;if(s.canDrag&&s.didMove&&t){if(s.canDrag=!1,Math.abs(s.delta)>s.removalDistance){a(!0),e.closeToast(!0),e.collapseAll();return}t.style.transition=`transform 0.2s, opacity 0.2s`,t.style.removeProperty(`transform`),t.style.removeProperty(`opacity`)}}let C={onPointerDown:h,onPointerUp:g};return c&&l&&(C.onMouseEnter=v,e.stacked||(C.onMouseLeave=_)),f&&(C.onClick=e=>{d&&d(e),s.canCloseOnClick&&u(!0)}),{playToast:_,pauseToast:v,isRunning:t,preventExitTransition:r,toastRef:o,eventHandlers:C}}var ce=typeof window<`u`?i.useLayoutEffect:i.useEffect,le=({theme:e,type:t,isLoading:n,...r})=>i.createElement(`svg`,{viewBox:`0 0 24 24`,width:`100%`,height:`100%`,fill:e===`colored`?`currentColor`:`var(--toastify-icon-color-${t})`,...r});function L(e){return i.createElement(le,{...e},i.createElement(`path`,{d:`M23.32 17.191L15.438 2.184C14.728.833 13.416 0 11.996 0c-1.42 0-2.733.833-3.443 2.184L.533 17.448a4.744 4.744 0 000 4.368C1.243 23.167 2.555 24 3.975 24h16.05C22.22 24 24 22.044 24 19.632c0-.904-.251-1.746-.68-2.44zm-9.622 1.46c0 1.033-.724 1.823-1.698 1.823s-1.698-.79-1.698-1.822v-.043c0-1.028.724-1.822 1.698-1.822s1.698.79 1.698 1.822v.043zm.039-12.285l-.84 8.06c-.057.581-.408.943-.897.943-.49 0-.84-.367-.896-.942l-.84-8.065c-.057-.624.25-1.095.779-1.095h1.91c.528.005.84.476.784 1.1z`}))}function R(e){return i.createElement(le,{...e},i.createElement(`path`,{d:`M12 0a12 12 0 1012 12A12.013 12.013 0 0012 0zm.25 5a1.5 1.5 0 11-1.5 1.5 1.5 1.5 0 011.5-1.5zm2.25 13.5h-4a1 1 0 010-2h.75a.25.25 0 00.25-.25v-4.5a.25.25 0 00-.25-.25h-.75a1 1 0 010-2h1a2 2 0 012 2v4.75a.25.25 0 00.25.25h.75a1 1 0 110 2z`}))}function ue(e){return i.createElement(le,{...e},i.createElement(`path`,{d:`M12 0a12 12 0 1012 12A12.014 12.014 0 0012 0zm6.927 8.2l-6.845 9.289a1.011 1.011 0 01-1.43.188l-4.888-3.908a1 1 0 111.25-1.562l4.076 3.261 6.227-8.451a1 1 0 111.61 1.183z`}))}function z(e){return i.createElement(le,{...e},i.createElement(`path`,{d:`M11.983 0a12.206 12.206 0 00-8.51 3.653A11.8 11.8 0 000 12.207 11.779 11.779 0 0011.8 24h.214A12.111 12.111 0 0024 11.791 11.766 11.766 0 0011.983 0zM10.5 16.542a1.476 1.476 0 011.449-1.53h.027a1.527 1.527 0 011.523 1.47 1.475 1.475 0 01-1.449 1.53h-.027a1.529 1.529 0 01-1.523-1.47zM11 12.5v-6a1 1 0 012 0v6a1 1 0 11-2 0z`}))}function de(){return i.createElement(`div`,{className:`Toastify__spinner`})}var fe={info:R,warning:L,success:ue,error:z,spinner:de},pe=e=>e in fe;function B({theme:e,type:t,isLoading:n,icon:r}){let a=null,o={theme:e,type:t};return r===!1||(s(r)?a=r({...o,isLoading:n}):(0,i.isValidElement)(r)?a=(0,i.cloneElement)(r,o):n?a=fe.spinner():pe(t)&&(a=fe[t](o))),a}var V=e=>{let{isRunning:t,preventExitTransition:n,toastRef:a,eventHandlers:o,playToast:c}=se(e),{closeButton:l,children:u,autoClose:d,onClick:f,type:p,hideProgressBar:m,closeToast:v,transition:y,position:b,className:x,style:S,progressClassName:C,updateId:w,role:T,progress:E,rtl:D,toastId:ee,deleteToast:te,isIn:O,isLoading:ne,closeOnClick:re,theme:k,ariaLabel:A}=e,j=r(`Toastify__toast`,`Toastify__toast-theme--${k}`,`Toastify__toast--${p}`,{"Toastify__toast--rtl":D},{"Toastify__toast--close-on-click":re}),M=s(x)?x({rtl:D,position:b,type:p,defaultClassName:j}):r(j,x),N=B(e),P=!!E||!d,F={closeToast:v,type:p,theme:k},I=null;return l===!1||(I=s(l)?l(F):(0,i.isValidElement)(l)?(0,i.cloneElement)(l,F):g(F)),i.createElement(y,{isIn:O,done:te,position:b,preventExitTransition:n,nodeRef:a,playToast:c},i.createElement(`div`,{id:ee,tabIndex:0,onClick:f,"data-in":O,className:M,...o,style:S,ref:a,...O&&{role:T,"aria-label":A}},N!=null&&i.createElement(`div`,{className:r(`Toastify__toast-icon`,{"Toastify--animate-icon Toastify__zoom-enter":!ne})},N),h(u,e,!t),I,!e.customProgressBar&&i.createElement(_,{...w&&!P?{key:`p-${w}`}:{},rtl:D,theme:k,delay:d,isRunning:t,isIn:O,closeToast:v,hide:m,type:p,className:C,controlledProgress:P,progress:E||0})))},H=(e,t=!1)=>({enter:`Toastify--animate Toastify__${e}-enter`,exit:`Toastify--animate Toastify__${e}-exit`,appendPosition:t}),U=p(H(`bounce`,!0));p(H(`slide`,!0)),p(H(`zoom`)),p(H(`flip`));var W={position:`top-right`,transition:U,autoClose:5e3,closeButton:!0,pauseOnHover:!0,pauseOnFocusLoss:!0,draggable:`touch`,draggablePercent:80,draggableDirection:`x`,role:`alert`,theme:`light`,"aria-label":`Notifications Alt+T`,hotKeys:e=>e.altKey&&e.code===`KeyT`};function G(e){let t={...W,...e},n=e.stacked,[a,o]=(0,i.useState)(!0),c=(0,i.useRef)(null),{getToastToRender:u,isToastActive:d,count:f}=oe(t),{className:p,style:m,rtl:h,containerId:g,hotKeys:_}=t;function v(e){let t=r(`Toastify__toast-container`,`Toastify__toast-container--${e}`,{"Toastify__toast-container--rtl":h});return s(p)?p({position:e,rtl:h,defaultClassName:t}):r(t,l(p))}function y(){n&&(o(!0),I.play())}return ce(()=>{if(n){let e=c.current.querySelectorAll(`[data-in="true"]`),n=t.position?.includes(`top`),r=0,i=0;Array.from(e).reverse().forEach((e,t)=>{let o=e;o.classList.add(`Toastify__toast--stacked`),t>0&&(o.dataset.collapsed=`${a}`),o.dataset.pos||(o.dataset.pos=n?`top`:`bot`);let s=r*(a?.2:1)+(a?0:12*t),c=Math.max(.5,1-(a?i:0));o.style.setProperty(`--y`,`${n?s:s*-1}px`),o.style.setProperty(`--g`,`12`),o.style.setProperty(`--s`,`${c}`),r+=o.offsetHeight,i+=.025})}},[a,f,n]),(0,i.useEffect)(()=>{function e(e){var t;let n=c.current;_(e)&&((t=n?.querySelector(`[tabIndex="0"]`))==null||t.focus(),o(!1),I.pause()),e.key===`Escape`&&(document.activeElement===n||n!=null&&n.contains(document.activeElement))&&(o(!0),I.play())}return document.addEventListener(`keydown`,e),()=>{document.removeEventListener(`keydown`,e)}},[_]),i.createElement(`section`,{ref:c,className:`Toastify`,id:g,onMouseEnter:()=>{n&&(o(!1),I.pause())},onMouseLeave:y,"aria-live":`polite`,"aria-atomic":`false`,"aria-relevant":`additions text`,"aria-label":t[`aria-label`]},u((e,t)=>{let r=t.length?{...m}:{...m,pointerEvents:`none`};return i.createElement(`div`,{tabIndex:-1,className:v(e),"data-stacked":n,style:r,key:`c-${e}`},t.map(({content:e,props:t})=>i.createElement(V,{...t,stacked:n,collapseAll:y,isIn:d(t.toastId,t.containerId),key:`t-${t.key}`},e)))}))}var me=`:root {
  --toastify-color-light: #fff;
  --toastify-color-dark: #121212;
  --toastify-color-info: #3498db;
  --toastify-color-success: #07bc0c;
  --toastify-color-warning: #f1c40f;
  --toastify-color-error: hsl(6, 78%, 57%);
  --toastify-color-transparent: rgba(255, 255, 255, 0.7);

  --toastify-icon-color-info: var(--toastify-color-info);
  --toastify-icon-color-success: var(--toastify-color-success);
  --toastify-icon-color-warning: var(--toastify-color-warning);
  --toastify-icon-color-error: var(--toastify-color-error);

  --toastify-container-width: fit-content;
  --toastify-toast-width: 320px;
  --toastify-toast-offset: 16px;
  --toastify-toast-top: max(var(--toastify-toast-offset), env(safe-area-inset-top));
  --toastify-toast-right: max(var(--toastify-toast-offset), env(safe-area-inset-right));
  --toastify-toast-left: max(var(--toastify-toast-offset), env(safe-area-inset-left));
  --toastify-toast-bottom: max(var(--toastify-toast-offset), env(safe-area-inset-bottom));
  --toastify-toast-background: #fff;
  --toastify-toast-padding: 14px;
  --toastify-toast-min-height: 64px;
  --toastify-toast-max-height: 800px;
  --toastify-toast-bd-radius: 6px;
  --toastify-toast-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  --toastify-font-family: sans-serif;
  --toastify-z-index: 9999;
  --toastify-text-color-light: #757575;
  --toastify-text-color-dark: #fff;

  /* Used only for colored theme */
  --toastify-text-color-info: #fff;
  --toastify-text-color-success: #fff;
  --toastify-text-color-warning: #fff;
  --toastify-text-color-error: #fff;

  --toastify-spinner-color: #616161;
  --toastify-spinner-color-empty-area: #e0e0e0;
  --toastify-color-progress-light: linear-gradient(to right, #4cd964, #5ac8fa, #007aff, #34aadc, #5856d6, #ff2d55);
  --toastify-color-progress-dark: #bb86fc;
  --toastify-color-progress-info: var(--toastify-color-info);
  --toastify-color-progress-success: var(--toastify-color-success);
  --toastify-color-progress-warning: var(--toastify-color-warning);
  --toastify-color-progress-error: var(--toastify-color-error);
  /* used to control the opacity of the progress trail */
  --toastify-color-progress-bgo: 0.2;
}

.Toastify__toast-container {
  z-index: var(--toastify-z-index);
  -webkit-transform: translate3d(0, 0, var(--toastify-z-index));
  position: fixed;
  width: var(--toastify-container-width);
  box-sizing: border-box;
  color: #fff;
  display: flex;
  flex-direction: column;
}

.Toastify__toast-container--top-left {
  top: var(--toastify-toast-top);
  left: var(--toastify-toast-left);
}
.Toastify__toast-container--top-center {
  top: var(--toastify-toast-top);
  left: 50%;
  transform: translateX(-50%);
  align-items: center;
}
.Toastify__toast-container--top-right {
  top: var(--toastify-toast-top);
  right: var(--toastify-toast-right);
  align-items: end;
}
.Toastify__toast-container--bottom-left {
  bottom: var(--toastify-toast-bottom);
  left: var(--toastify-toast-left);
}
.Toastify__toast-container--bottom-center {
  bottom: var(--toastify-toast-bottom);
  left: 50%;
  transform: translateX(-50%);
  align-items: center;
}
.Toastify__toast-container--bottom-right {
  bottom: var(--toastify-toast-bottom);
  right: var(--toastify-toast-right);
  align-items: end;
}

.Toastify__toast {
  --y: 0px;
  position: relative;
  touch-action: none;
  width: var(--toastify-toast-width);
  min-height: var(--toastify-toast-min-height);
  box-sizing: border-box;
  margin-bottom: 1rem;
  padding: var(--toastify-toast-padding);
  border-radius: var(--toastify-toast-bd-radius);
  box-shadow: var(--toastify-toast-shadow);
  max-height: var(--toastify-toast-max-height);
  font-family: var(--toastify-font-family);
  /* webkit only issue #791 */
  z-index: 0;
  /* inner swag */
  display: flex;
  flex: 1 auto;
  align-items: center;
  word-break: break-word;
}

@media only screen and (max-width: 480px) {
  .Toastify__toast-container {
    width: 100vw;
    left: env(safe-area-inset-left);
    margin: 0;
  }
  .Toastify__toast-container--top-left,
  .Toastify__toast-container--top-center,
  .Toastify__toast-container--top-right {
    top: env(safe-area-inset-top);
    transform: translateX(0);
  }
  .Toastify__toast-container--bottom-left,
  .Toastify__toast-container--bottom-center,
  .Toastify__toast-container--bottom-right {
    bottom: env(safe-area-inset-bottom);
    transform: translateX(0);
  }
  .Toastify__toast-container--rtl {
    right: env(safe-area-inset-right);
    left: initial;
  }
  .Toastify__toast {
    --toastify-toast-width: 100%;
    margin-bottom: 0;
    border-radius: 0;
  }
}

.Toastify__toast-container[data-stacked='true'] {
  width: var(--toastify-toast-width);
}

@media only screen and (max-width: 480px) {
  .Toastify__toast-container[data-stacked='true'] {
    width: 100vw;
  }
}

.Toastify__toast--stacked {
  position: absolute;
  width: 100%;
  transform: translate3d(0, var(--y), 0) scale(var(--s));
  transition: transform 0.3s;
}

.Toastify__toast--stacked[data-collapsed] .Toastify__toast-body,
.Toastify__toast--stacked[data-collapsed] .Toastify__close-button {
  transition: opacity 0.1s;
}

.Toastify__toast--stacked[data-collapsed='false'] {
  overflow: visible;
}

.Toastify__toast--stacked[data-collapsed='true']:not(:last-child) > * {
  opacity: 0;
}

.Toastify__toast--stacked:after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  height: calc(var(--g) * 1px);
  bottom: 100%;
}

.Toastify__toast--stacked[data-pos='top'] {
  top: 0;
}

.Toastify__toast--stacked[data-pos='bot'] {
  bottom: 0;
}

.Toastify__toast--stacked[data-pos='bot'].Toastify__toast--stacked:before {
  transform-origin: top;
}

.Toastify__toast--stacked[data-pos='top'].Toastify__toast--stacked:before {
  transform-origin: bottom;
}

.Toastify__toast--stacked:before {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 100%;
  transform: scaleY(3);
  z-index: -1;
}

.Toastify__toast--rtl {
  direction: rtl;
}

.Toastify__toast--close-on-click {
  cursor: pointer;
}

.Toastify__toast-icon {
  margin-inline-end: 10px;
  width: 22px;
  flex-shrink: 0;
  display: flex;
}

.Toastify--animate {
  animation-fill-mode: both;
  animation-duration: 0.5s;
}

.Toastify--animate-icon {
  animation-fill-mode: both;
  animation-duration: 0.3s;
}

.Toastify__toast-theme--dark {
  background: var(--toastify-color-dark);
  color: var(--toastify-text-color-dark);
}

.Toastify__toast-theme--light {
  background: var(--toastify-color-light);
  color: var(--toastify-text-color-light);
}

.Toastify__toast-theme--colored.Toastify__toast--default {
  background: var(--toastify-color-light);
  color: var(--toastify-text-color-light);
}

.Toastify__toast-theme--colored.Toastify__toast--info {
  color: var(--toastify-text-color-info);
  background: var(--toastify-color-info);
}

.Toastify__toast-theme--colored.Toastify__toast--success {
  color: var(--toastify-text-color-success);
  background: var(--toastify-color-success);
}

.Toastify__toast-theme--colored.Toastify__toast--warning {
  color: var(--toastify-text-color-warning);
  background: var(--toastify-color-warning);
}

.Toastify__toast-theme--colored.Toastify__toast--error {
  color: var(--toastify-text-color-error);
  background: var(--toastify-color-error);
}

.Toastify__progress-bar-theme--light {
  background: var(--toastify-color-progress-light);
}

.Toastify__progress-bar-theme--dark {
  background: var(--toastify-color-progress-dark);
}

.Toastify__progress-bar--info {
  background: var(--toastify-color-progress-info);
}

.Toastify__progress-bar--success {
  background: var(--toastify-color-progress-success);
}

.Toastify__progress-bar--warning {
  background: var(--toastify-color-progress-warning);
}

.Toastify__progress-bar--error {
  background: var(--toastify-color-progress-error);
}

.Toastify__progress-bar-theme--colored.Toastify__progress-bar--info,
.Toastify__progress-bar-theme--colored.Toastify__progress-bar--success,
.Toastify__progress-bar-theme--colored.Toastify__progress-bar--warning,
.Toastify__progress-bar-theme--colored.Toastify__progress-bar--error {
  background: var(--toastify-color-transparent);
}

.Toastify__close-button {
  color: #fff;
  position: absolute;
  top: 6px;
  right: 6px;
  background: transparent;
  outline: none;
  border: none;
  padding: 0;
  cursor: pointer;
  opacity: 0.7;
  transition: 0.3s ease;
  z-index: 1;
}

.Toastify__toast--rtl .Toastify__close-button {
  left: 6px;
  right: unset;
}

.Toastify__close-button--light {
  color: #000;
  opacity: 0.3;
}

.Toastify__close-button > svg {
  fill: currentColor;
  height: 16px;
  width: 14px;
}

.Toastify__close-button:hover,
.Toastify__close-button:focus {
  opacity: 1;
}

@keyframes Toastify__trackProgress {
  0% {
    transform: scaleX(1);
  }
  100% {
    transform: scaleX(0);
  }
}

.Toastify__progress-bar {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  opacity: 0.7;
  transform-origin: left;
}

.Toastify__progress-bar--animated {
  animation: Toastify__trackProgress linear 1 forwards;
}

.Toastify__progress-bar--controlled {
  transition: transform 0.2s;
}

.Toastify__progress-bar--rtl {
  right: 0;
  left: initial;
  transform-origin: right;
  border-bottom-left-radius: initial;
}

.Toastify__progress-bar--wrp {
  position: absolute;
  overflow: hidden;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 5px;
  border-bottom-left-radius: var(--toastify-toast-bd-radius);
  border-bottom-right-radius: var(--toastify-toast-bd-radius);
}

.Toastify__progress-bar--wrp[data-hidden='true'] {
  opacity: 0;
}

.Toastify__progress-bar--bg {
  opacity: var(--toastify-color-progress-bgo);
  width: 100%;
  height: 100%;
}

.Toastify__spinner {
  width: 20px;
  height: 20px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: var(--toastify-spinner-color-empty-area);
  border-right-color: var(--toastify-spinner-color);
  animation: Toastify__spin 0.65s linear infinite;
}

@keyframes Toastify__bounceInRight {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  from {
    opacity: 0;
    transform: translate3d(3000px, 0, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(-25px, 0, 0);
  }
  75% {
    transform: translate3d(10px, 0, 0);
  }
  90% {
    transform: translate3d(-5px, 0, 0);
  }
  to {
    transform: none;
  }
}

@keyframes Toastify__bounceOutRight {
  20% {
    opacity: 1;
    transform: translate3d(-20px, var(--y), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(2000px, var(--y), 0);
  }
}

@keyframes Toastify__bounceInLeft {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  0% {
    opacity: 0;
    transform: translate3d(-3000px, 0, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(25px, 0, 0);
  }
  75% {
    transform: translate3d(-10px, 0, 0);
  }
  90% {
    transform: translate3d(5px, 0, 0);
  }
  to {
    transform: none;
  }
}

@keyframes Toastify__bounceOutLeft {
  20% {
    opacity: 1;
    transform: translate3d(20px, var(--y), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(-2000px, var(--y), 0);
  }
}

@keyframes Toastify__bounceInUp {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  from {
    opacity: 0;
    transform: translate3d(0, 3000px, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(0, -20px, 0);
  }
  75% {
    transform: translate3d(0, 10px, 0);
  }
  90% {
    transform: translate3d(0, -5px, 0);
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}

@keyframes Toastify__bounceOutUp {
  20% {
    transform: translate3d(0, calc(var(--y) - 10px), 0);
  }
  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, calc(var(--y) + 20px), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(0, -2000px, 0);
  }
}

@keyframes Toastify__bounceInDown {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  0% {
    opacity: 0;
    transform: translate3d(0, -3000px, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(0, 25px, 0);
  }
  75% {
    transform: translate3d(0, -10px, 0);
  }
  90% {
    transform: translate3d(0, 5px, 0);
  }
  to {
    transform: none;
  }
}

@keyframes Toastify__bounceOutDown {
  20% {
    transform: translate3d(0, calc(var(--y) - 10px), 0);
  }
  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, calc(var(--y) + 20px), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(0, 2000px, 0);
  }
}

.Toastify__bounce-enter--top-left,
.Toastify__bounce-enter--bottom-left {
  animation-name: Toastify__bounceInLeft;
}

.Toastify__bounce-enter--top-right,
.Toastify__bounce-enter--bottom-right {
  animation-name: Toastify__bounceInRight;
}

.Toastify__bounce-enter--top-center {
  animation-name: Toastify__bounceInDown;
}

.Toastify__bounce-enter--bottom-center {
  animation-name: Toastify__bounceInUp;
}

.Toastify__bounce-exit--top-left,
.Toastify__bounce-exit--bottom-left {
  animation-name: Toastify__bounceOutLeft;
}

.Toastify__bounce-exit--top-right,
.Toastify__bounce-exit--bottom-right {
  animation-name: Toastify__bounceOutRight;
}

.Toastify__bounce-exit--top-center {
  animation-name: Toastify__bounceOutUp;
}

.Toastify__bounce-exit--bottom-center {
  animation-name: Toastify__bounceOutDown;
}

@keyframes Toastify__zoomIn {
  from {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }
  50% {
    opacity: 1;
  }
}

@keyframes Toastify__zoomOut {
  from {
    opacity: 1;
  }
  50% {
    opacity: 0;
    transform: translate3d(0, var(--y), 0) scale3d(0.3, 0.3, 0.3);
  }
  to {
    opacity: 0;
  }
}

.Toastify__zoom-enter {
  animation-name: Toastify__zoomIn;
}

.Toastify__zoom-exit {
  animation-name: Toastify__zoomOut;
}

@keyframes Toastify__flipIn {
  from {
    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
    animation-timing-function: ease-in;
    opacity: 0;
  }
  40% {
    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
    animation-timing-function: ease-in;
  }
  60% {
    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
    opacity: 1;
  }
  80% {
    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
  }
  to {
    transform: perspective(400px);
  }
}

@keyframes Toastify__flipOut {
  from {
    transform: translate3d(0, var(--y), 0) perspective(400px);
  }
  30% {
    transform: translate3d(0, var(--y), 0) perspective(400px) rotate3d(1, 0, 0, -20deg);
    opacity: 1;
  }
  to {
    transform: translate3d(0, var(--y), 0) perspective(400px) rotate3d(1, 0, 0, 90deg);
    opacity: 0;
  }
}

.Toastify__flip-enter {
  animation-name: Toastify__flipIn;
}

.Toastify__flip-exit {
  animation-name: Toastify__flipOut;
}

@keyframes Toastify__slideInRight {
  from {
    transform: translate3d(110%, 0, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideInLeft {
  from {
    transform: translate3d(-110%, 0, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideInUp {
  from {
    transform: translate3d(0, 110%, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideInDown {
  from {
    transform: translate3d(0, -110%, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideOutRight {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(110%, var(--y), 0);
  }
}

@keyframes Toastify__slideOutLeft {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(-110%, var(--y), 0);
  }
}

@keyframes Toastify__slideOutDown {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(0, 500px, 0);
  }
}

@keyframes Toastify__slideOutUp {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(0, -500px, 0);
  }
}

.Toastify__slide-enter--top-left,
.Toastify__slide-enter--bottom-left {
  animation-name: Toastify__slideInLeft;
}

.Toastify__slide-enter--top-right,
.Toastify__slide-enter--bottom-right {
  animation-name: Toastify__slideInRight;
}

.Toastify__slide-enter--top-center {
  animation-name: Toastify__slideInDown;
}

.Toastify__slide-enter--bottom-center {
  animation-name: Toastify__slideInUp;
}

.Toastify__slide-exit--top-left,
.Toastify__slide-exit--bottom-left {
  animation-name: Toastify__slideOutLeft;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

.Toastify__slide-exit--top-right,
.Toastify__slide-exit--bottom-right {
  animation-name: Toastify__slideOutRight;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

.Toastify__slide-exit--top-center {
  animation-name: Toastify__slideOutUp;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

.Toastify__slide-exit--bottom-center {
  animation-name: Toastify__slideOutDown;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

@keyframes Toastify__spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
`,he=new Map,ge=(e,t)=>{ce(()=>{if(!e||typeof document>`u`)return;let n=document,r=he.get(n);if(r){t&&r.setAttribute(`nonce`,t);return}let i=n.createElement(`style`);i.textContent=e,t&&i.setAttribute(`nonce`,t),n.head.appendChild(i),he.set(n,i)},[t])};function K(e){return ge(me,e.nonce),i.createElement(G,{...e})}var _e=t(((e,t)=>{(function(n,r){typeof e==`object`&&t!==void 0?t.exports=r():typeof define==`function`&&define.amd?define(r):(n=typeof globalThis<`u`?globalThis:n||self,n.Sweetalert2=r())})(e,(function(){function e(e,t,n){if(typeof e==`function`?e===t:e.has(t))return arguments.length<3?t:n;throw TypeError(`Private element is not present on this object`)}function t(e,t){if(t.has(e))throw TypeError(`Cannot initialize the same private elements twice on an object`)}function n(t,n){return t.get(e(t,n))}function r(e,n,r){t(e,n),n.set(e,r)}function i(t,n,r){return t.set(e(t,n),r),r}let a={},o=()=>{a.previousActiveElement instanceof HTMLElement?(a.previousActiveElement.focus(),a.previousActiveElement=null):document.body&&document.body.focus()},s=e=>new Promise(t=>{if(!e)return t();let n=window.scrollX,r=window.scrollY;a.restoreFocusTimeout=setTimeout(()=>{o(),t()},100),window.scrollTo(n,r)}),c=`swal2-`,l=`container.shown.height-auto.iosfix.popup.modal.no-backdrop.no-transition.toast.toast-shown.show.hide.close.title.html-container.actions.confirm.deny.cancel.footer.icon.icon-content.image.input.file.range.select.radio.checkbox.label.textarea.inputerror.input-label.validation-message.progress-steps.active-progress-step.progress-step.progress-step-line.loader.loading.styled.top.top-start.top-end.top-left.top-right.center.center-start.center-end.center-left.center-right.bottom.bottom-start.bottom-end.bottom-left.bottom-right.grow-row.grow-column.grow-fullscreen.rtl.timer-progress-bar.timer-progress-bar-container.scrollbar-measure.icon-success.icon-warning.icon-info.icon-question.icon-error.draggable.dragging`.split(`.`).reduce((e,t)=>(e[t]=c+t,e),{}),u=[`success`,`warning`,`info`,`question`,`error`].reduce((e,t)=>(e[t]=c+t,e),{}),d=`SweetAlert2:`,f=e=>e.charAt(0).toUpperCase()+e.slice(1),p=e=>{console.warn(`${d} ${typeof e==`object`?e.join(` `):e}`)},m=e=>{console.error(`${d} ${e}`)},h=[],g=e=>{h.includes(e)||(h.push(e),p(e))},_=(e,t=null)=>{g(`"${e}" is deprecated and will be removed in the next major release.${t?` Use "${t}" instead.`:``}`)},v=e=>typeof e==`function`?e():e,y=e=>e&&typeof e.toPromise==`function`,b=e=>y(e)?e.toPromise():Promise.resolve(e),x=e=>e&&Promise.resolve(e)===e,S=()=>navigator.userAgent.includes(`Firefox`),C=()=>document.body.querySelector(`.${l.container}`),w=e=>{let t=C();return t?t.querySelector(e):null},T=e=>w(`.${e}`),E=()=>T(l.popup),D=()=>T(l.icon),ee=()=>T(l[`icon-content`]),te=()=>T(l.title),O=()=>T(l[`html-container`]),ne=()=>T(l.image),re=()=>T(l[`progress-steps`]),k=()=>T(l[`validation-message`]),A=()=>w(`.${l.actions} .${l.confirm}`),j=()=>w(`.${l.actions} .${l.cancel}`),M=()=>w(`.${l.actions} .${l.deny}`),N=()=>T(l[`input-label`]),P=()=>w(`.${l.loader}`),F=()=>T(l.actions),I=()=>T(l.footer),ie=()=>T(l[`timer-progress-bar`]),ae=()=>T(l.close),oe=()=>{let e=E();if(!e)return[];let t=e.querySelectorAll(`[tabindex]:not([tabindex="-1"]):not([tabindex="0"])`),n=Array.from(t).sort((e,t)=>{let n=parseInt(e.getAttribute(`tabindex`)||`0`),r=parseInt(t.getAttribute(`tabindex`)||`0`);return n>r?1:n<r?-1:0}),r=e.querySelectorAll(`
  a[href],
  area[href],
  input:not([disabled]),
  select:not([disabled]),
  textarea:not([disabled]),
  button:not([disabled]),
  iframe,
  object,
  embed,
  [tabindex="0"],
  [contenteditable],
  audio[controls],
  video[controls],
  summary
`),i=Array.from(r).filter(e=>e.getAttribute(`tabindex`)!==`-1`);return[...new Set(n.concat(i))].filter(e=>K(e))},se=()=>R(document.body,l.shown)&&!R(document.body,l[`toast-shown`])&&!R(document.body,l[`no-backdrop`]),ce=()=>{let e=E();return e?R(e,l.toast):!1},le=()=>{let e=E();return e?e.hasAttribute(`data-loading`):!1},L=(e,t)=>{if(e.textContent=``,t){let n=new DOMParser().parseFromString(t,`text/html`),r=n.querySelector(`head`);r&&Array.from(r.childNodes).forEach(t=>{e.appendChild(t)});let i=n.querySelector(`body`);i&&Array.from(i.childNodes).forEach(t=>{t instanceof HTMLVideoElement||t instanceof HTMLAudioElement?e.appendChild(t.cloneNode(!0)):e.appendChild(t)})}},R=(e,t)=>t?t.split(/\s+/).every(t=>e.classList.contains(t)):!1,ue=(e,t)=>{Array.from(e.classList).forEach(n=>{!Object.values(l).includes(n)&&!Object.values(u).includes(n)&&!Object.values(t.showClass||{}).includes(n)&&e.classList.remove(n)})},z=(e,t,n)=>{if(ue(e,t),!t.customClass)return;let r=t.customClass[n];if(r){if(typeof r!=`string`&&!r.forEach){p(`Invalid type of customClass.${n}! Expected string or iterable object, got "${typeof r}"`);return}B(e,r)}},de=(e,t)=>{if(!t)return null;switch(t){case`select`:case`textarea`:case`file`:return e.querySelector(`.${l.popup} > .${l[t]}`);case`checkbox`:return e.querySelector(`.${l.popup} > .${l.checkbox} input`);case`radio`:return e.querySelector(`.${l.popup} > .${l.radio} input:checked`)||e.querySelector(`.${l.popup} > .${l.radio} input:first-child`);case`range`:return e.querySelector(`.${l.popup} > .${l.range} input`);default:return e.querySelector(`.${l.popup} > .${l.input}`)}},fe=e=>{if(e.focus(),e.type!==`file`){let t=e.value;e.value=``,e.value=t}},pe=(e,t,n)=>{if(!e||!t)return;let r=typeof t==`string`?t.split(/\s+/).filter(Boolean):t;(Array.isArray(e)?e:[e]).forEach(e=>{r.forEach(t=>{n?e.classList.add(t):e.classList.remove(t)})})},B=(e,t)=>{pe(e,t,!0)},V=(e,t)=>{pe(e,t,!1)},H=(e,t)=>Array.from(e.children).find(e=>e instanceof HTMLElement&&R(e,t)),U=(e,t,n)=>{n===`${parseInt(`${n}`)}`&&(n=parseInt(n)),n||n===0?e.style.setProperty(t,typeof n==`number`?`${n}px`:n):e.style.removeProperty(t)},W=(e,t=`flex`)=>{e&&(e.style.display=t)},G=e=>{e&&(e.style.display=`none`)},me=(e,t=`block`)=>{e&&new MutationObserver(()=>{ge(e,e.innerHTML,t)}).observe(e,{childList:!0,subtree:!0})},he=(e,t,n,r)=>{let i=e.querySelector(t);i&&i.style.setProperty(n,r)},ge=(e,t,n=`flex`)=>{t?W(e,n):G(e)},K=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)),_e=()=>!K(A())&&!K(M())&&!K(j()),ve=e=>e.scrollHeight>e.clientHeight,ye=(e,t)=>{let n=e;for(;n&&n!==t;){if(ve(n))return!0;n=n.parentElement}return!1},be=e=>{let t=window.getComputedStyle(e),n=parseFloat(t.getPropertyValue(`animation-duration`)||`0`),r=parseFloat(t.getPropertyValue(`transition-duration`)||`0`);return n>0||r>0},xe=(e,t=!1)=>{let n=ie();n&&K(n)&&(t&&(n.style.transition=`none`,n.style.width=`100%`),setTimeout(()=>{n.style.transition=`width ${e/1e3}s linear`,n.style.width=`0%`},10))},Se=()=>{let e=ie();if(!e)return;let t=parseInt(window.getComputedStyle(e).width);e.style.removeProperty(`transition`),e.style.width=`100%`;let n=t/parseInt(window.getComputedStyle(e).width)*100;e.style.width=`${n}%`},Ce=()=>typeof window>`u`||typeof document>`u`,we=`
 <div aria-labelledby="${l.title}" aria-describedby="${l[`html-container`]}" class="${l.popup}" tabindex="-1">
   <button type="button" class="${l.close}"></button>
   <ul class="${l[`progress-steps`]}"></ul>
   <div class="${l.icon}"></div>
   <img class="${l.image}" />
   <h2 class="${l.title}" id="${l.title}"></h2>
   <div class="${l[`html-container`]}" id="${l[`html-container`]}"></div>
   <input class="${l.input}" id="${l.input}" />
   <input type="file" class="${l.file}" />
   <div class="${l.range}">
     <input type="range" />
     <output></output>
   </div>
   <select class="${l.select}" id="${l.select}"></select>
   <div class="${l.radio}"></div>
   <label class="${l.checkbox}">
     <input type="checkbox" id="${l.checkbox}" />
     <span class="${l.label}"></span>
   </label>
   <textarea class="${l.textarea}" id="${l.textarea}"></textarea>
   <div class="${l[`validation-message`]}" id="${l[`validation-message`]}"></div>
   <div class="${l.actions}">
     <div class="${l.loader}"></div>
     <button type="button" class="${l.confirm}"></button>
     <button type="button" class="${l.deny}"></button>
     <button type="button" class="${l.cancel}"></button>
   </div>
   <div class="${l.footer}"></div>
   <div class="${l[`timer-progress-bar-container`]}">
     <div class="${l[`timer-progress-bar`]}"></div>
   </div>
 </div>
`.replace(/(^|\n)\s*/g,``),Te=()=>{let e=C();return e?(e.remove(),V([document.documentElement,document.body],[l[`no-backdrop`],l[`toast-shown`],l[`has-column`]]),!0):!1},q=()=>{a.currentInstance&&a.currentInstance.resetValidationMessage()},Ee=()=>{let e=E();if(!e)return;let t=H(e,l.input),n=H(e,l.file),r=e.querySelector(`.${l.range} input`),i=e.querySelector(`.${l.range} output`),a=H(e,l.select),o=e.querySelector(`.${l.checkbox} input`),s=H(e,l.textarea);t&&(t.oninput=q),n&&(n.onchange=q),a&&(a.onchange=q),o&&(o.onchange=q),s&&(s.oninput=q),r&&i&&(r.oninput=()=>{q(),i.value=r.value},r.onchange=()=>{q(),i.value=r.value})},De=e=>{if(typeof e==`string`){let t=document.querySelector(e);if(!t)throw Error(`Target element "${e}" not found`);return t}return e},Oe=e=>{let t=E();t&&(t.setAttribute(`role`,e.toast?`alert`:`dialog`),t.setAttribute(`aria-live`,e.toast?`polite`:`assertive`),e.toast||t.setAttribute(`aria-modal`,`true`))},ke=e=>{window.getComputedStyle(e).direction===`rtl`&&(B(C(),l.rtl),a.isRTL=!0)},Ae=e=>{let t=Te();if(Ce()){m(`SweetAlert2 requires document to initialize`);return}let n=document.createElement(`div`);n.className=l.container,t&&B(n,l[`no-transition`]),L(n,we),n.dataset.swal2Theme=e.theme;let r=De(e.target||`body`);r.appendChild(n),e.topLayer&&(n.setAttribute(`popover`,``),n.showPopover()),Oe(e),ke(r),Ee()},je=(e,t)=>{e instanceof HTMLElement?t.appendChild(e):typeof e==`object`?Me(e,t):e&&L(t,e)},Me=(e,t)=>{`jquery`in e?Ne(t,e):L(t,e.toString())},Ne=(e,t)=>{if(e.textContent=``,0 in t)for(let n=0;n in t;n++)e.appendChild(t[n].cloneNode(!0));else e.appendChild(t.cloneNode(!0))},Pe=(e,t)=>{let n=F(),r=P();!n||!r||(!t.showConfirmButton&&!t.showDenyButton&&!t.showCancelButton?G(n):W(n),z(n,t,`actions`),Fe(n,r,t),L(r,t.loaderHtml||``),z(r,t,`loader`))};function Fe(e,t,n){let r=A(),i=M(),a=j();!r||!i||!a||(Re(r,`confirm`,n),Re(i,`deny`,n),Re(a,`cancel`,n),Ie(r,i,a,n),n.reverseButtons&&(n.toast?(e.insertBefore(a,r),e.insertBefore(i,r)):(e.insertBefore(a,t),e.insertBefore(i,t),e.insertBefore(r,t))))}function Ie(e,t,n,r){if(!r.buttonsStyling){V([e,t,n],l.styled);return}B([e,t,n],l.styled),[[e,`confirm`,r.confirmButtonColor],[t,`deny`,r.denyButtonColor],[n,`cancel`,r.cancelButtonColor]].forEach(([e,t,n])=>{n&&e.style.setProperty(`--swal2-${t}-button-background-color`,n),Le(e)})}function Le(e){let t=window.getComputedStyle(e);if(t.getPropertyValue(`--swal2-action-button-focus-box-shadow`))return;let n=t.backgroundColor.replace(/rgba?\((\d+), (\d+), (\d+).*/,`rgba($1, $2, $3, 0.5)`);e.style.setProperty(`--swal2-action-button-focus-box-shadow`,t.getPropertyValue(`--swal2-outline`).replace(/ rgba\(.*/,` ${n}`))}function Re(e,t,n){ge(e,n[`show${f(t)}Button`],`inline-block`),L(e,n[`${t}ButtonText`]||``),e.setAttribute(`aria-label`,n[`${t}ButtonAriaLabel`]||``),e.className=l[t],z(e,n,`${t}Button`)}let ze=(e,t)=>{let n=ae();n&&(L(n,t.closeButtonHtml||``),z(n,t,`closeButton`),ge(n,t.showCloseButton),n.setAttribute(`aria-label`,t.closeButtonAriaLabel||``))},Be=(e,t)=>{let n=C();n&&(Ve(n,t.backdrop),He(n,t.position),Ue(n,t.grow),z(n,t,`container`))};function Ve(e,t){typeof t==`string`?e.style.background=t:t||B([document.documentElement,document.body],l[`no-backdrop`])}function He(e,t){t&&(t in l?B(e,l[t]):(p(`The "position" parameter is not valid, defaulting to "center"`),B(e,l.center)))}function Ue(e,t){t&&B(e,l[`grow-${t}`])}var J={innerParams:new WeakMap,domCache:new WeakMap,focusedElement:new WeakMap};let We=[`input`,`file`,`range`,`select`,`radio`,`checkbox`,`textarea`],Ge=(e,t)=>{let n=E();if(!n)return;let r=J.innerParams.get(e),i=!r||t.input!==r.input;We.forEach(e=>{let r=H(n,l[e]);r&&(Je(e,t.inputAttributes),r.className=l[e],i&&G(r))}),t.input&&(i&&Ke(t),Ye(t))},Ke=e=>{if(!e.input)return;if(!Y[e.input]){m(`Unexpected type of input! Expected ${Object.keys(Y).join(` | `)}, got "${e.input}"`);return}let t=Qe(e.input);if(!t)return;let n=Y[e.input](t,e);W(t),e.inputAutoFocus&&setTimeout(()=>{fe(n)})},qe=e=>{for(let{name:t}of Array.from(e.attributes))[`id`,`type`,`value`,`style`].includes(t)||e.removeAttribute(t)},Je=(e,t)=>{let n=E();if(!n)return;let r=de(n,e);if(r){qe(r);for(let e in t)r.setAttribute(e,t[e])}},Ye=e=>{if(!e.input)return;let t=Qe(e.input);t&&z(t,e,`input`)},Xe=(e,t)=>{!e.placeholder&&t.inputPlaceholder&&(e.placeholder=t.inputPlaceholder)},Ze=(e,t,n)=>{if(n.inputLabel){let r=document.createElement(`label`),i=l[`input-label`];r.setAttribute(`for`,e.id),r.className=i,typeof n.customClass==`object`&&B(r,n.customClass.inputLabel),r.innerText=n.inputLabel,t.insertAdjacentElement(`beforebegin`,r)}},Qe=e=>{let t=E();if(t)return H(t,l[e]||l.input)},$e=(e,t)=>{[`string`,`number`].includes(typeof t)?e.value=`${t}`:x(t)||p(`Unexpected type of inputValue! Expected "string", "number" or "Promise", got "${typeof t}"`)},Y={};Y.text=Y.email=Y.password=Y.number=Y.tel=Y.url=Y.search=Y.date=Y[`datetime-local`]=Y.time=Y.week=Y.month=(e,t)=>{let n=e;return $e(n,t.inputValue),Ze(n,n,t),Xe(n,t),n.type=t.input,n},Y.file=(e,t)=>{let n=e;return Ze(n,n,t),Xe(n,t),n},Y.range=(e,t)=>{let n=e,r=n.querySelector(`input`),i=n.querySelector(`output`);return r&&($e(r,t.inputValue),r.type=t.input,Ze(r,e,t)),i&&$e(i,t.inputValue),e},Y.select=(e,t)=>{let n=e;if(n.textContent=``,t.inputPlaceholder){let e=document.createElement(`option`);L(e,t.inputPlaceholder),e.value=``,e.disabled=!0,e.selected=!0,n.appendChild(e)}return Ze(n,n,t),n},Y.radio=e=>{let t=e;return t.textContent=``,e},Y.checkbox=(e,t)=>{let n=E();if(!n)throw Error(`Popup not found`);let r=de(n,`checkbox`);if(!r)throw Error(`Checkbox input not found`);r.value=`1`,r.checked=!!t.inputValue;let i=e.querySelector(`span`);if(i){let e=t.inputPlaceholder||t.inputLabel;e&&L(i,e)}return r},Y.textarea=(e,t)=>{let n=e;$e(n,t.inputValue),Xe(n,t),Ze(n,n,t);let r=e=>parseInt(window.getComputedStyle(e).marginLeft)+parseInt(window.getComputedStyle(e).marginRight);return setTimeout(()=>{if(`MutationObserver`in window){let e=E();if(!e)return;let i=parseInt(window.getComputedStyle(e).width);new MutationObserver(()=>{if(!document.body.contains(n))return;let e=n.offsetWidth+r(n),a=E();a&&(e>i?a.style.width=`${e}px`:U(a,`width`,t.width))}).observe(n,{attributes:!0,attributeFilter:[`style`]})}}),n};let et=(e,t)=>{let n=O();n&&(me(n),z(n,t,`htmlContainer`),t.html?(je(t.html,n),W(n,`block`)):t.text?(n.textContent=t.text,W(n,`block`)):G(n),Ge(e,t))},tt=(e,t)=>{let n=I();n&&(me(n),ge(n,!!t.footer,`block`),t.footer&&je(t.footer,n),z(n,t,`footer`))},nt=(e,t)=>{let n=J.innerParams.get(e),r=D();if(r){if(n&&t.icon===n.icon){ot(r,t),rt(r,t);return}if(!t.icon&&!t.iconHtml){G(r);return}if(t.icon&&Object.keys(u).indexOf(t.icon)===-1){m(`Unknown icon! Expected "success", "error", "warning", "info" or "question", got "${t.icon}"`),G(r);return}W(r),ot(r,t),rt(r,t),B(r,t.showClass&&t.showClass.icon),window.matchMedia(`(prefers-color-scheme: dark)`).addEventListener(`change`,it)}},rt=(e,t)=>{for(let[n,r]of Object.entries(u))t.icon!==n&&V(e,r);B(e,t.icon&&u[t.icon]),st(e,t),it(),z(e,t,`icon`)},it=()=>{let e=E();if(!e)return;let t=window.getComputedStyle(e).getPropertyValue(`background-color`);e.querySelectorAll(`[class^=swal2-success-circular-line], .swal2-success-fix`).forEach(e=>{e.style.backgroundColor=t})},at=e=>`
  ${e.animation?`<div class="swal2-success-circular-line-left"></div>`:``}
  <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
  <div class="swal2-success-ring"></div>
  ${e.animation?`<div class="swal2-success-fix"></div>`:``}
  ${e.animation?`<div class="swal2-success-circular-line-right"></div>`:``}
`,ot=(e,t)=>{if(!t.icon&&!t.iconHtml)return;let n=e.innerHTML,r=``;t.iconHtml?r=ct(t.iconHtml):t.icon===`success`?(r=at(t),n=n.replace(/ style=".*?"/g,``)):t.icon===`error`?r=`
  <span class="swal2-x-mark">
    <span class="swal2-x-mark-line-left"></span>
    <span class="swal2-x-mark-line-right"></span>
  </span>
`:t.icon&&(r=ct({question:`?`,warning:`!`,info:`i`}[t.icon])),n.trim()!==r.trim()&&L(e,r)},st=(e,t)=>{if(t.iconColor){e.style.color=t.iconColor,e.style.borderColor=t.iconColor;for(let n of[`.swal2-success-line-tip`,`.swal2-success-line-long`,`.swal2-x-mark-line-left`,`.swal2-x-mark-line-right`])he(e,n,`background-color`,t.iconColor);he(e,`.swal2-success-ring`,`border-color`,t.iconColor)}},ct=e=>`<div class="${l[`icon-content`]}">${e}</div>`,lt=(e,t)=>{let n=ne();if(n){if(!t.imageUrl){G(n);return}W(n,``),n.setAttribute(`src`,t.imageUrl),n.setAttribute(`alt`,t.imageAlt||``),U(n,`width`,t.imageWidth),U(n,`height`,t.imageHeight),n.className=l.image,z(n,t,`image`)}},ut=!1,dt=0,ft=0,pt=0,mt=0,ht=e=>{e.addEventListener(`mousedown`,_t),document.body.addEventListener(`mousemove`,vt),e.addEventListener(`mouseup`,yt),e.addEventListener(`touchstart`,_t),document.body.addEventListener(`touchmove`,vt),e.addEventListener(`touchend`,yt)},gt=e=>{e.removeEventListener(`mousedown`,_t),document.body.removeEventListener(`mousemove`,vt),e.removeEventListener(`mouseup`,yt),e.removeEventListener(`touchstart`,_t),document.body.removeEventListener(`touchmove`,vt),e.removeEventListener(`touchend`,yt)},_t=e=>{let t=E();if(!t)return;let n=D();if(e.target===t||n&&n.contains(e.target)){ut=!0;let n=bt(e);dt=n.clientX,ft=n.clientY,pt=parseInt(t.style.insetInlineStart)||0,mt=parseInt(t.style.insetBlockStart)||0,B(t,`swal2-dragging`)}},vt=e=>{let t=E();if(t&&ut){let{clientX:n,clientY:r}=bt(e),i=n-dt;t.style.insetInlineStart=`${pt+(a.isRTL?-i:i)}px`,t.style.insetBlockStart=`${mt+(r-ft)}px`}},yt=()=>{let e=E();ut=!1,V(e,`swal2-dragging`)},bt=e=>{let t=e.type.startsWith(`touch`)?e.touches[0]:e;return{clientX:t.clientX,clientY:t.clientY}},xt=(e,t)=>{let n=C(),r=E();if(!(!n||!r)){if(t.toast){U(n,`width`,t.width),r.style.width=`100%`;let e=P();e&&r.insertBefore(e,D())}else U(r,`width`,t.width);U(r,`padding`,t.padding),t.color&&(r.style.color=t.color),t.background&&(r.style.background=t.background),G(k()),St(r,t),t.draggable&&!t.toast?(B(r,l.draggable),ht(r)):(V(r,l.draggable),gt(r))}},St=(e,t)=>{let n=t.showClass||{};e.className=`${l.popup} ${K(e)?n.popup:``}`,t.toast?(B([document.documentElement,document.body],l[`toast-shown`]),B(e,l.toast)):B(e,l.modal),z(e,t,`popup`),typeof t.customClass==`string`&&B(e,t.customClass),t.icon&&B(e,l[`icon-${t.icon}`])},Ct=(e,t)=>{let n=re();if(!n)return;let{progressSteps:r,currentProgressStep:i}=t;if(!r||r.length===0||i===void 0){G(n);return}W(n),n.textContent=``,i>=r.length&&p(`Invalid currentProgressStep parameter, it should be less than progressSteps.length (currentProgressStep like JS arrays starts from 0)`),r.forEach((e,a)=>{let o=wt(e);if(n.appendChild(o),a===i&&B(o,l[`active-progress-step`]),a!==r.length-1){let e=Tt(t);n.appendChild(e)}})},wt=e=>{let t=document.createElement(`li`);return B(t,l[`progress-step`]),L(t,e),t},Tt=e=>{let t=document.createElement(`li`);return B(t,l[`progress-step-line`]),e.progressStepsDistance&&U(t,`width`,e.progressStepsDistance),t},Et=(e,t)=>{let n=te();n&&(me(n),ge(n,!!(t.title||t.titleText),`block`),t.title&&je(t.title,n),t.titleText&&(n.innerText=t.titleText),z(n,t,`title`))},Dt=(e,t)=>{var n;xt(e,t),Be(e,t),Ct(e,t),nt(e,t),lt(e,t),Et(e,t),ze(e,t),et(e,t),Pe(e,t),tt(e,t);let r=E();typeof t.didRender==`function`&&r&&t.didRender(r),(n=a.eventEmitter)==null||n.emit(`didRender`,r)},Ot=()=>K(E()),kt=()=>A()?.click(),At=()=>M()?.click(),jt=()=>j()?.click(),Mt=Object.freeze({cancel:`cancel`,backdrop:`backdrop`,close:`close`,esc:`esc`,timer:`timer`}),Nt=e=>{if(e.keydownTarget&&e.keydownHandlerAdded&&e.keydownHandler){let t=e.keydownHandler;e.keydownTarget.removeEventListener(`keydown`,t,{capture:e.keydownListenerCapture}),e.keydownHandlerAdded=!1}},Pt=(e,t,n)=>{if(Nt(e),!t.toast){let r=e=>Rt(t,e,n);e.keydownHandler=r;let i=t.keydownListenerCapture?window:E();if(i){e.keydownTarget=i,e.keydownListenerCapture=t.keydownListenerCapture;let n=r;e.keydownTarget.addEventListener(`keydown`,n,{capture:e.keydownListenerCapture}),e.keydownHandlerAdded=!0}}},Ft=(e,t)=>{var n;let r=oe();return r.length?(e+=t,e===-2&&(e=r.length-1),e===r.length?e=0:e===-1&&(e=r.length-1),r[e].focus(),!(S()&&r[e]instanceof HTMLIFrameElement)):((n=E())==null||n.focus(),!0)},It=[`ArrowRight`,`ArrowDown`],Lt=[`ArrowLeft`,`ArrowUp`],Rt=(e,t,n)=>{e&&(t.isComposing||t.keyCode===229||(e.stopKeydownPropagation&&t.stopPropagation(),t.key===`Enter`?zt(t,e):t.key===`Tab`?Bt(t):[...It,...Lt].includes(t.key)?Vt(t.key):t.key===`Escape`&&Ht(t,e,n)))},zt=(e,t)=>{if(!v(t.allowEnterKey))return;let n=E();if(!n||!t.input)return;let r=de(n,t.input);if(e.target&&r&&e.target instanceof HTMLElement&&e.target.outerHTML===r.outerHTML){if([`textarea`,`file`].includes(t.input))return;kt(),e.preventDefault()}},Bt=e=>{let t=e.target,n=oe().findIndex(e=>e===t),r=!0;r=e.shiftKey?Ft(n,-1):Ft(n,1),e.stopPropagation(),r&&e.preventDefault()},Vt=e=>{let t=F(),n=A(),r=M(),i=j();if(!t||!n||!r||!i)return;let a=[n,r,i];if(document.activeElement instanceof HTMLElement&&!a.includes(document.activeElement))return;let o=It.includes(e)?`nextElementSibling`:`previousElementSibling`,s=document.activeElement;if(s){for(let e=0;e<t.children.length;e++){if(s=s[o],!s)return;if(s instanceof HTMLButtonElement&&K(s))break}s instanceof HTMLButtonElement&&s.focus()}},Ht=(e,t,n)=>{e.preventDefault(),v(t.allowEscapeKey)&&n(Mt.esc)};var Ut={swalPromiseResolve:new WeakMap,swalPromiseReject:new WeakMap};let Wt=()=>{let e=C();Array.from(document.body.children).forEach(t=>{t.contains(e)||(t.hasAttribute(`aria-hidden`)&&t.setAttribute(`data-previous-aria-hidden`,t.getAttribute(`aria-hidden`)||``),t.setAttribute(`aria-hidden`,`true`))})},Gt=()=>{Array.from(document.body.children).forEach(e=>{e.hasAttribute(`data-previous-aria-hidden`)?(e.setAttribute(`aria-hidden`,e.getAttribute(`data-previous-aria-hidden`)||``),e.removeAttribute(`data-previous-aria-hidden`)):e.removeAttribute(`aria-hidden`)})},Kt=typeof window<`u`&&!!window.GestureEvent,qt=Kt&&/iPad|iPhone|iPod/.test(navigator.userAgent)&&!window.MSStream,Jt=()=>{if(Kt&&!R(document.body,l.iosfix)){let e=document.body.scrollTop;document.body.style.top=`${e*-1}px`,B(document.body,l.iosfix),Yt()}},Yt=()=>{let e=C();if(!e)return;let t;e.ontouchstart=e=>{t=Xt(e)},e.ontouchmove=e=>{t&&(e.preventDefault(),e.stopPropagation())}},Xt=e=>{let t=e.target,n=C(),r=O();return!n||!r||Zt(e)||Qt(e)?!1:t===n||!ve(n)&&t instanceof HTMLElement&&!ye(t,r)&&t.tagName!==`INPUT`&&t.tagName!==`TEXTAREA`&&!(ve(r)&&r.contains(t))},Zt=e=>!!(e.touches&&e.touches.length&&e.touches[0].touchType===`stylus`),Qt=e=>e.touches&&e.touches.length>1,$t=()=>{if(R(document.body,l.iosfix)){let e=parseInt(document.body.style.top,10);V(document.body,l.iosfix),document.body.style.top=``,document.body.scrollTop=e*-1}},en=()=>{let e=document.createElement(`div`);e.className=l[`scrollbar-measure`],document.body.appendChild(e);let t=e.getBoundingClientRect().width-e.clientWidth;return document.body.removeChild(e),t},tn=null,nn=e=>{tn===null&&(document.body.scrollHeight>window.innerHeight||e===`scroll`)&&(tn=parseInt(window.getComputedStyle(document.body).getPropertyValue(`padding-right`)),document.body.style.paddingRight=`${tn+en()}px`)},rn=()=>{tn!==null&&(document.body.style.paddingRight=`${tn}px`,tn=null)};function an(e,t,n,r){ce()?pn(e,r):(s(n).then(()=>pn(e,r)),Nt(a)),Kt?(t.setAttribute(`style`,`display:none !important`),t.removeAttribute(`class`),t.innerHTML=``):t.remove(),se()&&(rn(),$t(),Gt()),on()}function on(){V([document.documentElement,document.body],[l.shown,l[`height-auto`],l[`no-backdrop`],l[`toast-shown`]])}function X(e){e=un(e);let t=Ut.swalPromiseResolve.get(this),n=sn(this);this.isAwaitingPromise?e.isDismissed||(ln(this),t(e)):n&&t(e)}let sn=e=>{let t=E();if(!t)return!1;let n=J.innerParams.get(e);if(!n||R(t,n.hideClass.popup))return!1;V(t,n.showClass.popup),B(t,n.hideClass.popup);let r=C();return V(r,n.showClass.backdrop),B(r,n.hideClass.backdrop),dn(e,t,n),!0};function cn(e){let t=Ut.swalPromiseReject.get(this);ln(this),t&&t(e)}let ln=e=>{e.isAwaitingPromise&&(delete e.isAwaitingPromise,J.innerParams.get(e)||e._destroy())},un=e=>e===void 0?{isConfirmed:!1,isDenied:!1,isDismissed:!0}:Object.assign({isConfirmed:!1,isDenied:!1,isDismissed:!1},e),dn=(e,t,n)=>{var r;let i=C(),o=be(t);typeof n.willClose==`function`&&n.willClose(t),(r=a.eventEmitter)==null||r.emit(`willClose`,t),o&&i?fn(e,t,i,!!n.returnFocus,n.didClose):i&&an(e,i,!!n.returnFocus,n.didClose)},fn=(e,t,n,r,i)=>{a.swalCloseEventFinishedCallback=an.bind(null,e,n,r,i);let o=function(e){if(e.target===t){var n;(n=a.swalCloseEventFinishedCallback)==null||n.call(a),delete a.swalCloseEventFinishedCallback,t.removeEventListener(`animationend`,o),t.removeEventListener(`transitionend`,o)}};t.addEventListener(`animationend`,o),t.addEventListener(`transitionend`,o)},pn=(e,t)=>{setTimeout(()=>{var n;typeof t==`function`&&t.bind(e.params)(),(n=a.eventEmitter)==null||n.emit(`didClose`),e._destroy&&e._destroy()})},mn=e=>{let t=E();if(t||new li,t=E(),!t)return;let n=P();ce()?G(D()):hn(t,e),W(n),t.setAttribute(`data-loading`,`true`),t.setAttribute(`aria-busy`,`true`),t.focus()},hn=(e,t)=>{let n=F(),r=P();!n||!r||(!t&&K(A())&&(t=A()),W(n),t&&(G(t),r.setAttribute(`data-button-to-replace`,t.className),n.insertBefore(r,t)),B([e,n],l.loading))},gn=(e,t)=>{t.input===`select`||t.input===`radio`?xn(e,t):[`text`,`email`,`number`,`tel`,`textarea`].some(e=>e===t.input)&&(y(t.inputValue)||x(t.inputValue))&&(mn(A()),Sn(e,t))},_n=(e,t)=>{let n=e.getInput();if(!n)return null;switch(t.input){case`checkbox`:return vn(n);case`radio`:return yn(n);case`file`:return bn(n);default:return t.inputAutoTrim?n.value.trim():n.value}},vn=e=>+!!e.checked,yn=e=>e.checked?e.value:null,bn=e=>e.files&&e.files.length?e.getAttribute(`multiple`)===null?e.files[0]:e.files:null,xn=(e,t)=>{let n=E();if(!n)return;let r=e=>{t.input===`select`?Cn(n,Tn(e),t):t.input===`radio`&&wn(n,Tn(e),t)};y(t.inputOptions)||x(t.inputOptions)?(mn(A()),b(t.inputOptions).then(t=>{e.hideLoading(),r(t)})):typeof t.inputOptions==`object`?r(t.inputOptions):m(`Unexpected type of inputOptions! Expected object, Map or Promise, got ${typeof t.inputOptions}`)},Sn=(e,t)=>{let n=e.getInput();n&&(G(n),b(t.inputValue).then(r=>{n.value=t.input===`number`?`${parseFloat(r)||0}`:`${r}`,W(n),n.focus(),e.hideLoading()}).catch(t=>{m(`Error in inputValue promise: ${t}`),n.value=``,W(n),n.focus(),e.hideLoading()}))};function Cn(e,t,n){let r=H(e,l.select);if(!r)return;let i=(e,t,r)=>{let i=document.createElement(`option`);i.value=r,L(i,t),i.selected=En(r,n.inputValue),e.appendChild(i)};t.forEach(e=>{let t=e[0],n=e[1];if(Array.isArray(n)){let e=document.createElement(`optgroup`);e.label=t,e.disabled=!1,r.appendChild(e),n.forEach(t=>i(e,t[1],t[0]))}else i(r,n,t)}),r.focus()}function wn(e,t,n){let r=H(e,l.radio);if(!r)return;t.forEach(e=>{let t=e[0],i=e[1],a=document.createElement(`input`),o=document.createElement(`label`);a.type=`radio`,a.name=l.radio,a.value=t,En(t,n.inputValue)&&(a.checked=!0);let s=document.createElement(`span`);L(s,i),s.className=l.label,o.appendChild(a),o.appendChild(s),r.appendChild(o)});let i=r.querySelectorAll(`input`);i.length&&i[0].focus()}let Tn=e=>(e instanceof Map?Array.from(e):Object.entries(e)).map(([e,t])=>[e,typeof t==`object`?Tn(t):t]),En=(e,t)=>!!t&&t!=null&&t.toString()===e.toString(),Dn=e=>{let t=J.innerParams.get(e);e.disableButtons(),t.input?An(e,`confirm`):Fn(e,!0)},On=e=>{let t=J.innerParams.get(e);e.disableButtons(),t.returnInputValueOnDeny?An(e,`deny`):Mn(e,!1)},kn=(e,t)=>{e.disableButtons(),t(Mt.cancel)},An=(e,t)=>{let n=J.innerParams.get(e);if(!n.input){m(`The "input" parameter is needed to be set when using returnInputValueOn${f(t)}`);return}let r=e.getInput(),i=_n(e,n);n.inputValidator?jn(e,i,t):r&&!r.checkValidity()?(e.enableButtons(),e.showValidationMessage(n.validationMessage||r.validationMessage)):t===`deny`?Mn(e,i):Fn(e,i)},jn=(e,t,n)=>{let r=J.innerParams.get(e);e.disableInput(),Promise.resolve().then(()=>b(r.inputValidator(t,r.validationMessage))).then(r=>{e.enableButtons(),e.enableInput(),r?e.showValidationMessage(r):n===`deny`?Mn(e,t):Fn(e,t)})},Mn=(e,t)=>{let n=J.innerParams.get(e);n.showLoaderOnDeny&&mn(M()),n.preDeny?(e.isAwaitingPromise=!0,Promise.resolve().then(()=>b(n.preDeny(t,n.validationMessage))).then(n=>{n===!1?(e.hideLoading(),ln(e)):e.close({isDenied:!0,value:n===void 0?t:n})}).catch(t=>Pn(e,t))):e.close({isDenied:!0,value:t})},Nn=(e,t)=>{e.close({isConfirmed:!0,value:t})},Pn=(e,t)=>{e.rejectPromise(t)},Fn=(e,t)=>{let n=J.innerParams.get(e);n.showLoaderOnConfirm&&mn(),n.preConfirm?(e.resetValidationMessage(),e.isAwaitingPromise=!0,Promise.resolve().then(()=>b(n.preConfirm(t,n.validationMessage))).then(n=>{K(k())||n===!1?(e.hideLoading(),ln(e)):Nn(e,n===void 0?t:n)}).catch(t=>Pn(e,t))):Nn(e,t)};function In(){let e=J.innerParams.get(this);if(!e)return;let t=J.domCache.get(this);G(t.loader),ce()?e.icon&&W(D()):Ln(t),V([t.popup,t.actions],l.loading),t.popup.removeAttribute(`aria-busy`),t.popup.removeAttribute(`data-loading`),this.enableButtons()}let Ln=e=>{let t=e.loader.getAttribute(`data-button-to-replace`),n=t?e.popup.getElementsByClassName(t):[];n.length?W(n[0],`inline-block`):_e()&&G(e.actions)};function Rn(){let e=J.innerParams.get(this),t=J.domCache.get(this);return t?de(t.popup,e.input):null}function zn(e,t,n){let r=J.domCache.get(e);t.forEach(e=>{r[e].disabled=n})}function Bn(e,t){let n=E();!n||!e||(e.type===`radio`?n.querySelectorAll(`[name="${l.radio}"]`).forEach(e=>{e.disabled=t}):e.disabled=t)}function Vn(){zn(this,[`confirmButton`,`denyButton`,`cancelButton`],!1);let e=J.focusedElement.get(this);e instanceof HTMLElement&&document.activeElement===document.body&&e.focus(),J.focusedElement.delete(this)}function Hn(){J.focusedElement.set(this,document.activeElement),zn(this,[`confirmButton`,`denyButton`,`cancelButton`],!0)}function Un(){Bn(this.getInput(),!1)}function Wn(){Bn(this.getInput(),!0)}function Gn(e){let t=J.domCache.get(this),n=J.innerParams.get(this);L(t.validationMessage,e),t.validationMessage.className=l[`validation-message`],n.customClass&&n.customClass.validationMessage&&B(t.validationMessage,n.customClass.validationMessage),W(t.validationMessage);let r=this.getInput();r&&(r.setAttribute(`aria-invalid`,`true`),r.setAttribute(`aria-describedby`,l[`validation-message`]),fe(r),B(r,l.inputerror))}function Kn(){let e=J.domCache.get(this);e.validationMessage&&G(e.validationMessage);let t=this.getInput();t&&(t.removeAttribute(`aria-invalid`),t.removeAttribute(`aria-describedby`),V(t,l.inputerror))}let Z={title:``,titleText:``,text:``,html:``,footer:``,icon:void 0,iconColor:void 0,iconHtml:void 0,template:void 0,toast:!1,draggable:!1,animation:!0,theme:`light`,showClass:{popup:`swal2-show`,backdrop:`swal2-backdrop-show`,icon:`swal2-icon-show`},hideClass:{popup:`swal2-hide`,backdrop:`swal2-backdrop-hide`,icon:`swal2-icon-hide`},customClass:{},target:`body`,color:void 0,backdrop:!0,heightAuto:!0,allowOutsideClick:!0,allowEscapeKey:!0,allowEnterKey:!0,stopKeydownPropagation:!0,keydownListenerCapture:!1,showConfirmButton:!0,showDenyButton:!1,showCancelButton:!1,preConfirm:void 0,preDeny:void 0,confirmButtonText:`OK`,confirmButtonAriaLabel:``,confirmButtonColor:void 0,denyButtonText:`No`,denyButtonAriaLabel:``,denyButtonColor:void 0,cancelButtonText:`Cancel`,cancelButtonAriaLabel:``,cancelButtonColor:void 0,buttonsStyling:!0,reverseButtons:!1,focusConfirm:!0,focusDeny:!1,focusCancel:!1,returnFocus:!0,showCloseButton:!1,closeButtonHtml:`&times;`,closeButtonAriaLabel:`Close this dialog`,loaderHtml:``,showLoaderOnConfirm:!1,showLoaderOnDeny:!1,imageUrl:void 0,imageWidth:void 0,imageHeight:void 0,imageAlt:``,timer:void 0,timerProgressBar:!1,width:void 0,padding:void 0,background:void 0,input:void 0,inputPlaceholder:``,inputLabel:``,inputValue:``,inputOptions:{},inputAutoFocus:!0,inputAutoTrim:!0,inputAttributes:{},inputValidator:void 0,returnInputValueOnDeny:!1,validationMessage:void 0,grow:!1,position:`center`,progressSteps:[],currentProgressStep:void 0,progressStepsDistance:void 0,willOpen:void 0,didOpen:void 0,didRender:void 0,willClose:void 0,didClose:void 0,didDestroy:void 0,scrollbarPadding:!0,topLayer:!1},qn=`allowEscapeKey.allowOutsideClick.background.buttonsStyling.cancelButtonAriaLabel.cancelButtonColor.cancelButtonText.closeButtonAriaLabel.closeButtonHtml.color.confirmButtonAriaLabel.confirmButtonColor.confirmButtonText.currentProgressStep.customClass.denyButtonAriaLabel.denyButtonColor.denyButtonText.didClose.didDestroy.draggable.footer.hideClass.html.icon.iconColor.iconHtml.imageAlt.imageHeight.imageUrl.imageWidth.preConfirm.preDeny.progressSteps.returnFocus.reverseButtons.showCancelButton.showCloseButton.showConfirmButton.showDenyButton.text.title.titleText.theme.willClose`.split(`.`),Jn={allowEnterKey:void 0},Yn=[`allowOutsideClick`,`allowEnterKey`,`backdrop`,`draggable`,`focusConfirm`,`focusDeny`,`focusCancel`,`returnFocus`,`heightAuto`,`keydownListenerCapture`],Xn=e=>Object.prototype.hasOwnProperty.call(Z,e),Zn=e=>qn.indexOf(e)!==-1,Qn=e=>Jn[e],$n=e=>{Xn(e)||p(`Unknown parameter "${e}"`)},er=e=>{Yn.includes(e)&&p(`The parameter "${e}" is incompatible with toasts`)},tr=e=>{let t=Qn(e);t&&_(e,t)},nr=e=>{e.backdrop===!1&&e.allowOutsideClick&&p('"allowOutsideClick" parameter requires `backdrop` parameter to be set to `true`'),e.theme&&![`light`,`dark`,`auto`,`minimal`,`borderless`,`bootstrap-4`,`bootstrap-4-light`,`bootstrap-4-dark`,`bootstrap-5`,`bootstrap-5-light`,`bootstrap-5-dark`,`material-ui`,`material-ui-light`,`material-ui-dark`,`embed-iframe`,`bulma`,`bulma-light`,`bulma-dark`].includes(e.theme)&&p(`Invalid theme "${e.theme}"`);for(let t in e)$n(t),e.toast&&er(t),tr(t)};function rr(e){let t=C(),n=E(),r=J.innerParams.get(this);if(!n||R(n,r.hideClass.popup)){p(`You're trying to update the closed or closing popup, that won't work. Use the update() method in preConfirm parameter or show a new popup.`);return}let i=ir(e),a=Object.assign({},r,i);nr(a),t&&(t.dataset.swal2Theme=a.theme),Dt(this,a),J.innerParams.set(this,a),Object.defineProperties(this,{params:{value:Object.assign({},this.params,e),writable:!1,enumerable:!0}})}let ir=e=>{let t={};return Object.keys(e).forEach(n=>{Zn(n)?t[n]=e[n]:p(`Invalid parameter to update: ${n}`)}),t};function ar(){var e;let t=J.domCache.get(this),n=J.innerParams.get(this);if(!n){sr(this);return}t.popup&&a.swalCloseEventFinishedCallback&&(a.swalCloseEventFinishedCallback(),delete a.swalCloseEventFinishedCallback),typeof n.didDestroy==`function`&&n.didDestroy(),(e=a.eventEmitter)==null||e.emit(`didDestroy`),or(this)}let or=e=>{sr(e),delete e.params,delete a.keydownHandler,delete a.keydownTarget,delete a.currentInstance},sr=e=>{e.isAwaitingPromise?(cr(J,e),e.isAwaitingPromise=!0):(cr(Ut,e),cr(J,e),delete e.isAwaitingPromise,delete e.disableButtons,delete e.enableButtons,delete e.getInput,delete e.disableInput,delete e.enableInput,delete e.hideLoading,delete e.disableLoading,delete e.showValidationMessage,delete e.resetValidationMessage,delete e.close,delete e.closePopup,delete e.closeModal,delete e.closeToast,delete e.rejectPromise,delete e.update,delete e._destroy)},cr=(e,t)=>{for(let n in e)e[n].delete(t)};var lr=Object.freeze({__proto__:null,_destroy:ar,close:X,closeModal:X,closePopup:X,closeToast:X,disableButtons:Hn,disableInput:Wn,disableLoading:In,enableButtons:Vn,enableInput:Un,getInput:Rn,handleAwaitingPromise:ln,hideLoading:In,rejectPromise:cn,resetValidationMessage:Kn,showValidationMessage:Gn,update:rr});let ur=(e,t,n)=>{e.toast?dr(e,t,n):(mr(t),hr(t),gr(e,t,n))},dr=(e,t,n)=>{t.popup.onclick=()=>{e&&(fr(e)||e.timer||e.input)||n(Mt.close)}},fr=e=>!!(e.showConfirmButton||e.showDenyButton||e.showCancelButton||e.showCloseButton),pr=!1,mr=e=>{e.popup.onmousedown=()=>{e.container.onmouseup=function(t){e.container.onmouseup=()=>{},t.target===e.container&&(pr=!0)}}},hr=e=>{e.container.onmousedown=t=>{t.target===e.container&&t.preventDefault(),e.popup.onmouseup=function(t){e.popup.onmouseup=()=>{},(t.target===e.popup||t.target instanceof HTMLElement&&e.popup.contains(t.target))&&(pr=!0)}}},gr=(e,t,n)=>{t.container.onclick=r=>{if(pr){pr=!1;return}r.target===t.container&&v(e.allowOutsideClick)&&n(Mt.backdrop)}},_r=e=>typeof e==`object`&&!!e&&`jquery`in e,vr=e=>e instanceof Element||_r(e),yr=e=>{let t={};return typeof e[0]==`object`&&!vr(e[0])?Object.assign(t,e[0]):[`title`,`html`,`icon`].forEach((n,r)=>{let i=e[r];typeof i==`string`||vr(i)?t[n]=i:i!==void 0&&m(`Unexpected type of ${n}! Expected "string" or "Element", got ${typeof i}`)}),t};function br(...e){return new this(...e)}function xr(e){class t extends this{_main(t,n){return super._main(t,Object.assign({},e,n))}}return t}let Sr=()=>a.timeout&&a.timeout.getTimerLeft(),Cr=()=>{if(a.timeout)return Se(),a.timeout.stop()},wr=()=>{if(a.timeout){let e=a.timeout.start();return xe(e),e}},Tr=()=>{let e=a.timeout;return e&&(e.running?Cr():wr())},Er=e=>{if(a.timeout){let t=a.timeout.increase(e);return xe(t,!0),t}},Dr=()=>!!(a.timeout&&a.timeout.isRunning()),Or=!1,kr={};function Ar(e=`data-swal-template`){kr[e]=this,Or||=(document.body.addEventListener(`click`,jr),!0)}let jr=e=>{for(let t=e.target;t&&t!==document;t=t.parentNode)for(let e in kr){let n=t.getAttribute&&t.getAttribute(e);if(n){kr[e].fire({template:n});return}}};class Mr{constructor(){this.events={}}_getHandlersByEventName(e){return this.events[e]===void 0&&(this.events[e]=[]),this.events[e]}on(e,t){let n=this._getHandlersByEventName(e);n.includes(t)||n.push(t)}once(e,t){let n=(...r)=>{this.removeListener(e,n),t.apply(this,r)};this.on(e,n)}emit(e,...t){this._getHandlersByEventName(e).forEach(e=>{try{e.apply(this,t)}catch(e){console.error(e)}})}removeListener(e,t){let n=this._getHandlersByEventName(e),r=n.indexOf(t);r>-1&&n.splice(r,1)}removeAllListeners(e){this.events[e]!==void 0&&(this.events[e].length=0)}reset(){this.events={}}}a.eventEmitter=new Mr;var Nr=Object.freeze({__proto__:null,argsToParams:yr,bindClickHandler:Ar,clickCancel:jt,clickConfirm:kt,clickDeny:At,enableLoading:mn,fire:br,getActions:F,getCancelButton:j,getCloseButton:ae,getConfirmButton:A,getContainer:C,getDenyButton:M,getFocusableElements:oe,getFooter:I,getHtmlContainer:O,getIcon:D,getIconContent:ee,getImage:ne,getInputLabel:N,getLoader:P,getPopup:E,getProgressSteps:re,getTimerLeft:Sr,getTimerProgressBar:ie,getTitle:te,getValidationMessage:k,increaseTimer:Er,isDeprecatedParameter:Qn,isLoading:le,isTimerRunning:Dr,isUpdatableParameter:Zn,isValidParameter:Xn,isVisible:Ot,mixin:xr,off:(e,t)=>{if(a.eventEmitter){if(!e){a.eventEmitter.reset();return}t?a.eventEmitter.removeListener(e,t):a.eventEmitter.removeAllListeners(e)}},on:(e,t)=>{a.eventEmitter&&a.eventEmitter.on(e,t)},once:(e,t)=>{a.eventEmitter&&a.eventEmitter.once(e,t)},resumeTimer:wr,showLoading:mn,stopTimer:Cr,toggleTimer:Tr});class Pr{constructor(e,t){this.callback=e,this.remaining=t,this.running=!1,this.start()}start(){return this.running||(this.running=!0,this.started=new Date,this.id=setTimeout(this.callback,this.remaining)),this.remaining}stop(){return this.started&&this.running&&(this.running=!1,clearTimeout(this.id),this.remaining-=new Date().getTime()-this.started.getTime()),this.remaining}increase(e){let t=this.running;return t&&this.stop(),this.remaining+=e,t&&this.start(),this.remaining}getTimerLeft(){return this.running&&(this.stop(),this.start()),this.remaining}isRunning(){return this.running}}let Fr=[`swal-title`,`swal-html`,`swal-footer`],Ir=e=>{let t=typeof e.template==`string`?document.querySelector(e.template):e.template;if(!t)return{};let n=t.content;return Wr(n),Object.assign(Lr(n),Rr(n),zr(n),Br(n),Vr(n),Hr(n),Ur(n,Fr))},Lr=e=>{let t={};return Array.from(e.querySelectorAll(`swal-param`)).forEach(e=>{Gr(e,[`name`,`value`]);let n=e.getAttribute(`name`),r=e.getAttribute(`value`);!n||!r||(n in Z&&typeof Z[n]==`boolean`?t[n]=r!==`false`:n in Z&&typeof Z[n]==`object`?t[n]=JSON.parse(r):t[n]=r)}),t},Rr=e=>{let t={};return Array.from(e.querySelectorAll(`swal-function-param`)).forEach(e=>{let n=e.getAttribute(`name`),r=e.getAttribute(`value`);!n||!r||(t[n]=Function(`return ${r}`)())}),t},zr=e=>{let t={};return Array.from(e.querySelectorAll(`swal-button`)).forEach(e=>{Gr(e,[`type`,`color`,`aria-label`]);let n=e.getAttribute(`type`);if(!n||![`confirm`,`cancel`,`deny`].includes(n))return;t[`${n}ButtonText`]=e.innerHTML,t[`show${f(n)}Button`]=!0;let r=e.getAttribute(`color`);r!==null&&(t[`${n}ButtonColor`]=r);let i=e.getAttribute(`aria-label`);i!==null&&(t[`${n}ButtonAriaLabel`]=i)}),t},Br=e=>{let t={},n=e.querySelector(`swal-image`);if(n){Gr(n,[`src`,`width`,`height`,`alt`]);let e=n.getAttribute(`src`);e!==null&&(t.imageUrl=e||void 0);let r=n.getAttribute(`width`);r!==null&&(t.imageWidth=r||void 0);let i=n.getAttribute(`height`);i!==null&&(t.imageHeight=i||void 0);let a=n.getAttribute(`alt`);a!==null&&(t.imageAlt=a||void 0)}return t},Vr=e=>{let t={},n=e.querySelector(`swal-icon`);return n&&(Gr(n,[`type`,`color`]),n.hasAttribute(`type`)&&(t.icon=n.getAttribute(`type`)),n.hasAttribute(`color`)&&(t.iconColor=n.getAttribute(`color`)),t.iconHtml=n.innerHTML),t},Hr=e=>{let t={},n=e.querySelector(`swal-input`);n&&(Gr(n,[`type`,`label`,`placeholder`,`value`]),t.input=n.getAttribute(`type`)||`text`,n.hasAttribute(`label`)&&(t.inputLabel=n.getAttribute(`label`)),n.hasAttribute(`placeholder`)&&(t.inputPlaceholder=n.getAttribute(`placeholder`)),n.hasAttribute(`value`)&&(t.inputValue=n.getAttribute(`value`)));let r=Array.from(e.querySelectorAll(`swal-input-option`));return r.length&&(t.inputOptions={},r.forEach(e=>{Gr(e,[`value`]);let n=e.getAttribute(`value`);if(!n)return;let r=e.innerHTML;t.inputOptions[n]=r})),t},Ur=(e,t)=>{let n={};for(let r in t){let i=t[r],a=e.querySelector(i);a&&(Gr(a,[]),n[i.replace(/^swal-/,``)]=a.innerHTML.trim())}return n},Wr=e=>{let t=Fr.concat([`swal-param`,`swal-function-param`,`swal-button`,`swal-image`,`swal-icon`,`swal-input`,`swal-input-option`]);Array.from(e.children).forEach(e=>{let n=e.tagName.toLowerCase();t.includes(n)||p(`Unrecognized element <${n}>`)})},Gr=(e,t)=>{Array.from(e.attributes).forEach(n=>{t.indexOf(n.name)===-1&&p([`Unrecognized attribute "${n.name}" on <${e.tagName.toLowerCase()}>.`,`${t.length?`Allowed attributes are: ${t.join(`, `)}`:`To set the value, use HTML within the element.`}`])})},Kr=e=>{var t,n;let r=C(),i=E();if(!r||!i)return;typeof e.willOpen==`function`&&e.willOpen(i),(t=a.eventEmitter)==null||t.emit(`willOpen`,i);let o=window.getComputedStyle(document.body).overflowY;if(Xr(r,i,e),setTimeout(()=>{Jr(r,i)},10),se()&&(Yr(r,e.scrollbarPadding===void 0?!1:e.scrollbarPadding,o),Wt()),qt&&e.backdrop===!1&&i.scrollHeight>r.clientHeight&&(r.style.pointerEvents=`auto`),!ce()&&!a.previousActiveElement&&(a.previousActiveElement=document.activeElement),typeof e.didOpen==`function`){let t=e.didOpen;setTimeout(()=>t(i))}(n=a.eventEmitter)==null||n.emit(`didOpen`,i)},qr=e=>{let t=E();if(!t||e.target!==t)return;let n=C();n&&(t.removeEventListener(`animationend`,qr),t.removeEventListener(`transitionend`,qr),n.style.overflowY=`auto`,V(n,l[`no-transition`]))},Jr=(e,t)=>{be(t)?(e.style.overflowY=`hidden`,t.addEventListener(`animationend`,qr),t.addEventListener(`transitionend`,qr)):e.style.overflowY=`auto`},Yr=(e,t,n)=>{Jt(),t&&n!==`hidden`&&nn(n),setTimeout(()=>{e.scrollTop=0})},Xr=(e,t,n)=>{var r;(r=n.showClass)!=null&&r.backdrop&&B(e,n.showClass.backdrop),n.animation?(t.style.setProperty(`opacity`,`0`,`important`),W(t,`grid`),setTimeout(()=>{var e;(e=n.showClass)!=null&&e.popup&&B(t,n.showClass.popup),t.style.removeProperty(`opacity`)},10)):W(t,`grid`),B([document.documentElement,document.body],l.shown),n.heightAuto&&n.backdrop&&!n.toast&&B([document.documentElement,document.body],l[`height-auto`])};var Zr={email:(e,t)=>/^[a-zA-Z0-9.+_'-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9-]+$/.test(e)?Promise.resolve():Promise.resolve(t||`Invalid email address`),url:(e,t)=>/^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-z]{2,63}\b([-a-zA-Z0-9@:%_+.~#?&/=]*)$/.test(e)?Promise.resolve():Promise.resolve(t||`Invalid URL`)};function Qr(e){e.inputValidator||(e.input===`email`&&(e.inputValidator=Zr.email),e.input===`url`&&(e.inputValidator=Zr.url))}function $r(e){(!e.target||typeof e.target==`string`&&!document.querySelector(e.target)||typeof e.target!=`string`&&!e.target.appendChild)&&(p(`Target parameter is not valid, defaulting to "body"`),e.target=`body`)}function ei(e){Qr(e),e.showLoaderOnConfirm&&!e.preConfirm&&p(`showLoaderOnConfirm is set to true, but preConfirm is not defined.
showLoaderOnConfirm should be used together with preConfirm, see usage example:
https://sweetalert2.github.io/#ajax-request`),$r(e),typeof e.title==`string`&&(e.title=e.title.split(`
`).join(`<br />`)),Ae(e)}let Q;var ti=new WeakMap;class ${constructor(...e){if(r(this,ti,Promise.resolve({isConfirmed:!1,isDenied:!1,isDismissed:!0})),typeof window>`u`)return;Q=this;let t=Object.freeze(this.constructor.argsToParams(e));this.params=t,this.isAwaitingPromise=!1,i(ti,this,this._main(Q.params))}_main(e,t={}){if(nr(Object.assign({},t,e)),a.currentInstance){let e=Ut.swalPromiseResolve.get(a.currentInstance),{isAwaitingPromise:t}=a.currentInstance;a.currentInstance._destroy(),t||e({isDismissed:!0}),se()&&Gt()}a.currentInstance=Q;let n=ri(e,t);ei(n),Object.freeze(n),a.timeout&&(a.timeout.stop(),delete a.timeout),clearTimeout(a.restoreFocusTimeout);let r=ii(Q);return Dt(Q,n),J.innerParams.set(Q,n),ni(Q,r,n)}then(e){return n(ti,this).then(e)}finally(e){return n(ti,this).finally(e)}}let ni=(e,t,n)=>new Promise((r,i)=>{let o=t=>{e.close({isDismissed:!0,dismiss:t,isConfirmed:!1,isDenied:!1})};Ut.swalPromiseResolve.set(e,r),Ut.swalPromiseReject.set(e,i),t.confirmButton.onclick=()=>{Dn(e)},t.denyButton.onclick=()=>{On(e)},t.cancelButton.onclick=()=>{kn(e,o)},t.closeButton.onclick=()=>{o(Mt.close)},ur(n,t,o),Pt(a,n,o),gn(e,n),Kr(n),ai(a,n,o),oi(t,n),setTimeout(()=>{t.container.scrollTop=0})}),ri=(e,t)=>{let n=Ir(e),r=Object.assign({},Z,t,n,e);return r.showClass=Object.assign({},Z.showClass,r.showClass),r.hideClass=Object.assign({},Z.hideClass,r.hideClass),r.animation===!1&&(r.showClass={backdrop:`swal2-noanimation`},r.hideClass={}),r},ii=e=>{let t={popup:E(),container:C(),actions:F(),confirmButton:A(),denyButton:M(),cancelButton:j(),loader:P(),closeButton:ae(),validationMessage:k(),progressSteps:re()};return J.domCache.set(e,t),t},ai=(e,t,n)=>{let r=ie();G(r),t.timer&&(e.timeout=new Pr(()=>{n(`timer`),delete e.timeout},t.timer),t.timerProgressBar&&r&&(W(r),z(r,t,`timerProgressBar`),setTimeout(()=>{e.timeout&&e.timeout.running&&xe(t.timer)})))},oi=(e,t)=>{if(!t.toast){if(!v(t.allowEnterKey)){_(`allowEnterKey`,`preConfirm: () => false`),e.popup.focus();return}si(e)||ci(e,t)||Ft(-1,1)}},si=e=>{let t=Array.from(e.popup.querySelectorAll(`[autofocus]`));for(let e of t)if(e instanceof HTMLElement&&K(e))return e.focus(),!0;return!1},ci=(e,t)=>t.focusDeny&&K(e.denyButton)?(e.denyButton.focus(),!0):t.focusCancel&&K(e.cancelButton)?(e.cancelButton.focus(),!0):t.focusConfirm&&K(e.confirmButton)?(e.confirmButton.focus(),!0):!1;$.prototype.disableButtons=Hn,$.prototype.enableButtons=Vn,$.prototype.getInput=Rn,$.prototype.disableInput=Wn,$.prototype.enableInput=Un,$.prototype.hideLoading=In,$.prototype.disableLoading=In,$.prototype.showValidationMessage=Gn,$.prototype.resetValidationMessage=Kn,$.prototype.close=X,$.prototype.closePopup=X,$.prototype.closeModal=X,$.prototype.closeToast=X,$.prototype.rejectPromise=cn,$.prototype.update=rr,$.prototype._destroy=ar,Object.assign($,Nr),Object.keys(lr).forEach(e=>{$[e]=function(...t){if(Q&&Q[e])return Q[e](...t)}}),$.DismissReason=Mt,$.version=`11.26.25`;let li=$;return li.default=li,li})),e!==void 0&&e.Sweetalert2&&(e.swal=e.sweetAlert=e.Swal=e.SweetAlert=e.Sweetalert2),typeof document<`u`&&function(e,t){var n=e.createElement(`style`);if(e.getElementsByTagName(`head`)[0].appendChild(n),n.styleSheet)n.styleSheet.disabled||(n.styleSheet.cssText=t);else try{n.innerHTML=t}catch{n.innerText=t}}(document,`:root{--swal2-outline: 0 0 0 3px rgba(100, 150, 200, 0.5);--swal2-container-padding: 0.625em;--swal2-backdrop: rgba(0, 0, 0, 0.4);--swal2-backdrop-transition: background-color 0.15s;--swal2-width: 32em;--swal2-padding: 0 0 1.25em;--swal2-border: none;--swal2-border-radius: 0.3125rem;--swal2-background: white;--swal2-color: #545454;--swal2-show-animation: swal2-show 0.3s;--swal2-hide-animation: swal2-hide 0.15s forwards;--swal2-icon-zoom: 1;--swal2-title-padding: 0.8em 1em 0;--swal2-html-container-padding: 1em 1.6em 0.3em;--swal2-input-border: 1px solid #d9d9d9;--swal2-input-border-radius: 0.1875em;--swal2-input-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06), 0 0 0 3px transparent;--swal2-input-background: transparent;--swal2-input-transition: border-color 0.2s, box-shadow 0.2s;--swal2-input-hover-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06), 0 0 0 3px transparent;--swal2-input-focus-border: 1px solid #b4dbed;--swal2-input-focus-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06), 0 0 0 3px rgba(100, 150, 200, 0.5);--swal2-progress-step-background: #add8e6;--swal2-validation-message-background: #f0f0f0;--swal2-validation-message-color: #666;--swal2-footer-border-color: #eee;--swal2-footer-background: transparent;--swal2-footer-color: inherit;--swal2-timer-progress-bar-background: rgba(0, 0, 0, 0.3);--swal2-close-button-position: initial;--swal2-close-button-inset: auto;--swal2-close-button-font-size: 2.5em;--swal2-close-button-color: #ccc;--swal2-close-button-transition: color 0.2s, box-shadow 0.2s;--swal2-close-button-outline: initial;--swal2-close-button-box-shadow: inset 0 0 0 3px transparent;--swal2-close-button-focus-box-shadow: inset var(--swal2-outline);--swal2-close-button-hover-transform: none;--swal2-actions-justify-content: center;--swal2-actions-width: auto;--swal2-actions-margin: 1.25em auto 0;--swal2-actions-padding: 0;--swal2-actions-border-radius: 0;--swal2-actions-background: transparent;--swal2-action-button-transition: background-color 0.2s, box-shadow 0.2s;--swal2-action-button-hover: black 10%;--swal2-action-button-active: black 10%;--swal2-confirm-button-box-shadow: none;--swal2-confirm-button-border-radius: 0.25em;--swal2-confirm-button-background-color: #7066e0;--swal2-confirm-button-color: #fff;--swal2-deny-button-box-shadow: none;--swal2-deny-button-border-radius: 0.25em;--swal2-deny-button-background-color: #dc3741;--swal2-deny-button-color: #fff;--swal2-cancel-button-box-shadow: none;--swal2-cancel-button-border-radius: 0.25em;--swal2-cancel-button-background-color: #6e7881;--swal2-cancel-button-color: #fff;--swal2-toast-show-animation: swal2-toast-show 0.5s;--swal2-toast-hide-animation: swal2-toast-hide 0.1s forwards;--swal2-toast-border: none;--swal2-toast-box-shadow: 0 0 1px hsl(0deg 0% 0% / 0.075), 0 1px 2px hsl(0deg 0% 0% / 0.075), 1px 2px 4px hsl(0deg 0% 0% / 0.075), 1px 3px 8px hsl(0deg 0% 0% / 0.075), 2px 4px 16px hsl(0deg 0% 0% / 0.075)}[data-swal2-theme=dark]{--swal2-dark-theme-black: #19191a;--swal2-dark-theme-white: #e1e1e1;--swal2-background: var(--swal2-dark-theme-black);--swal2-color: var(--swal2-dark-theme-white);--swal2-footer-border-color: #555;--swal2-input-background: color-mix(in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10%);--swal2-validation-message-background: color-mix( in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10% );--swal2-validation-message-color: var(--swal2-dark-theme-white);--swal2-timer-progress-bar-background: rgba(255, 255, 255, 0.7)}@media(prefers-color-scheme: dark){[data-swal2-theme=auto]{--swal2-dark-theme-black: #19191a;--swal2-dark-theme-white: #e1e1e1;--swal2-background: var(--swal2-dark-theme-black);--swal2-color: var(--swal2-dark-theme-white);--swal2-footer-border-color: #555;--swal2-input-background: color-mix(in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10%);--swal2-validation-message-background: color-mix( in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10% );--swal2-validation-message-color: var(--swal2-dark-theme-white);--swal2-timer-progress-bar-background: rgba(255, 255, 255, 0.7)}}body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto !important}body.swal2-no-backdrop .swal2-container{background-color:rgba(0,0,0,0) !important;pointer-events:none}body.swal2-no-backdrop .swal2-container .swal2-popup{pointer-events:auto}body.swal2-no-backdrop .swal2-container .swal2-modal{box-shadow:0 0 10px var(--swal2-backdrop)}body.swal2-toast-shown .swal2-container{box-sizing:border-box;width:360px;max-width:100%;background-color:rgba(0,0,0,0);pointer-events:none}body.swal2-toast-shown .swal2-container.swal2-top{inset:0 auto auto 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{inset:0 0 auto auto}body.swal2-toast-shown .swal2-container.swal2-top-start,body.swal2-toast-shown .swal2-container.swal2-top-left{inset:0 auto auto 0}body.swal2-toast-shown .swal2-container.swal2-center-start,body.swal2-toast-shown .swal2-container.swal2-center-left{inset:50% auto auto 0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{inset:50% auto auto 50%;transform:translate(-50%, -50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{inset:50% 0 auto auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-start,body.swal2-toast-shown .swal2-container.swal2-bottom-left{inset:auto auto 0 0}body.swal2-toast-shown .swal2-container.swal2-bottom{inset:auto auto 0 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{inset:auto 0 0 auto}@media print{body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown){overflow-y:scroll !important}body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown) .swal2-container{position:static !important}}div:where(.swal2-container){display:grid;position:fixed;z-index:1060;inset:0;box-sizing:border-box;grid-template-areas:"top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";grid-template-rows:minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);height:100%;padding:var(--swal2-container-padding);overflow-x:hidden;transition:var(--swal2-backdrop-transition);-webkit-overflow-scrolling:touch}div:where(.swal2-container).swal2-backdrop-show,div:where(.swal2-container).swal2-noanimation{background:var(--swal2-backdrop)}div:where(.swal2-container).swal2-backdrop-hide{background:rgba(0,0,0,0) !important}div:where(.swal2-container).swal2-top-start,div:where(.swal2-container).swal2-center-start,div:where(.swal2-container).swal2-bottom-start{grid-template-columns:minmax(0, 1fr) auto auto}div:where(.swal2-container).swal2-top,div:where(.swal2-container).swal2-center,div:where(.swal2-container).swal2-bottom{grid-template-columns:auto minmax(0, 1fr) auto}div:where(.swal2-container).swal2-top-end,div:where(.swal2-container).swal2-center-end,div:where(.swal2-container).swal2-bottom-end{grid-template-columns:auto auto minmax(0, 1fr)}div:where(.swal2-container).swal2-top-start>.swal2-popup{align-self:start}div:where(.swal2-container).swal2-top>.swal2-popup{grid-column:2;place-self:start center}div:where(.swal2-container).swal2-top-end>.swal2-popup,div:where(.swal2-container).swal2-top-right>.swal2-popup{grid-column:3;place-self:start end}div:where(.swal2-container).swal2-center-start>.swal2-popup,div:where(.swal2-container).swal2-center-left>.swal2-popup{grid-row:2;align-self:center}div:where(.swal2-container).swal2-center>.swal2-popup{grid-column:2;grid-row:2;place-self:center center}div:where(.swal2-container).swal2-center-end>.swal2-popup,div:where(.swal2-container).swal2-center-right>.swal2-popup{grid-column:3;grid-row:2;place-self:center end}div:where(.swal2-container).swal2-bottom-start>.swal2-popup,div:where(.swal2-container).swal2-bottom-left>.swal2-popup{grid-column:1;grid-row:3;align-self:end}div:where(.swal2-container).swal2-bottom>.swal2-popup{grid-column:2;grid-row:3;place-self:end center}div:where(.swal2-container).swal2-bottom-end>.swal2-popup,div:where(.swal2-container).swal2-bottom-right>.swal2-popup{grid-column:3;grid-row:3;place-self:end end}div:where(.swal2-container).swal2-grow-row>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-column:1/4;width:100%}div:where(.swal2-container).swal2-grow-column>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-row:1/4;align-self:stretch}div:where(.swal2-container).swal2-no-transition{transition:none !important}div:where(.swal2-container)[popover]{width:auto;border:0}div:where(.swal2-container) div:where(.swal2-popup){display:none;position:relative;box-sizing:border-box;grid-template-columns:minmax(0, 100%);width:var(--swal2-width);max-width:100%;padding:var(--swal2-padding);border:var(--swal2-border);border-radius:var(--swal2-border-radius);background:var(--swal2-background);color:var(--swal2-color);font-family:inherit;font-size:1rem}div:where(.swal2-container) div:where(.swal2-popup):focus{outline:none}div:where(.swal2-container) div:where(.swal2-popup).swal2-loading{overflow-y:hidden}div:where(.swal2-container) div:where(.swal2-popup).swal2-draggable{cursor:grab}div:where(.swal2-container) div:where(.swal2-popup).swal2-draggable div:where(.swal2-icon){cursor:grab}div:where(.swal2-container) div:where(.swal2-popup).swal2-dragging{cursor:grabbing}div:where(.swal2-container) div:where(.swal2-popup).swal2-dragging div:where(.swal2-icon){cursor:grabbing}div:where(.swal2-container) h2:where(.swal2-title){position:relative;max-width:100%;margin:0;padding:var(--swal2-title-padding);color:inherit;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;overflow-wrap:break-word;cursor:initial}div:where(.swal2-container) div:where(.swal2-actions){display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:var(--swal2-actions-justify-content);width:var(--swal2-actions-width);margin:var(--swal2-actions-margin);padding:var(--swal2-actions-padding);border-radius:var(--swal2-actions-border-radius);background:var(--swal2-actions-background)}div:where(.swal2-container) div:where(.swal2-loader){display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 rgba(0,0,0,0) #2778c4 rgba(0,0,0,0)}div:where(.swal2-container) button:where(.swal2-styled){margin:.3125em;padding:.625em 1.1em;transition:var(--swal2-action-button-transition);border:none;box-shadow:0 0 0 3px rgba(0,0,0,0);font-weight:500}div:where(.swal2-container) button:where(.swal2-styled):not([disabled]){cursor:pointer}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm){border-radius:var(--swal2-confirm-button-border-radius);background:initial;background-color:var(--swal2-confirm-button-background-color);box-shadow:var(--swal2-confirm-button-box-shadow);color:var(--swal2-confirm-button-color);font-size:1em}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm):hover{background-color:color-mix(in srgb, var(--swal2-confirm-button-background-color), var(--swal2-action-button-hover))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm):active{background-color:color-mix(in srgb, var(--swal2-confirm-button-background-color), var(--swal2-action-button-active))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny){border-radius:var(--swal2-deny-button-border-radius);background:initial;background-color:var(--swal2-deny-button-background-color);box-shadow:var(--swal2-deny-button-box-shadow);color:var(--swal2-deny-button-color);font-size:1em}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny):hover{background-color:color-mix(in srgb, var(--swal2-deny-button-background-color), var(--swal2-action-button-hover))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny):active{background-color:color-mix(in srgb, var(--swal2-deny-button-background-color), var(--swal2-action-button-active))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel){border-radius:var(--swal2-cancel-button-border-radius);background:initial;background-color:var(--swal2-cancel-button-background-color);box-shadow:var(--swal2-cancel-button-box-shadow);color:var(--swal2-cancel-button-color);font-size:1em}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel):hover{background-color:color-mix(in srgb, var(--swal2-cancel-button-background-color), var(--swal2-action-button-hover))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel):active{background-color:color-mix(in srgb, var(--swal2-cancel-button-background-color), var(--swal2-action-button-active))}div:where(.swal2-container) button:where(.swal2-styled):focus-visible{outline:none;box-shadow:var(--swal2-action-button-focus-box-shadow)}div:where(.swal2-container) button:where(.swal2-styled)[disabled]:not(.swal2-loading){opacity:.4}div:where(.swal2-container) button:where(.swal2-styled)::-moz-focus-inner{border:0}div:where(.swal2-container) div:where(.swal2-footer){margin:1em 0 0;padding:1em 1em 0;border-top:1px solid var(--swal2-footer-border-color);background:var(--swal2-footer-background);color:var(--swal2-footer-color);font-size:1em;text-align:center;cursor:initial}div:where(.swal2-container) .swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;grid-column:auto !important;overflow:hidden;border-bottom-right-radius:var(--swal2-border-radius);border-bottom-left-radius:var(--swal2-border-radius)}div:where(.swal2-container) div:where(.swal2-timer-progress-bar){width:100%;height:.25em;background:var(--swal2-timer-progress-bar-background)}div:where(.swal2-container) img:where(.swal2-image){max-width:100%;margin:2em auto 1em;cursor:initial}div:where(.swal2-container) button:where(.swal2-close){position:var(--swal2-close-button-position);inset:var(--swal2-close-button-inset);z-index:2;align-items:center;justify-content:center;width:1.2em;height:1.2em;margin-top:0;margin-right:0;margin-bottom:-1.2em;padding:0;overflow:hidden;transition:var(--swal2-close-button-transition);border:none;border-radius:var(--swal2-border-radius);outline:var(--swal2-close-button-outline);background:rgba(0,0,0,0);color:var(--swal2-close-button-color);font-family:monospace;font-size:var(--swal2-close-button-font-size);cursor:pointer;justify-self:end}div:where(.swal2-container) button:where(.swal2-close):hover{transform:var(--swal2-close-button-hover-transform);background:rgba(0,0,0,0);color:#f27474}div:where(.swal2-container) button:where(.swal2-close):focus-visible{outline:none;box-shadow:var(--swal2-close-button-focus-box-shadow)}div:where(.swal2-container) button:where(.swal2-close)::-moz-focus-inner{border:0}div:where(.swal2-container) div:where(.swal2-html-container){z-index:1;justify-content:center;margin:0;padding:var(--swal2-html-container-padding);overflow:auto;color:inherit;font-size:1.125em;font-weight:normal;line-height:normal;text-align:center;overflow-wrap:break-word;word-break:break-word;cursor:initial}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea),div:where(.swal2-container) select:where(.swal2-select),div:where(.swal2-container) div:where(.swal2-radio),div:where(.swal2-container) label:where(.swal2-checkbox){margin:1em 2em 3px}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea){box-sizing:border-box;width:auto;transition:var(--swal2-input-transition);border:var(--swal2-input-border);border-radius:var(--swal2-input-border-radius);background:var(--swal2-input-background);box-shadow:var(--swal2-input-box-shadow);color:inherit;font-size:1.125em}div:where(.swal2-container) input:where(.swal2-input).swal2-inputerror,div:where(.swal2-container) input:where(.swal2-file).swal2-inputerror,div:where(.swal2-container) textarea:where(.swal2-textarea).swal2-inputerror{border-color:#f27474 !important;box-shadow:0 0 2px #f27474 !important}div:where(.swal2-container) input:where(.swal2-input):hover,div:where(.swal2-container) input:where(.swal2-file):hover,div:where(.swal2-container) textarea:where(.swal2-textarea):hover{box-shadow:var(--swal2-input-hover-box-shadow)}div:where(.swal2-container) input:where(.swal2-input):focus,div:where(.swal2-container) input:where(.swal2-file):focus,div:where(.swal2-container) textarea:where(.swal2-textarea):focus{border:var(--swal2-input-focus-border);outline:none;box-shadow:var(--swal2-input-focus-box-shadow)}div:where(.swal2-container) input:where(.swal2-input)::placeholder,div:where(.swal2-container) input:where(.swal2-file)::placeholder,div:where(.swal2-container) textarea:where(.swal2-textarea)::placeholder{color:#ccc}div:where(.swal2-container) .swal2-range{margin:1em 2em 3px;background:var(--swal2-background)}div:where(.swal2-container) .swal2-range input{width:80%}div:where(.swal2-container) .swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}div:where(.swal2-container) .swal2-range input,div:where(.swal2-container) .swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}div:where(.swal2-container) .swal2-input{height:2.625em;padding:0 .75em}div:where(.swal2-container) .swal2-file{width:75%;margin-right:auto;margin-left:auto;background:var(--swal2-input-background);font-size:1.125em}div:where(.swal2-container) .swal2-textarea{height:6.75em;padding:.75em}div:where(.swal2-container) .swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:var(--swal2-input-background);color:inherit;font-size:1.125em}div:where(.swal2-container) .swal2-radio,div:where(.swal2-container) .swal2-checkbox{align-items:center;justify-content:center;background:var(--swal2-background);color:inherit}div:where(.swal2-container) .swal2-radio label,div:where(.swal2-container) .swal2-checkbox label{margin:0 .6em;font-size:1.125em}div:where(.swal2-container) .swal2-radio input,div:where(.swal2-container) .swal2-checkbox input{flex-shrink:0;margin:0 .4em}div:where(.swal2-container) label:where(.swal2-input-label){display:flex;justify-content:center;margin:1em auto 0}div:where(.swal2-container) div:where(.swal2-validation-message){align-items:center;justify-content:center;margin:1em 0 0;padding:.625em;overflow:hidden;background:var(--swal2-validation-message-background);color:var(--swal2-validation-message-color);font-size:1em;font-weight:300}div:where(.swal2-container) div:where(.swal2-validation-message)::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}div:where(.swal2-container) .swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:1.25em auto;padding:0;background:rgba(0,0,0,0);font-weight:600}div:where(.swal2-container) .swal2-progress-steps li{display:inline-block;position:relative}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:var(--swal2-progress-step-background);color:#fff}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:var(--swal2-progress-step-background)}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}div:where(.swal2-icon){position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:2.5em auto .6em;zoom:var(--swal2-icon-zoom);border:.25em solid rgba(0,0,0,0);border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;user-select:none}div:where(.swal2-icon) .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}div:where(.swal2-icon).swal2-error{border-color:#f27474;color:#f27474}div:where(.swal2-icon).swal2-error .swal2-x-mark{position:relative;flex-grow:1}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-error.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-error.swal2-icon-show .swal2-x-mark{animation:swal2-animate-error-x-mark .5s}div:where(.swal2-icon).swal2-warning{border-color:#f8bb86;color:#f8bb86}div:where(.swal2-icon).swal2-warning.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-warning.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .5s}div:where(.swal2-icon).swal2-info{border-color:#3fc3ee;color:#3fc3ee}div:where(.swal2-icon).swal2-info.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-info.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .8s}div:where(.swal2-icon).swal2-question{border-color:#87adbd;color:#87adbd}div:where(.swal2-icon).swal2-question.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-question.swal2-icon-show .swal2-icon-content{animation:swal2-animate-question-mark .8s}div:where(.swal2-icon).swal2-success{border-color:#a5dc86;color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;border-radius:50%}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}div:where(.swal2-icon).swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-0.25em;left:-0.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}div:where(.swal2-icon).swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-animate-success-line-tip .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-animate-success-line-long .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-circular-line-right{animation:swal2-rotate-success-circular-line 4.25s ease-in}[class^=swal2]{-webkit-tap-highlight-color:rgba(0,0,0,0)}.swal2-show{animation:var(--swal2-show-animation)}.swal2-hide{animation:var(--swal2-hide-animation)}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{margin-right:initial;margin-left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}.swal2-toast{box-sizing:border-box;grid-column:1/4 !important;grid-row:1/4 !important;grid-template-columns:min-content auto min-content;padding:1em;overflow-y:hidden;border:var(--swal2-toast-border);background:var(--swal2-background);box-shadow:var(--swal2-toast-box-shadow);pointer-events:auto}.swal2-toast>*{grid-column:2}.swal2-toast h2:where(.swal2-title){margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-toast .swal2-loading{justify-content:center}.swal2-toast input:where(.swal2-input){height:2em;margin:.5em;font-size:1em}.swal2-toast .swal2-validation-message{font-size:1em}.swal2-toast div:where(.swal2-footer){margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-toast button:where(.swal2-close){grid-column:3/3;grid-row:1/99;align-self:center;width:.8em;height:.8em;margin:0;font-size:2em}.swal2-toast div:where(.swal2-html-container){margin:.5em 1em;padding:0;overflow:initial;font-size:1em;text-align:initial}.swal2-toast div:where(.swal2-html-container):empty{padding:0}.swal2-toast .swal2-loader{grid-column:1;grid-row:1/99;align-self:center;width:2em;height:2em;margin:.25em}.swal2-toast .swal2-icon{grid-column:1;grid-row:1/99;align-self:center;width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:bold}.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-toast div:where(.swal2-actions){justify-content:flex-start;height:auto;margin:0;margin-top:.5em;padding:0 .5em}.swal2-toast button:where(.swal2-styled){margin:.25em .5em;padding:.4em .6em;font-size:1em}.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;border-radius:50%}.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.8em;left:-0.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-toast-animate-success-line-tip .75s}.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-toast-animate-success-line-long .75s}.swal2-toast.swal2-show{animation:var(--swal2-toast-show-animation)}.swal2-toast.swal2-hide{animation:var(--swal2-toast-hide-animation)}@keyframes swal2-show{0%{transform:translate3d(0, -50px, 0) scale(0.9);opacity:0}100%{transform:translate3d(0, 0, 0) scale(1);opacity:1}}@keyframes swal2-hide{0%{transform:translate3d(0, 0, 0) scale(1);opacity:1}100%{transform:translate3d(0, -50px, 0) scale(0.9);opacity:0}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-0.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(0.4);opacity:0}50%{margin-top:1.625em;transform:scale(0.4);opacity:0}80%{margin-top:-0.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0deg);opacity:1}}@keyframes swal2-rotate-loading{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}@keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-toast-show{0%{transform:translateY(-0.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(0.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0deg)}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-0.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}`)}));export{K as n,I as r,_e as t};